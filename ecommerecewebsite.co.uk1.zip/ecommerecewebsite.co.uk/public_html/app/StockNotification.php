<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StockNotification extends Model
{
    //
}
