<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductStock extends Model
{
    //
    protected $fillable = ['id','product_id','variant','sku','price','qty','variant_description','variant_image'];
    
    protected $table = 'product_stocks';
    public function product(){
    	return $this->belongsTo(Product::class);
    }
}
