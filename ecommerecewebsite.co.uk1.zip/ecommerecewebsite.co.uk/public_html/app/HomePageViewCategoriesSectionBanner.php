<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HomePageViewCategoriesSectionBanner extends Model
{
    //
    protected $table = 'home_page_view_categories_section_banner';
}
