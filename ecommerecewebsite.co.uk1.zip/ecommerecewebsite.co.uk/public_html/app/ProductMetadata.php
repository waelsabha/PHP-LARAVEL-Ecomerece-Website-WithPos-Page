<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductMetadata extends Model
{
    //
    // protected $fillable = [
    //     'product_id','m_title','m_mdesc','m_mkeywrd','m_robot','m_cpyrgt','m_og_title',
    //     'm_og_desc','m_dc_title','m_dc_desc','m_dc_sub','m_dc_crtor','m_dc_crtd','m_dc_modified','m_dc_type','m_dc_type_img','m_dc_lang','m_dc_format','m_dc_filename','m_sts'
    // ];
    protected $table = 'product_metadatas';
}
