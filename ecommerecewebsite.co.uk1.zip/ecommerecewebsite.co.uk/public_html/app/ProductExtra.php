<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductExtra extends Model
{
    //

    protected $fillable = ['id',
        'product_id','material','battery','battery_type','battery_qty','product_dimention','package_dimention',
        'age_for','country_of_origin','product_warning','product_usage','product_weight_unit','package_include','product_unit','package_unit'
    ];
     protected $table = 'product_extras';

    public function product(){
    	return $this->belongsTo(Product::class);
    }
}
