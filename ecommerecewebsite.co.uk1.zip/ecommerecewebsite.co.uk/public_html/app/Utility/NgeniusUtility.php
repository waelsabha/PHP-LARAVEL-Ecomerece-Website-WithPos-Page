<?php

namespace App\Utility;

use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\CustomerPackageController;
use App\Http\Controllers\WalletController;
use Session;
use App\Order;
use Illuminate\Support\Facades\Log;
class NgeniusUtility
{
    public static function getUrl($key)
    {
        $mode = self::getMode();
        $url['sandbox']['identity'] = "https://api-gateway.sandbox.ngenius-payments.com/identity/auth/access-token";
        $url['sandbox']['gateway'] = "https://api-gateway.sandbox.ngenius-payments.com";
        // sandbox urls do not work as the identity is not retrived by sandbox identity

        $url['real']['identity'] = "https://identity-uat.ngenius-payments.com/auth/realms/ni/protocol/openid-connect/token";
        $url['real']['gateway'] = "https://api-gateway-uat.ngenius-payments.com";

        return $url[$mode][$key];
    }

    //sandbox or real
    public static function getMode()
    {
        $sandbox = false; //check from db or env
        // sandbox urls do not work as the identity is not retrived by sandbox identity

        return $sandbox ? "sandbox" : "real";
    }

    public static function getAccessToken()
    {
        $apikey = "NDcwNTc5NmItNmZiZC00NjRjLTg3OTEtZmM5ZGZjMWIwMDk4OmM2MWZjMmRhLWJmYjgtNGQzNy04MmQ4LTZjNDk1YzQ0MmJjNA==";   // enter your API key here
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, "https://api-gateway.ngenius-payments.com/identity/auth/access-token"); 

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "accept: application/vnd.ni-identity.v1+json",
            "authorization: Basic ".$apikey,
            "content-type: application/vnd.ni-identity.v1+json"
        )); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        curl_setopt($ch, CURLOPT_POST, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS,  "{\"realmName\":\"NetworkInternational\"}"); 
        $output = json_decode(curl_exec($ch)); 
        // dd($output);
        $access_token = $output->access_token;
        
        
        return $access_token;
    }


    public static function make_payment($callback_url, $payment_type, $amount)
    {
        $shipping_info = Session::get('shipping_info');
        $shipping_charge_amount = Session::get('shipping');
        // dd($shipping_charge_amount);
        $postData = new \StdClass(); 
        $postData->action = "SALE"; 
        $postData->emailAddress = (!is_null($shipping_info['email'])) ? $shipping_info['email'] : ''; 
        $postData->amount = new \StdClass();
        $postData->amount->currencyCode = "AED"; 
        //$postData->amount->value = 100*1;
       $postData->amount->value = $amount;

        $postData->shippingAddress= new \StdClass();
        $postData->shippingAddress->firstName= (!is_null($shipping_info['name'])) ? $shipping_info['name'] : ''; 
        // $postData->shippingAddress->lastName= 'Jasem'; 
        $postData->shippingAddress->address1= (!is_null($shipping_info['address'])) ? $shipping_info['address'] : ''; 
        // $postData->shippingAddress->city= (!is_null($shipping_info['emirate'])) ? $shipping_info['emirate'] : ''; 

        $postData->shippingAddress->countryCode= 'UAE'; 

        
        $postData->merchantAttributes = new \StdClass();
        $postData->merchantAttributes->redirectUrl = $callback_url;
         
       
        $postData->merchantDefinedData= new \StdClass();
        $postData->merchantDefinedData->shipping_total =  ($shipping_charge_amount) ? $shipping_charge_amount : 0;  
       
        // $postData->merchantDefinedData->city2= (!is_null($shipping_info['area'])) ? $shipping_info['area'] : '';  
        
        $postData->merchantDefinedData->mobile= (!is_null($shipping_info['phone'])) ? $shipping_info['phone'] : '';  
       

        $postData->merchantAttributes->skipConfirmationPage = true; 

        $access_token = self::getAccessToken();
        $outlet = "adbe5328-aa64-4f4b-a353-a2d027f33ca6";
        // $outlet = "b604f1af-1928-4b92-9506-02ad6483ce3a";
        $json = json_encode($postData);
        $ch = curl_init(); 
        
        curl_setopt($ch, CURLOPT_URL, "https://api-gateway.ngenius-payments.com/transactions/outlets/".$outlet."/orders"); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer ".$access_token, 
        "Content-Type: application/vnd.ni-payment.v2+json", 
        "Accept: application/vnd.ni-payment.v2+json")); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        curl_setopt($ch, CURLOPT_POST, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json); 
        
        $output = json_decode(curl_exec($ch)); 


            // dd($output);
        // $  = $output->reference; 
        $order_paypage_url = $output->_links->payment->href;




        session()->save();

        /*echo "<!DOCTYPE html>
        <html>
        <script type=\"text/javascript\">
        window.location = \"$paymentLink\";

        </script>
        </html>";*/

        header("Location: " . $order_paypage_url);                     // execute redirect
        exit;


    }

    public static function check_callback($orderRef, $payment_type)
    {
        $outlet = "adbe5328-aa64-4f4b-a353-a2d027f33ca6";
        $apikey = "NDcwNTc5NmItNmZiZC00NjRjLTg3OTEtZmM5ZGZjMWIwMDk4OmM2MWZjMmRhLWJmYjgtNGQzNy04MmQ4LTZjNDk1YzQ0MmJjNA==";   // enter your API key here
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, "https://api-gateway.ngenius-payments.com/identity/auth/access-token"); 

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "accept: application/vnd.ni-identity.v1+json",
            "authorization: Basic ".$apikey,
            "content-type: application/vnd.ni-identity.v1+json"
        )); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        curl_setopt($ch, CURLOPT_POST, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS,  "{\"realmName\":\"NetworkInternational\"}"); 
        $output = json_decode(curl_exec($ch)); 
        $access_token = $output->access_token;


        /////////////////////order status//////////////////////////////
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api-gateway.ngenius-payments.com/transactions/outlets/".$outlet."/orders/".$_GET['ref'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "accept: application/vnd.ni-payment.v2+json",
            "authorization: Bearer ".$access_token
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            //echo "cURL Error #:" . $err;
           
            // return $err;
        } else {
        //pre_list($response);
        // return $response;
            
        }

        $orderStatusResponse = json_decode($response);

        if ($orderStatusResponse->_embedded->payment[0]->state == "FAILED") {
            // fail or cancel or incomplete
            Session::forget('payment_data');
            flash(translate('Payment incomplete'))->error();
            return redirect()->route('home');

        } else if ($orderStatusResponse->_embedded->payment[0]->state == "CAPTURED") {
            // success

            $payment = json_encode($orderStatusResponse);

            //dd($payment_type, Session::get('order_id'),Session::get('payment_data'), $payment);

            if ($payment_type == 'cart_payment') {
                $checkoutController = new CheckoutController;
                
                return $checkoutController->checkout_done(session()->get('order_id'), $payment);
            }

            if ($payment_type == 'wallet_payment') {
                $walletController = new WalletController;
                return $walletController->wallet_payment_done(Session::get('payment_data'), $payment);
            }

            if ($payment_type == 'customer_package_payment') {
                $customer_package_controller = new CustomerPackageController;
                return $customer_package_controller->purchase_payment_done(session()->get('payment_data'), $payment);
            }

            if ($payment_type == 'seller_package_payment') {
                $seller_package_controller = new \App\Http\Controllers\SellerPackageController;
                return $seller_package_controller->purchase_payment_done(session()->get('payment_data'), $payment);
            }

        }
    }

    public static function invokeCurlRequest($type, $url, $headers, $post)
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        if ($type == "POST") {

            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

        }

        $server_output = curl_exec($ch);
        // print_r($server_output);
        // exit();
        curl_close($ch);

        return $server_output;

    }
    public static function ngenius_make_payment($callback_url, $payment_type, $amount,$order_id)
    {
        $order = Order::where('id',$order_id)->first();
        $shipping_info = json_decode($order->shipping_address);
        // $shipping_info = json_decode($shipping_info)
        $shipping_charge_amount = $order->shipping_cost;
        // dd(json_decode($shipping_info));
        $postData = new \StdClass(); 
        $postData->action = "SALE"; 
        $postData->emailAddress = (!is_null($shipping_info->email)) ? $shipping_info->email : ''; 
        $postData->amount = new \StdClass();
        $postData->amount->currencyCode = "AED"; 
        // $postData->amount->value = 100*1;
       $postData->amount->value = $amount;

        $postData->shippingAddress= new \StdClass();
        $postData->shippingAddress->firstName= (!is_null($shipping_info->name)) ? $shipping_info->name : ''; 
        // $postData->shippingAddress->lastName= 'Jasem'; 
        $postData->shippingAddress->address1= (!is_null($shipping_info->address)) ? $shipping_info->address : ''; 
        // $postData->shippingAddress->city= (!is_null($shipping_info['emirate'])) ? $shipping_info['emirate'] : ''; 

        $postData->shippingAddress->countryCode= 'UAE'; 

        
        $postData->merchantAttributes = new \StdClass();
        $postData->merchantAttributes->redirectUrl = $callback_url;
       
       
        $postData->merchantDefinedData= new \StdClass();
        $postData->merchantDefinedData->shipping_total =  ($shipping_charge_amount) ? $shipping_charge_amount : 0;  
       
        // $postData->merchantDefinedData->city2= (!is_null($shipping_info['area'])) ? $shipping_info['area'] : '';  
        
        $postData->merchantDefinedData->mobile= (!is_null($shipping_info->phone)) ? $shipping_info->phone : '';  
       

        $postData->merchantAttributes->skipConfirmationPage = true; 

        $access_token = self::getAccessToken();
        $outlet = "adbe5328-aa64-4f4b-a353-a2d027f33ca6";
        // $outlet = "b604f1af-1928-4b92-9506-02ad6483ce3a";
        $json = json_encode($postData);
        $ch = curl_init(); 
        
        curl_setopt($ch, CURLOPT_URL, "https://api-gateway.ngenius-payments.com/transactions/outlets/".$outlet."/orders"); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer ".$access_token, 
        "Content-Type: application/vnd.ni-payment.v2+json", 
        "Accept: application/vnd.ni-payment.v2+json")); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        curl_setopt($ch, CURLOPT_POST, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json); 
        
        $output = json_decode(curl_exec($ch)); 

        $order->payment_reference_id = $output->reference;
        $order->save();
            // dd($output);
        // $  = $output->reference; 
        $order_paypage_url = $output->_links->payment->href;

            Log::info(json_encode($order_paypage_url));
         Log::info(json_encode($output));  
        

        // session()->save();

        /*echo "<!DOCTYPE html>
        <html>
        <script type=\"text/javascript\">
        window.location = \"$paymentLink\";

        </script>
        </html>";*/

        header("Location: " . $order_paypage_url);                     // execute redirect
        exit;


    }

    public static function ngenius_check_callback($orderRef, $payment_type)
    {
        $outlet = "adbe5328-aa64-4f4b-a353-a2d027f33ca6";
        $apikey = "NDcwNTc5NmItNmZiZC00NjRjLTg3OTEtZmM5ZGZjMWIwMDk4OmM2MWZjMmRhLWJmYjgtNGQzNy04MmQ4LTZjNDk1YzQ0MmJjNA==";   // enter your API key here
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, "https://api-gateway.ngenius-payments.com/identity/auth/access-token"); 

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "accept: application/vnd.ni-identity.v1+json",
            "authorization: Basic ".$apikey,
            "content-type: application/vnd.ni-identity.v1+json"
        )); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        curl_setopt($ch, CURLOPT_POST, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS,  "{\"realmName\":\"NetworkInternational\"}"); 
        $output = json_decode(curl_exec($ch)); 
        $access_token = $output->access_token;


        /////////////////////order status//////////////////////////////
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api-gateway.ngenius-payments.com/transactions/outlets/".$outlet."/orders/".$_GET['ref'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "accept: application/vnd.ni-payment.v2+json",
            "authorization: Bearer ".$access_token
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            //echo "cURL Error #:" . $err;
           
            // return $err;
        } else {
        //pre_list($response);
        // return $response;
            
        }

        $orderStatusResponse = json_decode($response);

        if ($orderStatusResponse->_embedded->payment[0]->state == "FAILED") {
            // fail or cancel or incomplete
            Session::forget('payment_data');
            flash(translate('Payment incomplete'))->error();
            return redirect()->route('home');

        } else if ($orderStatusResponse->_embedded->payment[0]->state == "CAPTURED") {
            // success

            $payment = json_encode($orderStatusResponse);

            //dd($payment_type, Session::get('order_id'),Session::get('payment_data'), $payment);

            if ($payment_type == 'cart_payment') {
                $checkoutController = new CheckoutController;
                $order = Order::where('code',$_GET['ref'])->first();
                return $checkoutController->checkout_done($order->id, $payment,1);
            }
        }
    }
}
