<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HomePageViewCategoriesSection2 extends Model
{
    //
    protected $table = 'home_page_view_categories_section_2';
}
