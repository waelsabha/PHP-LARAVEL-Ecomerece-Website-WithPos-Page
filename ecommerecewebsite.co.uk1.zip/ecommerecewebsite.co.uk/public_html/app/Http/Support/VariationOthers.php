<?php
namespace App\Http\Support;

class VariationOthers
{

    public static function variaionValueTemplete($val)
    {
        $str = 'aaaa';

        return $str;
    }
}

