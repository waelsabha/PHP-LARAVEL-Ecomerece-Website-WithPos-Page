<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Category;
use App\Http\Controllers\PaypalController;
use App\Http\Controllers\InstamojoController;
use App\Http\Controllers\ClubPointController;
use App\Http\Controllers\StripePaymentController;
use App\Http\Controllers\PublicSslCommerzPaymentController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AffiliateController;
use App\Http\Controllers\PaytmController;
use App\Order;
use App\BusinessSetting;
use App\Coupon;
use App\CouponUsage;
use App\User;
use App\Address;
use App\CartDetail;
use App\CartList;
use App\Country;
use App\Currency;
use App\PickupPoint;
use App\Models\Cart;
use PDF;
use Mail;
use App\Mail\InvoiceEmailManager;
use App\Models\OrderDetail;
use App\Models\Product;
use App\Models\ProductStock;
use App\ShippingCharge;
use Session;
use App\Utility\PayhereUtility;
use Illuminate\Support\Facades\DB;
use SMSGlobal\Credentials;
use SMSGlobal\Resource\Sms;
use App\Utility\verifyEmail;
use App\Postcodelatlng;
use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Facades\Log;
use Postpay\Exceptions\RESTfulException;



class CheckoutController extends Controller
{

    public function __construct()
    {
        //
        update_all_stock_from_pos();
        // update_cartDb_to_cartSession();
    }

    //check the selected payment gateway and redirect to that controller accordingly
    public function checkout(Request $request)
    {
        // dd($request);
        // dd($request->session()->get('cart'));
        if ($request->payment_option != null) {
            // dd($request->session()->get('shipping'));
            if ($request->session()->get('cart') == null)
            {
                flash(translate('Your cart is empty.'))->warning();
                return back();
            }

            
            $orderController = new OrderController;
            $orderController->store($request);
            $order = Order::findOrFail($request->session()->get('order_id'));
    
            $request->session()->put('payment_type', 'cart_payment');

            if ($request->session()->get('order_id') != null) {
                if ($request->payment_option == 'paypal') {
                    $paypal = new PaypalController;
                    return $paypal->getCheckout();
                } elseif ($request->payment_option == 'stripe') {
                    $stripe = new StripePaymentController;
                    return $stripe->stripe();
                } elseif ($request->payment_option == 'sslcommerz') {
                    $sslcommerz = new PublicSslCommerzPaymentController;
                    return $sslcommerz->index($request);
                } elseif ($request->payment_option == 'instamojo') {
                    $instamojo = new InstamojoController;
                    return $instamojo->pay($request);
                } elseif ($request->payment_option == 'razorpay') {
                    $razorpay = new RazorpayController;
                    return $razorpay->payWithRazorpay($request);
                } elseif ($request->payment_option == 'paystack') {
                    $paystack = new PaystackController;
                    return $paystack->redirectToGateway($request);
                } elseif ($request->payment_option == 'voguepay') {
                    $voguePay = new VoguePayController;
                    return $voguePay->customer_showForm();
                } elseif ($request->payment_option == 'twocheckout') {
                    $twocheckout = new TwoCheckoutController;
                    return $twocheckout->index($request);
                } elseif ($request->payment_option == 'payhere') {
                    $order = Order::findOrFail($request->session()->get('order_id'));

                    $order_id = $order->id;
                    $amount = $order->grand_total;
                    $first_name = json_decode($order->shipping_address)->name;
                    $last_name = 'X';
                    $phone = json_decode($order->shipping_address)->phone;
                    $email = json_decode($order->shipping_address)->email;
                    $address = json_decode($order->shipping_address)->address;
                    $city = json_decode($order->shipping_address)->city;

                    return PayhereUtility::create_checkout_form($order_id, $amount, $first_name, $last_name, $phone, $email, $address, $city);
                } else if ($request->payment_option == 'ngenius') {
                    $ngenius = new NgeniusController();
                    return $ngenius->pay();
                    // $pay = $this->auth_2();
                    // return redirect()->to($pay);
                } 
                else if ($request->payment_option == 'cashew') {
                    $cashew = new CashewController();
                    return $cashew->pay($order->id);
                } 
                
                
                
                
                
                else if ($request->payment_option == 'flutterwave') {
                    $flutterwave = new FlutterwaveController();
                    return $flutterwave->pay();
                }
                elseif($request->payment_option == 'postpay'){
                    $postpay = new PostPayController();
                    return $postpay->postPayCheckout();
                }
                 else if ($request->payment_option == 'mpesa') {
                    $mpesa = new MpesaController();
                    return $mpesa->pay();
                } elseif ($request->payment_option == 'paytm') {
                    $paytm = new PaytmController;
                    return $paytm->index();
                } elseif ($request->payment_option == 'cash_on_delivery') {
                    $request->session()->put('cart', collect([]));
                    // $request->session()->forget('order_id');
                    $request->session()->forget('delivery_info');
                    $request->session()->forget('coupon_id');
                    $request->session()->forget('coupon_discount');
                    $order = Order::findOrFail(Session::get('order_id'));
                    $order_details = OrderDetail::where('order_id',$order->id)->first();

                    $pdf = PDF::setOptions([
                        'isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true,
                        'logOutputFile' => storage_path('logs/log.htm'),
                        'tempDir' => storage_path('logs/')
                    ])->loadView('invoices.customer_invoice', compact('order'));
                        $output = $pdf->output();
                        file_put_contents('public/invoices/'.'Order#'.$order->code.'.pdf', $output);
        
                        
                        if($order_details->shipping_type == 'home_delivery')
                        {
                            $array['shipping_type'] = $order_details->shipping_type;
        
                        }
                        else{
                            $array['shipping_type'] = $order_details->shipping_type;
                            $pick_up_address = PickupPoint::where('id',$order_details->pickup_point_id)->first();
                            $array['pickup_address'] = $pick_up_address->address;
                            $array['phone']  = $pick_up_address->phone;
                        }
                        $array['code'] = $order->code;
                        $array['order'] = $order;
        
                        // dd($array['order']);
                        $array['order_details'] = $order_details;
                        $array['view'] = 'emails.invoice';
                        $array['subject'] = 'Order Placed - Biri Trading UK LTD';
                        $array['from'] = env('MAIL_USERNAME');
                        $array['content'] = translate('A new order has been placed. Please check the attached invoice.');
                        $array['file'] = 'public/invoices/Order#'.$order->code.'.pdf';
                        $array['file_name'] = 'Order#'.$order->code.'.pdf';
                        Log::info('trying to send email here');
                        
                            try {
                                Log::info('try');
                                if(is_null($order->user_id)){

                                $email = json_decode($order->shipping_address)->email;
                                $email_info = env('EMAIL_INFO');
                                $email_it = env('EMAIL_IT');
                                $email_more = env('EMAIL_MORE');
                                $emai_marktng = env('EMAIL_MARKETING');
                                 $email_alternate = env('EMAIL_ALTERNATE');
                                
                                $send_to = [$email];
                                $bcc = [$email_info,$email_it,$email_more,$emai_marktng, $email_alternate];
                                Log::info('before mail send');
                                    Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                Log::info('email send');
                           
 
                                }
                                else{
                                    Log::info(\App\User::find($order->user_id)->email);
                                    $email = \App\User::find($order->user_id)->email;
                                    $email_info = env('EMAIL_INFO');
                                    $email_it = env('EMAIL_IT');
                                    $email_more = env('EMAIL_MORE');
                                    $emai_marktng = env('EMAIL_MARKETING');
                                     $email_alternate = env('EMAIL_ALTERNATE');
                                
                                    $send_to = [$email];
                                    $bcc = [$email_info,$email_it,$email_more,$emai_marktng,$email_alternate];
                                            Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                   
								 
                                    Log::info('send');
                                }
                                

                                $phone = json_decode($order->shipping_address)->phone;
                                $explode = explode(',',$phone);
                                $text = 'Dear Customer, your  order ('.$order->code.') has been successfully placed.We are preparing your order and we will inform you when it is shipped.';
                                if($order->country_id == '230')
                                {
                                    try{
                                        //$this->send_message($explode[0],$text);
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                    }
                                    
                                }
                                

                            } catch (\Exception $e) {
                                Log::info($e);
                            }

                    try {
                        Log::info('Sending to api fn');
                        $payment = 'not_paid';
                        $get = $this->apiDataToPos($order->id,$payment);
                        Log::info('sale invoice updated in pos');
                    }
                    catch(\Exception $e)
                    {
                        Log::info('Could not update in pos');
                    }
                     $sendcloudshipping = new SendcloudController();
                    return  $sendcloudshipping->sendlabel($order->id);
                    //flash(translate("Your order has been placed successfully"))->success();
                   // return redirect()->route('order_confirmed');
                } elseif ($request->payment_option == 'wallet') {
                    $user = Auth::user();
                    $user->balance -= Order::findOrFail($request->session()->get('order_id'))->grand_total;
                    $user->save();
                    return $this->checkout_done($request->session()->get('order_id'), null);
                } else {
                    $order = Order::findOrFail($request->session()->get('order_id'));
                    $order->manual_payment = 1;
                    $order->save();

                    $request->session()->put('cart', collect([]));
                    // $request->session()->forget('order_id');
                    $request->session()->forget('delivery_info');
                    $request->session()->forget('coupon_id');
                    $request->session()->forget('coupon_discount');
                       $sendcloudshipping = new SendcloudController();
                    return  $sendcloudshipping->sendlabel($order->id);
                    // flash(translate('Your order has been placed successfully. Please submit payment information from purchase history'))->success();
                    // return redirect()->route('order_confirmed');
                }
            }
        } else {
            flash(translate('Select Payment Option.'))->warning();
            return back();
        }
    }

    //redirects to this method after a successfull checkout
    public function checkout_done($order_id, $payment,$mobile_app=0)
    {
        $order = Order::findOrFail($order_id);
        $order->payment_status = 'paid';
        $order->payment_details = $payment;
        $order->save();

        try {
            $payment = 'paid';
            //$get = $this->apiDataToPos($order->id,$payment);
            Log::info('sale invoice updated in pos');
            $phone = json_decode($order->shipping_address)->phone;
            $explode = explode(',',$phone);
            $text = 'Dear Customer, your  order ('.$order->code.') has been successfully placed.We are preparing your order and we will inform you when it is shipped.';
            if($order->country_id == '230')
                                {
                                    try{
                                        //$this->send_message($explode[0],$text);
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                    }
                                    
                                }
            
        }
        catch(\Exception $e)
        {
            Log::info('Could not update in pos');
        }
        if($mobile_app == 0)
        {
        foreach (Session::get('cart') as $key => $cartItem){
           
            if(env('ONE_DHM_DEAL') == 1)
                {
                    $flash_deal_product = \App\FlashDealProduct::where('product_id', $cartItem['id'])->first();
                    if($flash_deal_product)
                    {
                        if($flash_deal_product->product_id == $cartItem['id'])
                        {
                            $order->deal_availed = 1;
                        }
                    }
                }
            if($cartItem['one_dirham'] == 1)
            {
                $order->deal_availed = 1; 
            }

        }
        }
        $order->save();
        
        $user_update_one_aed_deal = 
            $order_details = OrderDetail::where('order_id',$order->id)->first();

            $pdf = PDF::setOptions([
                'isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true,
                'logOutputFile' => storage_path('logs/log.htm'),
                'tempDir' => storage_path('logs/')
            ])->loadView('invoices.customer_invoice', compact('order'));
                $output = $pdf->output();
                file_put_contents('public/invoices/'.'Order#'.$order->code.'.pdf', $output);

                
                if($order_details->shipping_type == 'home_delivery')
                {
                    $array['shipping_type'] = $order_details->shipping_type;

                }
                else{
                    $array['shipping_type'] = $order_details->shipping_type;
                    $pick_up_address = PickupPoint::where('id',$order_details->pickup_point_id)->first();
                    $array['pickup_address'] = $pick_up_address->address;
                    $array['phone']  = $pick_up_address->phone;
                }
                $array['code'] = $order->code;
                $array['order'] = $order;

                // dd($array['order']);
                $array['order_details'] = $order_details;
                $array['view'] = 'emails.invoice';
                $array['subject'] = 'Order Placed -Biri Trading UK LTD';
                $array['from'] = env('MAIL_USERNAME');
                $array['content'] = translate('A new order has been placed. Please check the attached invoice.');
                $array['file'] = 'public/invoices/Order#'.$order->code.'.pdf';
                $array['file_name'] = 'Order#'.$order->code.'.pdf';

                
                    try {
                        Log::info('checkout received trying to send email');
                        if(is_null($order->user_id)){

                                $email = json_decode($order->shipping_address)->email;
                            
                                $email_info = env('EMAIL_INFO');
                                $email_it = env('EMAIL_IT');
                                $email_more = env('EMAIL_MORE');
                                $email_accounts = env('EMAIL_ACC');
                                $emai_marktng = env('EMAIL_MARKETING');
                                $email_alternate = env('EMAIL_ALTERNATE');
                                $send_to = [$email];
                                $bcc = [$email_info,$email_it,$email_more,$emai_marktng,$email_alternate];
								 Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                            
                                Log::info('send to guest user - '.$email);
                            }
                            else
                            {
                                $email = \App\User::find($order->user_id)->email;
                            
                                $email_info = env('EMAIL_INFO');
                                $email_it = env('EMAIL_IT');
                                $email_more = env('EMAIL_MORE');
                                $emai_marktng = env('EMAIL_MARKETING');
                                $email_alternate = env('EMAIL_ALTERNATE');
                                $send_to = [$email];
                                $bcc = [$email_info,$email_it,$email_more,$emai_marktng,$email_alternate];
                                Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));

                        
                                Log::info('send to registered user - '.$email);
                            }
                                
                    } catch (\Exception $e) {
                        Log::info(json_encode($e));
                        Log::info('exception');
                    }
                
        

        if (\App\Addon::where('unique_identifier', 'affiliate_system')->first() != null && \App\Addon::where('unique_identifier', 'affiliate_system')->first()->activated) {
            $affiliateController = new AffiliateController;
            $affiliateController->processAffiliatePoints($order);
        }

        if (\App\Addon::where('unique_identifier', 'club_point')->first() != null && \App\Addon::where('unique_identifier', 'club_point')->first()->activated) {
            $clubpointController = new ClubPointController;
            $clubpointController->processClubPoints($order);
        }
        if (\App\Addon::where('unique_identifier', 'seller_subscription')->first() == null || !\App\Addon::where('unique_identifier', 'seller_subscription')->first()->activated) {
            if (BusinessSetting::where('type', 'category_wise_commission')->first()->value != 1) {
                $commission_percentage = BusinessSetting::where('type', 'vendor_commission')->first()->value;
                foreach ($order->orderDetails as $key => $orderDetail) {
                    $orderDetail->payment_status = 'paid';
                    $orderDetail->save();
                    if ($orderDetail->product->user->user_type == 'seller') {
                        $seller = $orderDetail->product->user->seller;
                        $seller->admin_to_pay = $seller->admin_to_pay + ($orderDetail->price * (100 - $commission_percentage)) / 100 + $orderDetail->tax + $orderDetail->shipping_cost;
                        $seller->save();
                    }
                }
            } else {
                foreach ($order->orderDetails as $key => $orderDetail) {
                    $orderDetail->payment_status = 'paid';
                    $orderDetail->save();
                    if ($orderDetail->product->user->user_type == 'seller') {
                        $commission_percentage = $orderDetail->product->category->commision_rate;
                        $seller = $orderDetail->product->user->seller;
                        $seller->admin_to_pay = $seller->admin_to_pay + ($orderDetail->price * (100 - $commission_percentage)) / 100 + $orderDetail->tax + $orderDetail->shipping_cost;
                        $seller->save();
                    }
                }
            }
        } else {
            foreach ($order->orderDetails as $key => $orderDetail) {
                $orderDetail->payment_status = 'paid';
                $orderDetail->save();
                if ($orderDetail->product->user->user_type == 'seller') {
                    $seller = $orderDetail->product->user->seller;
                    $seller->admin_to_pay = $seller->admin_to_pay + $orderDetail->price + $orderDetail->tax + $orderDetail->shipping_cost;
                    $seller->save();
                }
            }
        }

        $order->commission_calculated = 1;
        $order->save();

         if($mobile_app == 1)
        {
            return view('frontend.app_confirm_order', compact('order'));
        }
        else
        {
            Session::put('cart', collect([]));
            // Session::forget('order_id');
            Session::forget('payment_type');
            Session::forget('delivery_info');
            Session::forget('coupon_id');
            Session::forget('coupon_discount');
            
    
            flash(translate('Payment completed'))->success();
            return view('frontend.order_confirmed', compact('order'));
        }
    }

    public function get_shipping_info(Request $request)
    {
       // dd($request);
       
        Log::info('Shipping info page');
        try{
            Log::info('IP Address --'.$request->ip());      
            Log::info($request->server('HTTP_USER_AGENT')); 
        }
        catch(\Exception $e)
        {

        }
        // dd('here');
        $added_one_dirham = 0;
        $free_gift_count = 0;
        $other_product_count = 0;

        if (Session::has('cart') && count(Session::get('cart')) > 0) {
            foreach (Session::get('cart') as $key => $cartItem){

                $check_product = Product::where('id',$cartItem['id'])->first();
                
                if($check_product)
                {
                   
                    if($check_product->published === '0')
                    {
                        // dd($check_product);
                        if(Session::has('uid'))
                        {
                            $cart_list = CartList::where('unique_id',Session::get('uid'))->first();
                            if($cart_list)
                            {
                                $cart_details = CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->first();
                                if($cart_details)
                                {
                                    CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->delete();
                                }
                            }
                        }
                        unset($cart_session[$key]);
                        
                        Session::forget('cart');
                        Session::put('cart', $cart_session);
                        flash('Some items removed, since they are not available.')->warning();
                        
                        // dd(Session::get('cart'));
                    }
                }

                if(isset($cartItem['free_gift']) &&($cartItem['free_gift'] != "" || $cartItem['free_gift'] != null) )
                {
                    $free_gift_count += 1;
                }
                else
                {
                    $other_product_count += 1; 
                }
            }
            Session::save();
            if($other_product_count == 0)
            {
                flash(translate('Add other than free item to the cart.'))->error();
                return back();
            }

            if(env('ONE_DHM_DEAL') == 1)
            {
                if(Auth::check())
                {
                    // dd('here');
                }
                else{
                    flash(translate('Login to avail 1 AED Deal'))->error();
                    return back();
                }
                $total = 0;
                foreach (Session::get('cart') as $key => $cartItem){
                $flash_deal_product = \App\FlashDealProduct::where('product_id', $cartItem['id'])->first();
                if($flash_deal_product)
                {
                    if($flash_deal_product != null && $flash_deal_product->status == 1  && strtotime(date('d-m-Y')) >= $flash_deal_product->start_date && strtotime(date('d-m-Y')) <= $flash_deal_product->end_date)
                    {


                        if($cartItem['quantity'] > 1)
                        {
                            flash(translate('Only one flash deal item can be choosen.'))->warning();
                            return back();
                        }

                       
                    }
                }

                $total += $cartItem['price']*$cartItem['quantity'];
                if(env('ONE_DHM_DEAL') == 1)
                    {
                        if($flash_deal_product)
                        {
                            if($flash_deal_product->product_id == $cartItem['id'])
                            {
                                $added_one_dirham = 1;
                            }
                        }
                    }
                if($cartItem['one_dirham'] == 1)
                {
                    $added_one_dirham = 1;
                }

                }
                if($added_one_dirham == 1)
                {
                if($total < 100)
                        {
                            flash(translate('Please make your cart 100 gbp'))->warning();
                            return back();
                        }

                }        
                
            }
        
            $categories = Category::all();

            if(Session::has('currency_code')){
                $currency_code = Session::get('currency_code');
            }
            else{
                $currency_code = \App\Currency::findOrFail(\App\BusinessSetting::where('type', 'system_default_currency')->first()->value)->code;
            }
            
            $curr_db = Currency::where('code',$currency_code)->first();
            $country_id = $curr_db->country_id;
            
            $country = Country::where('id',$country_id)->first();
            $shipping_charges_db = Postcodelatlng::where('sc_country',$country_id)->where('sc_sts',1)->where('sc_color','!=','red')->get();
            
            $postcode = $shipping_charges_db;
           // $areas = $shipping_charges_db;
            $ab = 'skbjs ';
           //dd($postcode);
            // dd(rtrim($ab));
            $pick_up_points = PickupPoint::where('pick_up_status',1)->get();
            // return view('frontend.shipping_info_test', compact('categories','postcode','pick_up_points','shipping_charges_db','areas'));

           return view('frontend.shipping_info', compact('categories','postcode','pick_up_points','shipping_charges_db','country'));
            // return view('frontend.shipping_info', compact('categories','pick_up_points','shipping_charges_db','areas','country'));
        }
         
        flash(translate('Your cart is empty'))->success();
        return back();
    }

    public function getTownList(Request $request)
    {
        $select = $request->get('select');
        $value = $request->get('value');
        $dependent = $request->get('dependent');
        
        if($select == 'country')
        {
            $shipping_charges = ShippingCharge::where('sc_country',$value)->where('sc_color','!=','red')->groupBy('postcode')->get();
            $output = '<option value="">Select '.ucfirst($dependent).'</option>';
            foreach($shipping_charges as $row)
            {
                $output .= '<option  value="'.$row->postcode.'">'.$row->postcode.'</option>';
            }
            echo $output;
        }
        else
        {
            $shipping_charges = ShippingCharge::where('postcode',$value)->where('sc_color','!=','red')->get();
            $output = '<option value="">Select '.ucfirst($dependent).'</option>';
            foreach($shipping_charges as $row)
            {
                $output .= '<option  value="'.$row->sc_town.'">'.$row->sc_town.'</option>';
            }
            echo $output;
        }
        
        
        // return response()->json($shipping_charges);
        
    }

    public function getShippingcharge(Request $request)
    {   
        $address_id = $request->get('addressId');

        if(!is_numeric($address_id))
        {
           // $area = $request->get('area');
            
            //$shipping_charges_data = ShippingCharge::where('sc_town',$area)->first();
           $shipping_charges_data= Postcodelatlng::where('postcode',$request->state)->first();
            return response()->json($shipping_charges_data);

            
        }

        $addresses = Address::where('id',$address_id)->first();

        $shipping_charges_data = Postcodelatlng::where('id',$addresses->shipping_charges_id)->first();
        
        return response()->json($shipping_charges_data);
        if($shipping_charges_data->sc_color == 'red')
        {

        }
        else{

        }

    }

  public function store_shipping_info(Request $request)
    {
        
        Log::info('Delivery info page');
        try{
            Log::info('IP Address --'.$request->ip());      
            Log::info($request->server('HTTP_USER_AGENT')); 
        }
        catch(\Exception $e)
        {

        }
        $business_settings = \App\BusinessSetting::where('type', 'system_default_currency')->first();
                                    if ($business_settings != null) {
                                    
                                        $currency_default = \App\Currency::find($business_settings->value);
                                    
                                    }
                                    
                                    $code = \App\Currency::findOrFail(\App\BusinessSetting::where('type', 'system_default_currency')->first()->value)->code;
                                    if (Session::has('currency_code')) {
                                        $currency = \App\Currency::where('code', Session::get('currency_code', $code))->first();
                                        
                                    } else {
                                        $currency = \App\Currency::where('code', $code)->first();
                                        
                                    }
        $country_code = '+44';
        if($currency->code == 'BHD')
        {
            $country_code = '+973';
        }
        if($currency->code == 'SAR')
        {
            $country_code = '+966';
        }
        $added_one_dirham = 0;
        $local_pick_up = $request->local_pick_up;
        $pick_up = array();
        $shipping_charge = 0;
        $id_array = array();
        if (Session::has('cart') && count(Session::get('cart')) > 0) {
            if(env('ONE_DHM_DEAL') == 1)
            {
                $total = 0;
                foreach (Session::get('cart') as $key => $cartItem){
                $flash_deal_product = \App\FlashDealProduct::where('product_id', $cartItem['id'])->first();
                if($flash_deal_product)
                {
                    if($flash_deal_product != null && $flash_deal_product->status == 1  && strtotime(date('d-m-Y')) >= $flash_deal_product->start_date && strtotime(date('d-m-Y')) <= $flash_deal_product->end_date)
                    {


                        if($cartItem['quantity'] > 1)
                        {
                            flash(translate('Only one flash deal item can be choosen.'))->warning();
                            return back();
                        }

                       
                    }
                }
                if(env('ONE_DHM_DEAL') == 1)
                {
                    if($flash_deal_product)
                    {
                        if($flash_deal_product->product_id == $cartItem['id'])
                        {
                            $added_one_dirham = 1;
                        }
                    }
                }
                if($cartItem['one_dirham'] == 1)
                {
                    $added_one_dirham = 1;
                }


                $total += $cartItem['price']*$cartItem['quantity'];

                }
                if($added_one_dirham == 1)
                {
                    if($total < 100)
                        {
                            flash(translate('Please make your cart 100 AED'))->warning();
                            return back();
                        }
                        if(Auth::user())
                        {
                            $all_orders = Order::where('user_id',Auth::user()->id)->where('deal_availed',1)->get();
                            foreach($all_orders as $order_check)
                            {
                                if($order_check->deal_availed == 1)
                                {
                                    flash(translate("Already availed the offer"))->warning();
                                    return back();
                                }
                                
                            }
                        }

                        else
                        {
                            $all_orders = Order::where('deal_availed',1)->get();
                            foreach($all_orders as $order_check)
                            {
                                if($order_check->deal_availed == 1)
                                {
                                    $availed_user_email = json_decode($order_check->shipping_address);
                                    if($availed_user_email->email == $request->email)
                                    {
                                        flash(translate("Already availed the offer"))->warning();
                                        return back();
                                    }
                                    
                                }
                                
                            }
                           
                        }
                
                }   
                        
                
                        
                        
                
            }
            foreach (Session::get('cart') as $key => $cartItem){
                $id_array[] = $cartItem['id'];
            }
        }
        if (Auth::check()) {
            
            if ($request->address_id == null) {
                flash(translate("Please add shipping address"))->warning();
                return back();
            }
            
            if($request->local_pick_up != 1)
            {
                if ($request->address_id == 0) {
                    flash(translate("Please Select a valid address"))->warning();
                    return back();
                }
                $address = Address::findOrFail($request->address_id);
                if($currency->code != 'BHD' && $currency->code != 'SAR')
                {
                    //$shipping_charges = Postcodelatlng::where('postcode',$request->postcode)->first();
                   // $shipping_charge = $shipping_charges->sc_rate_5kg;
                        $shipping_charge='6';
                        $total_quantity = 0;
                        foreach (Session::get('cart') as $key => $cartItem){
                            $total_quantity += $cartItem['quantity'];
                        }
                        if($total_quantity > 1){
                            $shipping_charge_rest= ($total_quantity-1) * 3;
                            $shipping_charge += $shipping_charge_rest;
                            $shipping_charge_tax=($shipping_charge*20)/100;
                        }
                }
                else
                {
                    $shipping_charge = shippingPrice($id_array);
                    $shipping_charge_tax=($shipping_charge*20)/100;
                }
                

                $data['name'] = Auth::user()->name;
                $data['email'] = Auth::user()->email;
                $data['address'] = $address->address;
                $data['building_name'] = $address->building_name;
                $data['flat_no'] = $address->flat_no;
                $data['country'] = $address->country;
                $data['postcode'] = $address->postcode;
               // $data['area'] = $address->area;

                $data['landmark'] = $address->landmark;
               // $data['phone'] = $country_code.$address->phone;
               $data['phone'] =$address->phone;
                $data['checkout_type'] = $request->checkout_type;
                Log::info('Name: '.$data['name'].', email: '.$data['email'].', address: '.$data['address'].', bulding name: '.$data['building_name'].', flat no: '. $data['flat_no'].
                            ', country: '.$data['country'].', postcode: '.$data['postcode'].', phone: '.$data['phone'].', landmark: '.$data['landmark']);
            }

            else{
                
                $local_pick_up = $request->local_pick_up;
                $pick_up = array();
                if(config('helper.pickup') != "DEACTIVATE")
                {
                    if($local_pick_up == 1)
                    {
                        $pick_up = PickupPoint::where('id',$request->address_id)->first();
                        $data['name'] = Auth::user()->name;
                        $data['email'] = Auth::user()->email;
                        $data['address'] = $pick_up->address;
                        $data['pick_up_point_id'] = $pick_up->id;
                        
                        $data['phone'] = $pick_up->phone;
                        $data['checkout_type'] = $request->checkout_type;

                        $user_det = User::where('id',Auth::user()->id)->first();
                        if($user_det->phone == null)
                        {
                            $user_det->phone = $request->user_phone;
                            $user_det->save();
                        }
                        
                    
                    }
                }
                else
                {
                    
                    flash(translate("Pick up option is not available"))->error();
                    return back();
                }
            }
            
        } else {

            
            
            $validatedData = Validator::make($request->all(), [
                'address' => 'required',
                'email' => 'required|email',
                'name' => 'required',
                'phone' => 'required',
                // 'state' => 'required|not_in:0',
                //'town' => 'required|not_in:0',
                'building_name' => 'required',
                'flat_no' => 'required',
            ]);

            

            if ($validatedData->fails())
            {
                // flash($validatedData->errors())->error();
                return redirect()->back()->withErrors($validatedData->errors());
            }
                
        
                
            if($request->local_pick_up != 1)
            {
                if($currency->code != 'BHD' && $currency->code != 'SAR')
                {
                        $shipping_charges = Postcodelatlng::where('postcode',$request->town)->first();
                        $shipping_charge='6';
                        $total_quantity = 0;
                        foreach (Session::get('cart') as $key => $cartItem){
                            $total_quantity += $cartItem['quantity'];
                        }
                        if($total_quantity > 1){
                            $shipping_charge_rest= ($total_quantity-1) * 3;
                            $shipping_charge += $shipping_charge_rest;
                            $shipping_charge_tax=($shipping_charge*20)/100;

                        }

                        
                }
                else
                {
                    $shipping_charge = shippingPrice($id_array);
                    $shipping_charge_tax=($shipping_charge*20)/100;
                }
                

                $data['name'] = $request->name;
                $data['email'] = $request->email;
                $data['address'] = $request->address;
                $data['country'] = $request->country;
                $data['postcode'] = $request->state;
                //$data['area'] = $request->town;
                $data['building_name'] = $request->building_name;
                $data['flat_no'] = $request->flat_no;
                $data['landmark'] = $request->landmark;
                $data['phone'] = $country_code.$request->phone;
                $data['checkout_type'] = $request->checkout_type;

                Log::info('Name: '.$data['name'].', email: '.$data['email'].', address: '.$data['address'].', bulding name: '.$data['building_name'].', flat no: '. $data['flat_no'].
                            ', country: '.$data['country'].', postcode: '.$data['postcode'].', phone: '.$data['phone'].', landmark: '.$data['landmark']);
            }
            else{
               
                
                if($local_pick_up == 1)
                {
                    flash('Cannot use this option')->error();
                    return redirect()->back();
                    $pick_up = PickupPoint::where('id',$request->address_id)->first();
                    $data['name'] = $request->name;
                    $data['email'] = $request->email;
                    $data['address'] = $pick_up->address;
                    $data['building_name'] = $request->building_name;
                    $data['flat_no'] = $request->flat_no;
                    $data['pick_up_point_id'] = $pick_up->id;
                    $data['phone'] = $pick_up->phone;
                    $data['checkout_type'] = $request->checkout_type;
                
                }
            }
        }

        $shipping_info = $data;
        $request->session()->put('shipping_info', $shipping_info);
        if(Auth::check())
        {
            $ip = null;
            $user_id = Auth::user()->id;
            $cart_list = CartList::where('user_id',$user_id)->first();
            if($cart_list)
            {
                CartList::where('user_id',$user_id)->update(['shipping_address'=>json_encode($shipping_info)]);
            }
        }
        else 
        {
            $user_id = null;
            $ip = $request->ip();
            $cart_list = CartList::where('ip_address',$ip)->first();
            if($cart_list)
            {
                CartList::where('ip_address',$ip)->update(['shipping_address'=>json_encode($shipping_info)]);
            }
        }
        
        // json_encode($request->session()->get('shipping_info'));
        $online_payment_only = 0;
        $subtotal = 0;
        $tax = 0;
        $shipping = 0;
        $gift_wrap_val = 0;
        $newItem = collect();
        $carts = Session::get('cart', []);
        foreach ($carts as $key => $cartItem) {
        //    gift wrapper
        $newItem_add['gift_wrapper'] = 0;
            if(isset($request->gift_wrap))
            {
                foreach($request->gift_wrap as $key2 => $gift_wrap)
                {
                
                    if($key2 == $cartItem['id'])
                    {
                        if($gift_wrap == 'on')
                        {
                            $newItem_add['gift_wrapper'] = 1;

                        }
                        
                    }
                    
                }
            }
            
            if($newItem_add['gift_wrapper'] == 1)
            {
                
                $gift_wrap_val += env('GIFT_WRAPPER_AED');
            }
            $subtotal += ($cartItem['price'] * $cartItem['quantity']);
            $tax += $cartItem['tax'] * $cartItem['quantity'];

            
            $shipping += $cartItem['shipping'] * $cartItem['quantity'];
            $carts = array_merge($cartItem,$newItem_add);
            $newItem->push($carts);
            if(env('ONE_DHM_DEAL') == 1)
            {
                $flash_deal_product = \App\FlashDealProduct::where('product_id', $cartItem['id'])->first();
                if($flash_deal_product)
                {
                    if($flash_deal_product->product_id == $cartItem['id'])
                    {
                        $online_payment_only = 1;
                    }
                }
            }
            if($cartItem['one_dirham'] == 1)
                {
                    $online_payment_only = 1;
                }
        }
        if(Session::has('currency_code')){
            $currency_code = Session::get('currency_code');
        }
        else{
            $currency_code = \App\Currency::findOrFail(\App\BusinessSetting::where('type', 'system_default_currency')->first()->value)->code;
        }
        $curr_db = Currency::where('code',$currency_code)->first();
            
        $country = Country::where('id',$curr_db->country_id)->first();
        if($country->code == 'AE')
        {
            if($subtotal > env('FREE_DELIVERY_ABOVE'))
            {
                $shipping_charge = 0;
            }
        }
        
        $shipping_charge_tax=0;
        $total_shipping = $shipping+$shipping_charge+$shipping_charge_tax;

        $total = $subtotal + $total_shipping + $gift_wrap_val;
                
        if (Session::has('coupon_discount')) {
            $total -= Session::get('coupon_discount');
        }

        // if($total >= 5000)
        // {
        //     flash(translate('Order amount should not exceed 4999 AED.If your order is more than 4999 try ordering two or more times.'))->warning();
        //     return redirect()->back(); 
        // }
        // dd($carts);
       
        Session::put('cart', $newItem);
       
       return view('frontend.delivery_info',compact('local_pick_up','total_shipping','pick_up','online_payment_only'));
        // return view('frontend.payment_select', compact('total','local_pick_up','total_shipping','pick_up','online_payment_only'));
    }


    
   public function store_delivery_info(Request $request)
    {
        Log::info('Payment select page');
        try{
            Log::info('IP Address --'.$request->ip());      
            Log::info($request->server('HTTP_USER_AGENT')); 
        }
        catch(\Exception $e)
        {

        }
        if (Session::has('cart') && count(Session::get('cart')) > 0) {
            $cart = $request->session()->get('cart', collect([]));
            $cart = $cart->map(function ($object, $key) use ($request) {
                if (\App\Product::find($object['id'])->added_by == 'admin') {
                    if ($request['shipping_type_admin'] == 'home_delivery') {
                        $object['shipping_type'] = 'home_delivery';
                    } else {
                        $object['shipping_type'] = 'pickup_point';
                        $object['pickup_point'] = $request->pickup_point_id_admin;
                    }
                } else {
                    if ($request['shipping_type_' . \App\Product::find($object['id'])->user_id] == 'home_delivery') {
                        $object['shipping_type'] = 'home_delivery';
                    } else {
                        $object['shipping_type'] = 'pickup_point';
                        $object['pickup_point'] = $request['pickup_point_id_' . \App\Product::find($object['id'])->user_id];
                    }
                }
                return $object;
            });

            $request->session()->put('cart', $cart);

            $cart = $cart->map(function ($object, $key) use ($request) {
                $object['shipping'] = getShippingCost($key);
                return $object;
            });

            $request->session()->put('cart', $cart);


            $subtotal = 0;
            $tax = 0;
            $shipping = 0;
            $online_payment_only = 0;
            $shipping_tax=0;
            foreach (Session::get('cart') as $key => $cartItem) {
                $subtotal += $cartItem['price'] * $cartItem['quantity'];
                $tax += $cartItem['tax'] * $cartItem['quantity'];
                $shipping += $cartItem['shipping'] * $cartItem['quantity'];
                $shipping_tax += (($cartItem['shipping'] * $cartItem['quantity'])*20)/100;
                if(env('ONE_DHM_DEAL') == 1)
                {
                    $flash_deal_product = \App\FlashDealProduct::where('product_id', $cartItem['id'])->first();
                    // dd(Session::get('cart'));
                    if($flash_deal_product)
                    {
                        
                        if($flash_deal_product->product_id == $cartItem['id'])
                        {
                            $online_payment_only = 1;
                        }
                    }
                }
                if($cartItem['one_dirham'] == 1)
                {
                    $online_payment_only = 1;
                }
            }
            $total_shipping = $request->shipping_charge_final+$shipping+$shipping_tax;
            
            
            $total = $subtotal + $tax + $total_shipping;

            if(Session::has('currency_code')){
                $currency_code = Session::get('currency_code');
            }
            else{
                $currency_code = \App\Currency::findOrFail(\App\BusinessSetting::where('type', 'system_default_currency')->first()->value)->code;
            }
            $curr_db = Currency::where('code',$currency_code)->first();
                
            $country = Country::where('id',$curr_db->country_id)->first();
            if($country->code == 'AE')
            {
                Log::info('Shipping charge'.$request->shipping_charge_final);
                if($request->shipping_charge_final == 0 && $request->shipping_type_admin == 'home_delivery')
                {
                    Log::info('first if');
                    if($subtotal < env('FREE_DELIVERY_ABOVE'))
                    {
                        Log::info('first if inside if');
                        flash(translate('Please try again.'))->warning();
                        return redirect()->route('cart'); 
                    }
                }
                if($request->shipping_charge_final != 0 && $request->shipping_type_admin == 'home_delivery')
                {
                    Log::info('Second if');
                    if($subtotal > env('FREE_DELIVERY_ABOVE'))
                    {
                        Log::info('Second if inside if');
                        flash(translate('Please try again.'))->warning();
                        return redirect()->route('cart'); 
                    }
                }
               
            }
 

            $request->session()->put('shipping',  $total_shipping );
            
            if (Session::has('coupon_discount')) {
                $total -= Session::get('coupon_discount');
            }
            // dd($online_payment_only);
            
            $local_pick_up = $request->local_pick_up;
            return view('frontend.payment_select', compact('total','total_shipping','local_pick_up','online_payment_only'));
        } else {
            flash(translate('Your Cart was empty'))->warning();
            return redirect()->route('home');
        }
    }

    public function orderStatus()
    {
        $outlet = "adbe5328-aa64-4f4b-a353-a2d027f33ca6";
        $apikey = "NDcwNTc5NmItNmZiZC00NjRjLTg3OTEtZmM5ZGZjMWIwMDk4OmM2MWZjMmRhLWJmYjgtNGQzNy04MmQ4LTZjNDk1YzQ0MmJjNA==";   // enter your API key here
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, "https://api-gateway.ngenius-payments.com/identity/auth/access-token"); 

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "accept: application/vnd.ni-identity.v1+json",
            "authorization: Basic ".$apikey,
            "content-type: application/vnd.ni-identity.v1+json"
        )); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        curl_setopt($ch, CURLOPT_POST, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS,  "{\"realmName\":\"NetworkInternational\"}"); 
        $output = json_decode(curl_exec($ch)); 
        $access_token = $output->access_token;


        /////////////////////order status//////////////////////////////
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api-gateway.ngenius-payments.com/transactions/outlets/".$outlet."/orders/".$_GET['ref'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "accept: application/vnd.ni-payment.v2+json",
            "authorization: Bearer ".$access_token
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            //echo "cURL Error #:" . $err;
            // dd($err);
            return $err;
        } else {
        //pre_list($response);
        // dd($response);
            return $this->submit_shipping_data($response);
        }
    }

    public function get_payment_info(Request $request)
    {
       
        $subtotal = 0;
        $tax = 0;
        $shipping = 0;
        foreach (Session::get('cart') as $key => $cartItem) {
            $subtotal += $cartItem['price'] * $cartItem['quantity'];
            $tax += $cartItem['tax'] * $cartItem['quantity'];
            $shipping += $cartItem['shipping'] * $cartItem['quantity'];
        }
        
        $total = $subtotal + $tax + $shipping;

        if (Session::has('coupon_discount')) {
            $total -= Session::get('coupon_discount');
        }

        return view('frontend.payment_select', compact('total'));
    }

    public function apply_coupon_code(Request $request)
    {
        //dd($request->all());
        $coupon = Coupon::where('code', $request->code)->where('only_for_app',0)->first();

        if ($coupon != null) {
            if (strtotime(date('d-m-Y')) >= $coupon->start_date && strtotime(date('d-m-Y')) <= $coupon->end_date) {
                if (CouponUsage::where('user_id', Auth::user()->id)->where('coupon_id', $coupon->id)->first() == null || env('COUPON_ACTIVE') == $request->code ||
                     env('COUPON_ACTIVE2') == $request->code || env('COUPON_ACTIVE3') == $request->code) {
                    $coupon_details = json_decode($coupon->details);

                    if ($coupon->type == 'cart_base') {
                        $subtotal = 0;
                        $tax = 0;
                        $shipping = 0;
                        foreach (Session::get('cart') as $key => $cartItem) {
                            $subtotal += $cartItem['price'] * $cartItem['quantity'];
                            $tax += $cartItem['tax'] * $cartItem['quantity'];
                            $shipping += $cartItem['shipping'] * $cartItem['quantity'];
                        }
                        $sum = calculatePricePercentageBaseCurrency($subtotal) + $tax + $shipping;
                        
                        Log::info('sub total'.calculatePricePercentageBaseCurrency($subtotal));
                        
                        if ($sum > $coupon_details->min_buy) {
                            if ($coupon->discount_type == 'percent') {
                                $coupon_discount = ($sum * $coupon->discount) / 100;
                                if ($coupon_discount > $coupon_details->max_discount) {
                                    $coupon_discount = $coupon_details->max_discount;
                                }
                            } elseif ($coupon->discount_type == 'amount') {
                                $coupon_discount = $coupon->discount;
                            }
                            $request->session()->put('coupon_id', $coupon->id);
                            $request->session()->put('coupon_discount', $coupon_discount);
                            flash(translate('Coupon has been applied'))->success();
                        }
                    } elseif ($coupon->type == 'product_base') {
                        $coupon_discount = 0;
                        foreach (Session::get('cart') as $key => $cartItem) {
                            foreach ($coupon_details as $key => $coupon_detail) {
                                if ($coupon_detail->product_id == $cartItem['id']) {
                                    if ($coupon->discount_type == 'percent') {
                                        $coupon_discount += $cartItem['price'] * $coupon->discount / 100;
                                    } elseif ($coupon->discount_type == 'amount') {
                                        $coupon_discount += $coupon->discount;
                                    }
                                }
                            }
                        }
                        $request->session()->put('coupon_id', $coupon->id);
                        $request->session()->put('coupon_discount', $coupon_discount);
                        flash(translate('Coupon has been applied'))->success();
                    }
                } else {
                    flash(translate('You already used this coupon!'))->warning();
                }
            } else {
                flash(translate('Coupon expired!'))->warning();
            }
        } else {
            flash(translate('Invalid coupon!'))->warning();
        }
        return back();
    }

    public function remove_coupon_code(Request $request)
    {
        $request->session()->forget('coupon_id');
        $request->session()->forget('coupon_discount');
        return back();
    }

    public function order_confirmed()
    {
        $order = Order::findOrFail(Session::get('order_id'));

        $user_det = User::where('id',$order->user_id)->first();
        if($user_det)
        {
            $user_det->balance = $user_det->balance - $order->club_point_discount;
            $user_det->save();
        }
        // $array['order'] = $order;
        // dd($array['order']->orderDetails);
        Session::forget('club_point_discount');
        Session::forget('registration_bonus_discount');

        // dd(isset(json_decode($order->shipping_address)->pick_up_point_id));
        return view('frontend.order_confirmed', compact('order'));
    }

    public function auth_2()
    {
        $apikey = "NDcwNTc5NmItNmZiZC00NjRjLTg3OTEtZmM5ZGZjMWIwMDk4OmM2MWZjMmRhLWJmYjgtNGQzNy04MmQ4LTZjNDk1YzQ0MmJjNA==";   // enter your API key here
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, "https://api-gateway.ngenius-payments.com/identity/auth/access-token"); 

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "accept: application/vnd.ni-identity.v1+json",
            "authorization: Basic ".$apikey,
            "content-type: application/vnd.ni-identity.v1+json"
        )); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        curl_setopt($ch, CURLOPT_POST, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS,  "{\"realmName\":\"NetworkInternational\"}"); 
        $output = json_decode(curl_exec($ch)); 
        // dd($output);
        $access_token = $output->access_token;
        
        $data_return= $this->create_order($access_token);
        return $data_return;
    }

    public function create_order($access_token)
    {
            
        $postData = new \StdClass(); 
        $postData->action = "SALE"; 
        $postData->emailAddress = 'jasimogral@gmail.com'; 
        $postData->amount = new \StdClass();
        $postData->amount->currencyCode = "AED"; 
        $postData->amount->value = 100*1;
        //$postData->amount->value = 100*1;

        $postData->shippingAddress= new \StdClass();
        $postData->shippingAddress->firstName= 'Mohammed'; 
        $postData->shippingAddress->lastName= 'Jasem'; 
        $postData->shippingAddress->address1= 'jnnkknjnk'; 
        $postData->shippingAddress->city= 'Dubai'; 

        $postData->shippingAddress->countryCode= 'AE'; 

        // $postData->merchantDefinedData= new StdClass();
        // $postData->merchantDefinedData->wgt_total= $data['ps_wgt_total']; 
        // $postData->merchantDefinedData->shipping_total= $data['ps_shipping_total']; 
        // $postData->merchantDefinedData->zip_code= $data['ps_zip']; 
        // $postData->merchantDefinedData->city2= $data['ps_town2']; 
        // $postData->merchantDefinedData->address2= $data['ps_adr2']; 
        // $postData->merchantDefinedData->mobile= $data['ps_mob']; 
        // $postData->merchantDefinedData->state= $data['ps_state']; 
        // $postData->merchantDefinedData->cart_id= $data['ps_cart_id']; 
        // $postData->merchantDefinedData->payment_type= $data['payment_type']; 
        // $postData->merchantDefinedData->cashback_option= $data['cashback_option']; 
        // $postData->merchantDefinedData->ejabiplus_prd_id=$data['ejabiplus_prd_id'];

        $postData->merchantAttributes = new \StdClass();
        $postData->merchantAttributes->redirectUrl = "http://active.birigroup.co.uk/orderStatus"; 
        $postData->merchantAttributes->skipConfirmationPage = true; 


        $outlet = "adbe5328-aa64-4f4b-a353-a2d027f33ca6";
        // $outlet = "b604f1af-1928-4b92-9506-02ad6483ce3a";
        $json = json_encode($postData);
        $ch = curl_init(); 
        
        curl_setopt($ch, CURLOPT_URL, "https://api-gateway.ngenius-payments.com/transactions/outlets/".$outlet."/orders"); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Authorization: Bearer ".$access_token, 
        "Content-Type: application/vnd.ni-payment.v2+json", 
        "Accept: application/vnd.ni-payment.v2+json")); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        curl_setopt($ch, CURLOPT_POST, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json); 
        
        $output = json_decode(curl_exec($ch)); 


            // dd($output);
        $order_reference = $output->reference; 
        $order_paypage_url = $output->_links->payment->href; 
        return $order_paypage_url;
        redirect($order_paypage_url);
        // $response_card=$this->order_sts($access_token,$outlet,$order_reference);


        $data_return =array(
            'acces_token'=>$access_token,
            'oulet_id'=>$outlet,
            'order_ref'=>$order_reference,
            );
            // dd($data_return);
        return $data_return;
    //print_r($order_paypage_url);

    }


    public function apiToPos($data1)
    {
        $header = ["accept: application/json"];
        // $data_pass = array_merge($data1);  
                // dd(array_merge($data1,$params));
            // dd(date('m/d/yy H:i'));
  
        
        $curl = curl_init();
        $url="http://127.0.0.1:8000/api/sales-update-website";
        // dd($url);
        curl_setopt_array($curl, array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_TIMEOUT => 30000,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $data,
          CURLOPT_HTTPHEADER => array(
            "Authorization: 55784c3suNSIlFmrh4VfQKFMlwMifMHXfCkW",
            "accept: application/json"
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
          //echo "cURL Error #:" . $err;
            $res=$err;
        } else {
          $res= json_decode($response, true);
        } 
           
    }

    public function apiDataToPos($order_id,$payment)
    {
        // $data = array();

        $data['api_request'] = 1;
        $data['location_id'] = 10;
        $data['price_group'] = 0;
        $data['default_price_group'] = 0;
        $data['contact_id'] = 86;
        $data['pay_term_number'] = null;
        $data['pay_term_type'] = null;
        $data['transaction_date'] = date('m/d/yy H:i');
        $data['status'] = 'final';
        $data['invoice_scheme_id'] = 1;
        $data['search_product'] = null;
        $data['sell_price_tax'] = 'includes';

        $order = Order::where('id',$order_id)->first();
        $orderDetails = OrderDetail::where('order_id',$order->id)->get();
       
        // $product_det = array();
        $item = collect();
        $total = 0;
        $total_gift_wrapper = 0;
        $total_discount = 0;
        foreach($orderDetails as $key => $orderDetail)
        {
           
           
            $product = \App\Product::where('id',$orderDetail->product_id)->first();
            if($orderDetail->price != 0)
            {
               
                $discount =  ($product->unit_price - ($orderDetail->price/$orderDetail->quantity));
                $unit_price = strval(($orderDetail->price/$orderDetail->quantity) );
            }
            else{
             
                $discount =  0;
                $unit_price = '0';
            }
        
            $product_det_main = [
                            'sku' => $product->sku,
                            'name' => $product->name,
                            'unit_price' => $unit_price,
                            'line_discount_type' => 'fixed',
                            // 'line_discount_amount' => strval($discount),
                            'line_discount_amount' => '0.00',
                            'item_tax' => '0.00',
                            'tax_id' => null,
                            'sell_line_note' => null,
                            'enable_stock' => '1',
                            'quantity' => strval($orderDetail->quantity),
                            'base_unit_multiplier' => '1',
                            'unit_price_inc_tax' =>  $unit_price,

                            ];
           
            $total_discount += $discount * $orderDetail->quantity;
           
            if($orderDetail->gift_wrapper == 1)
            {
                $total_gift_wrapper += ($orderDetail->gift_wrapper * $orderDetail->quantity);
            }
            $total += $orderDetail->price;
           
            if($product->variant_product == 1 || $product->variable_to_single == 1)
            {
               if($product->variable_to_single == 1)
               {
                    Log::info('inside variable_to_single');
                    $product_det_variant = [
                        'product_type' => 'variable',
                        'variant_name' => $product->var_name
                    ];
               }
               else
               {
                $product_stock = ProductStock::where('product_id',$product->id)->where('variant',$orderDetail->variation)->first();
                
                $product_det_variant = [
                    'product_type' => 'variable',
                    'variant_name' => $product_stock->variant
                ]; 
               }

                $product_det = array_merge($product_det_main,$product_det_variant);
            }
            else
            {
                $product_det_single = [
                                    'product_type' => 'single',
                                ];       
                 

                $product_det = array_merge($product_det_main,$product_det_single);
            }
            
            $item->put($key+1 , $product_det);

        }
        $abc = collect();
    
        // dd($total_gift_wrapper);
        if($total_gift_wrapper > 0)
        {
            $gift_wrap = [
                'sku' => 'GFW001',
                'name' => 'Gift Wrapper',
                'product_type' => 'single',    
                'unit_price' => strval(env('GIFT_WRAPPER_AED')),
                'line_discount_type' => 'fixed',
                'line_discount_amount' => '0.00',
                'item_tax' => '0.00',
                'tax_id' => null,
                'sell_line_note' => null,
                'enable_stock' => '1',
                'quantity' => strval($total_gift_wrapper),
                'base_unit_multiplier' => '1',
                'unit_price_inc_tax' =>  strval(env('GIFT_WRAPPER_AED')),
    
                ];
            $abc->push($gift_wrap);
            $item = $item->merge($abc);
        }
        
        $total_discount =  $order->coupon_discount + $order->club_point_discount;
       
       
       $payment_pay = 'paid';
        $total = $total + $order->shipping_cost + ($total_gift_wrapper * env('GIFT_WRAPPER_AED')) - $total_discount;

        $amount ='0.00';
        $method = 'cash';
        
            
        if($order->payment_status == 'paid')
        {
            $amount = $total;
            $method = 'card';
        }

        $payment= collect();
        $payment_det = [
            'amount'=>  strval($amount),
            'method'=>  strval($method),
            'account_id'=>  null,
            'card_number'=>  null,
            'card_holder_name'=>  null,
            'card_transaction_number'=>  null,
            'card_type'=>  'credit',
            'card_month'=>  null,
            'card_year'=>  null,
            'card_security'=>  null,
            'cheque_number'=>  null,
            'bank_account_number'=>  null,
            'transaction_no_1'=>  null,
            'transaction_no_2'=>  null,
            'transaction_no_3'=>  null,
            'note'=>  null,
        ];

        $payment->push($payment_det);
       

       
        $order_shipping_address = str_replace('{',"",$order->shipping_address);
        $order_shipping_address = str_replace('}',"",$order_shipping_address);
        $order_shipping_address = str_replace('"',"",$order_shipping_address);
        $order_shipping_address .= " , Order code: #".$order->code;
        $header = ["accept: application/json"];
        // $data_pass = array_merge($data1);  
                // dd(array_merge($data1,$params));
            // dd(date('m/d/yy H:i'));
        $abc = [
            'api_request' => '1',
           'location_id' => '10',
            'price_group' => '0',
            'default_price_group' =>'0',
           'contact_id' => '86',
            'pay_term_number' => null,
            'pay_term_type' => null,
            'transaction_date' => date('m/d/yy H:i'),
            'status' => 'final',
            'invoice_scheme_id' => '1',
            'search_product' => null,
            'sell_price_tax' => 'includes',
            'products' => ($item),
            'discount_type'=> "flat",
            'discount_amount'=> strval($total_discount),
            'rp_redeemed'=> '0',
            'rp_redeemed_amount'=> '0',
            'rp_redeemed_modal'=> null,
            'tax_rate_id'=> null,
            'tax_calculation_amount'=> '0.00',
            'shipping_details'=> $order->tracking_no,
            'shipping_address'=> null,
            'shipping_charges'=> $order->shipping_cost,
            'shipping_status'=> 'ordered',
            'delivered_to'=> '1',
            'final_total'=> strval($total),
            'sale_note'=> ($order_shipping_address),
            'is_direct_sale'=> '1',
            'advance_balance'=> '1',
            'payment' => ($payment),
            'is_save_and_print'=> '0',
            'recur_interval'=> null,
            'recur_interval_type'=> 'days',
            'recur_repetitions'=> null,
            'subscription_repeat_on'=> null,
        ];
        // dd($abc);
       
        $curl = curl_init();
        $url=env('POS_URL')."/api/sales-update-website";
        // dd($url);
        curl_setopt_array($curl, array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_TIMEOUT => 30000,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $abc,
          CURLOPT_HTTPHEADER => array(
            "Authorization: 55784c3suNSIlFmrh4VfQKFMlwMifMHXfCkW",
            "accept: application/json",
            
           
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
          //echo "cURL Error #:" . $err;
            $res=$err;
        } else {
          $res= json_decode($response, true);
        } 
        
        
    //    $result =  $this->apiToPos($data);
       return true;
    }

    public function posSmsReceiveData(Request $request)
    {
        $header = $request->header('Authorization');
        $check_header = '55784c3suNSIlFmrh4VfQKFMlwMifMHXfCkW';

        if(!empty($header))
        {
            if($header == $check_header)
            {
                //Log::info($request->order_status);
                if($request->order_status == 'ordered')
                {
                    $text = 'Dear Customer, your  order has been successfully placed. We are preparing your order and we will inform you when it is shipped.';
                }
                if($request->order_status == 'shipped')
                {
                    $track = '';
                    if($request->shipping_type != null)
                    {
                        if($request->shipping_type == 'century')
                        {
                            $track = 'Your tracking code: '.$request->tracking_shipment.'click here to track the shipment https://centuryexpress.me/track-shipment/';
                        }
                        else{
                            $track = 'You will receive your order within 2 to 4 working days.';
                        }
                    }
                    else{
                        $track = 'You will receive your order within 2 to 4 working days.';
                    }

                   
                    $text = 'Dear Customer, your  order has been Shipped. '.$track;
                }
                if($request->order_status == 'delivered')
                {
                    $text = 'Dear Customer, your  order has been Delivered. Thank you for choosing us:) Register on our website to know more offers https://birigroup.co.uk/';
                }
                if($request->order_status == 'cancelled')
                {
                    $text = 'Dear Customer, your  order was cancelled. For assistance, call at 422 811 42 or send us e-mail on info@birigroup.com';
                }
                                    try{
                                    //    $pass =  $this->send_message($request->phone_number,$text);
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                    }
                

                return response()->json([ 'status' => 'true',
                'message' => 'Success',
            
                ], 200);
            }
            else
            {
                return response()->json([ 'status' => 'false',
                'message' => 'Unauthorized',
              
                ], 403);
            }
        }
        else
        {
            
            return response()->json([ 'status' => 'false',
            'message' => 'Unauthorized',
          
            ], 403);
        }
    }

    public function send_message($to,$text)
    {
        try{
            $to = trim($to);
            $to = str_replace(" ", "", $to);
            $check = substr($to,0,5);
            if($check == '00971')
            {
                $to = substr_replace($to,"",0,5);
            }
            
            $check = substr($to,0,4);
            if($check == '+971')
            {
                $to = substr_replace($to,"",0,4);
            }
            $check = substr($to,0,3);
            if($check == '971')
            {
                $to = substr_replace($to,"",0,3);
            }
            $check = substr($to,0,1);
            if($check == '0')
            {
                $to = substr_replace($to,"",0,1);
            }
            $to = '971'.$to;
    
              Credentials::set('24baa0b710c713e63af5edab75f5c739', '18f761b425b750ba1831bdeb4a2183ac');
              $send_message = new Sms();
            try{
                                     
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                        return 'false';
                                    }
             
            return 'true';
        }
        catch (\Exception $e)
        {
            return 'false';
        }
        
    }


    
}
