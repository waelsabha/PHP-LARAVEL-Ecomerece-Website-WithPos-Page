<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\CheckoutController;
use App\Order;
use App\OrderDetail;
use App\Product;
use App\ProductStock;
use Session;

use Illuminate\Support\Facades\Log;
use Postpay\Exceptions\RESTfulException;

class PostPayController extends Controller
{
    //
    public function __construct()
    {
        
    }

    public function postPayCheckout()
    {
            $postpay = new \Postpay\Postpay([
                'merchant_id' => 'id_7cf57e7011a949388ce0a767d0f9e7f7',
                'secret_key' => 'sk_live_70b2e150e739d88fabb375c9ce7fa9c8e3d30523',
                'sandbox' => false
            ]);
        //     $postpay = new \Postpay\Postpay([
        //     'merchant_id' => 'id_7cf57e7011a949388ce0a767d0f9e7f7',
        //     'secret_key' => 'sk_test_e09c288da4f1bd67ab6c6f5890573b6060d8d2af',
        //     'sandbox' => true
        // ]);
            $order = Order::findOrFail(Session::get('order_id'));
            // $payload= collect();
            if($order)
            {
                $orderAddress = json_decode($order->shipping_address);
                if($order->user_id != null)
                {
                    $user_id  = "customer-".$order->user_id;
                }
                else{
                    $user_id  = "guest-".$order->guest_id;
                }
            }
            $address = [
                "first_name"=> $orderAddress->name,
                "last_name"=> " ",
                "phone"=> $orderAddress->phone,
                "alt_phone"=> $orderAddress->phone,
                "line1"=>  $orderAddress->address,
                "line2"=>  $orderAddress->building_name.','. $orderAddress->flat_no,
                "city"=> $orderAddress->area,
                "state"=> $orderAddress->emirate,
                "country"=> "AE",
                "postal_code"=> "00000"
            ];
            $shipping_amount = round($order->shipping_cost*0.952381,2);
            $shipping_add = [
                "id"=> "shipping-01",
                "name"=> "Express Delivery",
                "amount"=> (float)round(($shipping_amount*100),2),
                "address" => $address
            ];
            $billing_address = [
                "first_name"=> $orderAddress->name,
                "last_name"=> " ",
                "phone"=> $orderAddress->phone,
                "alt_phone"=> $orderAddress->phone,
                "line1"=>  $orderAddress->address,
                "line2"=>  $orderAddress->building_name.','. $orderAddress->flat_no,
                "city"=> $orderAddress->area,
                "state"=> $orderAddress->emirate,
                "country"=> "AE",
                "postal_code"=> "00000"
            ];
            $customer = [
                "id"=> $user_id,
                "email"=>  $orderAddress->email,
                "first_name"=> $orderAddress->name,
                "last_name"=> " ",
                "gender"=> "male",
                "account"=> "guest",
                "date_of_birth"=> "1990-01-20",
                "date_joined"=> "2019-08-26T09:28:14.790Z"
            ]; 

            $orderDetails = OrderDetail::where('order_id',$order->id)->get();
            $item = array();
            foreach($orderDetails as $key => $orderDetail)
            {
                $product = Product::where('id',$orderDetail->product_id)->first();
                $p_price = round(($product->unit_price*0.952381),2);
                $item_each = [
                    "reference"=> $product->sku,
                    "name"=> $product->name.' '.$orderDetail->variation,
                    "description"=>  $product->name.' '.$orderDetail->variation,
                    "url"=> "https://birigroup.co.uk/product/".$product->slug,
                    "image_url"=> "https://birigroup.co.uk/public/".$product->thumbnail_img,
                    "unit_price"=> (float)round(($p_price*100),2),
                    "qty"=> $orderDetail->quantity
                ];
                $item[] = $item_each;
            }
            $items = $item;
                
        //    dd($items);
            $discounts = [
                "code"=> "return-10",
                "name"=> "Returning customer 10% discount",
                "amount"=> 000,
            ];
            $merchant = [
               
                "confirmation_url"=> "http://birigroup.co.uk/postpay/cart_payment_callback",
                "cancel_url"=> "http://birigroup.co.uk/postpay/cancel_callback"
            ];
            $tax = ($order->grand_total - (($order->grand_total)*0.952381));
            // dd(round($tax,2));
            if($order->user_id == 14)
            {
                $tot_am = 1*100;
            }
            else{
                $tot_am = ($order->grand_total)*100;
            }
            $payload = [

                "order_id" => $order->code,
                "total_amount"=> ($order->grand_total)*100,
                "tax_amount"=> round((round($tax,2)*100),2),
                "currency"=> "AED",
                "shipping"=>$shipping_add,
                "billing_address"=>$billing_address,
                "customer"=>$customer,
                "items"=>$items,
                "discounts"=>[$discounts],
                "merchant"=>$merchant
            ];
            // dd($payload);
            $tojson = json_encode($payload);
            $toarray = [$tojson];
            // $payload->push($payment_det);
            try {
                $response = $postpay->post('/checkouts', $payload);
                // dd($response->json());
                return redirect()->away($response->json()['redirect_url']);
            } catch (RESTfulException $e) {
                // echo $e->getErrorCode();
                Log::info('error post pay : '.$e->getErrorCode());
                flash(translate("Something went wrong please try again."))->error();
                return back();
            }
            // dd($response->redirect_url);
        
    }
    public function cart_payment_callback(Request $request)
    {
        $postpay = new \Postpay\Postpay([
            'merchant_id' => 'id_7cf57e7011a949388ce0a767d0f9e7f7',
            'secret_key' => 'sk_live_70b2e150e739d88fabb375c9ce7fa9c8e3d30523',
            'sandbox' => false
        ]);
        // $postpay = new \Postpay\Postpay([
        //     'merchant_id' => 'id_7cf57e7011a949388ce0a767d0f9e7f7',
        //     'secret_key' => 'sk_test_e09c288da4f1bd67ab6c6f5890573b6060d8d2af',
        //     'sandbox' => true
        // ]);
        $order_id = $request->order_id;
        $status = $request->status;
        
        if($status == 'APPROVED')
        {
            $order = Order::where('code',$order_id)->first();
            $order_id = $order->code;
            $url = '/orders/'.$order_id.'/capture';
            $response = $postpay->post($url);
            $response = $response->json();
            
            if($response['status'] == 'captured')
            {
                $checkoutController = new CheckoutController;
                
                return $checkoutController->checkout_done($order->id, 'postpay');
            }
            else{
                flash(translate("Could not capture the payment please try again."))->error();
                return redirect()->route('checkout.store_delivery_info');
            }
        }
    }
    public function cancel_callback(Request $request)
    {
        flash(translate("You have cancelled the order."))->error();
        return redirect()->route('cart');
    }

     public function appPostPayCheckout($order_id)
    {
        
            // $postpay = new \Postpay\Postpay([
                
            //     'merchant_id' => 'id_7cf57e7011a949388ce0a767d0f9e7f7',
            //     'secret_key' => 'sk_live_70b2e150e739d88fabb375c9ce7fa9c8e3d30523',
            //     'sandbox' => false
            // ]);
            $postpay = new \Postpay\Postpay([
            'merchant_id' => 'id_7cf57e7011a949388ce0a767d0f9e7f7',
            'secret_key' => 'sk_test_e09c288da4f1bd67ab6c6f5890573b6060d8d2af',
            'sandbox' => true
        ]);
            $order = Order::findOrFail($order_id);
            // $payload= collect();
            if($order)
            {
                $orderAddress = json_decode($order->shipping_address);
                if($order->user_id != null)
                {
                    $user_id  = "customer-".$order->user_id;
                }
                else{
                    $user_id  = "guest-".$order->guest_id;
                }
            }
            $address = [
                "first_name"=> $orderAddress->name,
                "last_name"=> " ",
                "phone"=> $orderAddress->phone,
                "alt_phone"=> $orderAddress->phone,
                "line1"=>  $orderAddress->address,
                "line2"=>  $orderAddress->building_name.','. $orderAddress->flat_no,
                "city"=> $orderAddress->area,
                "state"=> $orderAddress->emirate,
                "country"=> "AE",
                "postal_code"=> "00000"
            ];
            $shipping_amount = round($order->shipping_cost*0.952381,2);
            $shipping_add = [
                "id"=> "shipping-01",
                "name"=> "Express Delivery",
                "amount"=> (float)round(($shipping_amount*100),2),
                "address" => $address
            ];
            $billing_address = [
                "first_name"=> $orderAddress->name,
                "last_name"=> " ",
                "phone"=> $orderAddress->phone,
                "alt_phone"=> $orderAddress->phone,
                "line1"=>  $orderAddress->address,
                "line2"=>  $orderAddress->building_name.','. $orderAddress->flat_no,
                "city"=> $orderAddress->area,
                "state"=> $orderAddress->emirate,
                "country"=> "AE",
                "postal_code"=> "00000"
            ];
            $customer = [
                "id"=> $user_id,
                "email"=>  $orderAddress->email,
                "first_name"=> $orderAddress->name,
                "last_name"=> " ",
                "gender"=> "male",
                "account"=> "guest",
                "date_of_birth"=> "1990-01-20",
                "date_joined"=> "2019-08-26T09:28:14.790Z"
            ]; 

            $orderDetails = OrderDetail::where('order_id',$order->id)->get();
            $item = array();
            foreach($orderDetails as $key => $orderDetail)
            {
                $product = Product::where('id',$orderDetail->product_id)->first();
                $p_price = round(($product->unit_price*0.952381),2);
                $item_each = [
                    "reference"=> $product->sku,
                    "name"=> $product->name.' '.$orderDetail->variation,
                    "description"=>  $product->name.' '.$orderDetail->variation,
                    "url"=> "https://birigroup.co.uk/product/".$product->slug,
                    "image_url"=> "https://birigroup.co.uk/public/".$product->thumbnail_img,
                    "unit_price"=> (float)round(($p_price*100),2),
                    "qty"=> $orderDetail->quantity
                ];
                $item[] = $item_each;
            }
            $items = $item;
                
        //    dd($items);
            $discounts = [
                "code"=> "return-10",
                "name"=> "Returning customer 10% discount",
                "amount"=> 000,
            ];
            $merchant = [
               
                "confirmation_url"=> "http://birigroup.co.uk/postpay/app_cart_payment_callback",
                "cancel_url"=> "http://birigroup.co.uk/postpay/app_cancel_callback"
            ];
            $tax = ($order->grand_total - (($order->grand_total)*0.952381));
            // dd(round($tax,2));
            $payload = [

                "order_id" => $order->code,
                "total_amount"=> ($order->grand_total)*100,
                "tax_amount"=> round((round($tax,2)*100),2),
                "currency"=> "AED",
                "shipping"=>$shipping_add,
                "billing_address"=>$billing_address,
                "customer"=>$customer,
                "items"=>$items,
                "discounts"=>[$discounts],
                "merchant"=>$merchant
            ];
            // dd($payload);
            $tojson = json_encode($payload);
            $toarray = [$tojson];
            // $payload->push($payment_det);
            try {
                $response = $postpay->post('/checkouts', $payload);
                // dd($response);
                // return $response->json()['redirect_url'];
                // Log::info(json_encode($response));
                $resp = $response->json()['redirect_url'];
                return $resp;
            } catch (RESTfulException $e) {
                // echo $e->getErrorCode();
                $message = 'Payment incomplete..Please Try Again Later.';
                return view('frontend.app_message_notification',compact('message'));
            }
            // dd($response->redirect_url);
        
    }

    // public function appCart_payment_callback(Request $request)
    // {
        
    //     $order_id = $request->order_id;
    //     $status = $request->status;
        
    //     if($status == 'APPROVED')
    //     {
    //         $order = Order::where('code',$order_id)->first();
    //         $checkoutController = new CheckoutController;
                
    //         return $checkoutController->checkout_done($order->id, 'postpay',1);
    //     }
    // }

    public function appCart_payment_callback(Request $request)
    {
        $postpay = new \Postpay\Postpay([
            'merchant_id' => 'id_7cf57e7011a949388ce0a767d0f9e7f7',
            'secret_key' => 'sk_live_70b2e150e739d88fabb375c9ce7fa9c8e3d30523',
            'sandbox' => false
        ]);
        
        $order_id = $request->order_id;
        $status = $request->status;
        
        if($status == 'APPROVED')
        {
            $order = Order::where('code',$order_id)->first();

            $checkoutController = new CheckoutController;

            $url = '/orders/'.$order_id.'/capture';
            $response = $postpay->post($url);
            $order_id = $order->code;
            if($response->status == 'captured')
            {
                $checkoutController = new CheckoutController;
                
                return $checkoutController->checkout_done($order->id, 'postpay',1);
            }
            else{
                $this->appCancel_callback($request);
            } 
           
        }
        else{
            $this->appCancel_callback($request);
        } 
    }

    public function appCancel_callback(Request $request)
    {
        flash(translate("Something went wrong please try again."))->error();
        $message = 'Payment incomplete..Please Try Again Later.';
        return view('frontend.app_message_notification',compact('message'));
    }

    public function capture()
    {
        //dd('here');
        $id = 201;
        $postpay = new \Postpay\Postpay([
            'merchant_id' => 'id_7cf57e7011a949388ce0a767d0f9e7f7',
            'secret_key' => 'sk_live_70b2e150e739d88fabb375c9ce7fa9c8e3d30523',
            'sandbox' => false
        ]);

        $order_id = '20220217-11012553';
        $url = '/orders/'.$order_id;
        $response = $postpay->get($url);
        $response = $response->json();
        dd($response['status']);
          
    }
}
