<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Product;
use App\VariationTemplete;
use App\VariationValueTemplete;

use App\Support\VariationOthers;

use Illuminate\Support\Facades\Log;

class VariationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
      
        $sort_search =null;

        $variations_data = VariationTemplete::with('values')->latest()->get();
        $variations = VariationTemplete::orderBy('created_at', 'desc');
     
      
        if ($request->has('search')){
        
           $sort_search = $request->search;
           $variations = $variations->where('name', 'like', '%'.$sort_search.'%');
            
        }
        

        // $abc = $variations->paginate(15);
        
        $variations = $variations->paginate(15);
        // Log::info(9);
        // dd($variations_data);
        return view('variations.index', compact('variations', 'sort_search','variations_data'));
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('variations.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $variation_templete = new VariationTemplete([
            'name' => $request->input('name')
        ]);
        $variation_templete->save();
        foreach($request->input('value') as $key => $value) {
            if($value != null || $value != '')
            {

                
                $variation_value_templete = new VariationValueTemplete([
                    'name' => $value,
                    'variation_templete_id' => $variation_templete->id
                ]); 
                $variation_value_templete->save();
            }
           
        }
        return redirect()->route('variation.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //

        $variation = VariationTemplete::findOrFail(decrypt($id));

        return view('variations.edit', compact('variation'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
