<?php

namespace App\Http\Controllers;

use App\Category;
use App\Post;
use App\PostTopic;
use App\ProductMetadata;
use App\SubCategory;
use App\Topic;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use ImageOptimizer;

class BlogController extends Controller
{
    //

    public function admin_blog(Request $request)
    {
        $type = null;
        if ($request->type != null){
        }

        $blogs = Post::paginate(15);

        return view('blog.index',compact('blogs','type'));
    
    }


    public function create()
    {
        $topics = Topic::all();
        $categories = Category::all();
        return view('blog.create', compact('topics','categories'));
    }

    public function store(Request $request)
    {
        
        if($request->slug != null)
        {
            $get_post = Post::where('slug',$request->slug)->first();

            if($get_post)
            {
                flash(translate('URL already exist'))->error();
            }
            if($request->title == null && $request->body == null)
            {
                flash(translate('All fields are required'))->error();
            }
            else
            {

                // dd($request);    
                $new_post = new Post;
                $new_post->user_id = Auth::user()->id;
                $new_post->title = $request->title;
                $new_post->meta_description = $request->meta_description;
                $new_post->body = $request->body;
                $new_post->slug = $request->slug;
                if($request->hasFile('photo')){
                   
                    $new_post->image = $request->photo->store('uploads/blogs');
                    // $file_url = Storage::path('uploads\blogs\fH4irgpUFVmgpjAIkR374zlodzuaNz0lZbCqXjOf.jpeg');

                    // $img = ImageOptimizer::optimize($file_url,$file_url);
                    // dd($img);
                }
                if($request->hasFile('thumbnail_image')){
                   
                    $new_post->thumbnail_image = $request->thumbnail_image->store('uploads/blogs/thumbnail');
                  
                }

                $new_post->category_id = $request->category_id;

       
                $options_sub_cat = array();
                if($request->has('subcategory_id')){
                    if(is_array($request->subcategory_id))
                    {
                        foreach ($request->subcategory_id as $key => $sub_cat) {
                    
                            array_push($options_sub_cat, $sub_cat);
                            }
                    }

                    $new_post->subcategory_id = json_encode($request->subcategory_id);
                }

                $options_sub_sub_cat = array();

                if($request->has('subsubcategory_id') ){
                    if(is_array($request->subsubcategory_id))
                    {
                        foreach ($request->subsubcategory_id as $key => $sub_sub_cat) {
                        
                        array_push($options_sub_sub_cat, $sub_sub_cat);
                        
                        }
                    }
                    $new_post->subsubcategory_id = json_encode($request->subsubcategory_id);
                }

                $new_post->tags = implode('|',$request->tags);
                $new_post->published = '0';
                $new_post->save();

                $post_topic = new PostTopic;
                $post_topic->post_id =  $new_post->id;
                $post_topic->topic_id = $request->topic_id;
                $post_topic->save();

                $meta_data = new ProductMetadata();

                $meta_data->m_blog_id = $new_post->id;
                // dd($request->meta_title);
                $meta_data->m_title = $request->meta_title;
                $meta_data->m_mdesc = $request->meta_description;
        
                if($meta_data->m_title == null) {
                    $meta_data->m_title = $new_post->title;
                }
        
        
                $meta_data->m_mkeywrd = $request->m_mkeywrd;
                $meta_data->m_robot = $request->m_robot;
                $meta_data->m_cpyrgt = $request->m_cpyrgt;
                $meta_data->m_dc_title = $request->m_dc_title;
                $meta_data->m_dc_desc = $request->m_dc_desc;
                $meta_data->m_dc_sub = $request->m_dc_sub;
                $meta_data->m_dc_crtor = $request->m_dc_crtor;
                $meta_data->m_dc_type = $request->m_dc_type;
                $meta_data->m_dc_type_img = $request->m_dc_type_img;
                $meta_data->m_dc_lang = $request->m_dc_lang;
                $meta_data->m_dc_format = $request->m_dc_format;
                $meta_data->save();
        
                
                flash(translate('Blog added successfully'))->success();
                return redirect()->route('blog.index');
            }
        }
        else{
            flash(translate('URL required'))->error();
        }
        
    }

    public function edit($id)
    {
        $categories = Category::all();
      
        $sub_categories = SubCategory::all();
       

        $blog = Post::where('id',decrypt($id))->first();
        $post_topic = PostTopic::where('post_id',$blog->id)->first();
        $topic = Topic::where('id',$post_topic->topic_id)->first();
        $topics = Topic::all();

        $exp = explode(',', $blog->subcategory_id);
        preg_match_all('!\d+!', $blog->subcategory_id, $matches);
        $subcategory_ids = $matches;

        $meta_details = ProductMetadata::where('m_blog_id',decrypt($id))->first();
        return view('blog.edit',compact('blog','topic','topics','meta_details','categories','subcategory_ids','sub_categories'));
    }

    public function update(Request $request,$id)
    {
        
        if($request->slug != null)
        {
            $get_post = Post::where('id',$id)->first();

            
            if($request->title == null && $request->body == null)
            {
                flash(translate('All fields are required'))->error();
            }
            else
            {

                // dd($request);    
                
                $get_post->user_id = Auth::user()->id;
                $get_post->title = $request->title;
                $get_post->meta_description = $request->meta_description;
                $get_post->body = $request->body;
                $get_post->slug = $request->slug;
                if($request->hasFile('photo')){
                   
                    $get_post->image = $request->photo->store('uploads/blogs');

                }
                if($request->hasFile('thumbnail_image')){
                   
                    $get_post->thumbnail_image = $request->thumbnail_image->store('uploads/blogs/thumbnail');
                  
                }
                $get_post->category_id = $request->category_id;
        // dd($request);

                $options_sub_cat = array();
                if($request->has('subcategory_id') && count($request->subcategory_id) > 0){
                    foreach ($request->subcategory_id as $key => $sub_cat) {                    
                    array_push($options_sub_cat, $sub_cat);
                    }
                    
                    $get_post->subcategory_id = json_encode($request->subcategory_id);
                }
                else{
                    $get_post->subcategory_id = json_encode(array());
                } 
                $options_sub_sub_cat = array();
                if($request->has('subsubcategory_id') && count($request->subsubcategory_id) > 0){
                    foreach ($request->subsubcategory_id as $key => $sub_sub_cat) {
                    
                    array_push($options_sub_sub_cat, $sub_sub_cat);
                    }
                    
                    $get_post->subsubcategory_id = json_encode($request->subsubcategory_id);
                }
                else{
                    $get_post->subsubcategory_id = json_encode(array());
                }
                $get_post->tags = implode('|',$request->tags);

                $get_post->save();

                $post_topic = PostTopic::where('post_id',$id)->first();
                
                $post_topic->topic_id = $request->topic_id;
                $post_topic->save();

                $meta_data = ProductMetadata::where('m_blog_id',$id)->first();

                if($meta_data)
                {

                }
                else
                {
                    $meta_data = new ProductMetadata();
                    $meta_data->m_blog_id = $get_post->id;
                }
                    $meta_data->m_title = $request->meta_title;
                    $meta_data->m_mdesc = $request->meta_description;
            
                    if($meta_data->m_title == null) {
                        $meta_data->m_title = $meta_data->title;
                    }
            
                    $meta_data->m_mkeywrd = $request->m_mkeywrd;
                    $meta_data->m_robot = $request->m_robot;
                    $meta_data->m_cpyrgt = $request->m_cpyrgt;
                    $meta_data->m_dc_title = $request->m_dc_title;
                    $meta_data->m_dc_desc = $request->m_dc_desc;
                    $meta_data->m_dc_sub = $request->m_dc_sub;
                    $meta_data->m_dc_crtor = $request->m_dc_crtor;
                    $meta_data->m_dc_type = $request->m_dc_type;
                    $meta_data->m_dc_type_img = $request->m_dc_type_img;
                    $meta_data->m_dc_lang = $request->m_dc_lang;
                    $meta_data->m_dc_format = $request->m_dc_format;
                

                $meta_data->save();
                
                flash(translate('Blog updated successfully'))->success();
                return redirect()->route('blog.index');
            }
        }

        else{
            flash(translate('URL required'))->error();
        }
    }

    public function destroy($id)
    {
        $product = Post::findOrFail($id);
        if($product)
        {
            Post::destroy($id);
            flash(translate('Blog has been deleted successfully'))->success();
            return back();
        }
        else
        {
            flash(translate('Something went wrong'))->error();
            return back();
        }
    }

    public function updatePublished(Request $request)
    {
        $get_post = Post::where('id',$request->id)->first();
        if($get_post)
        {
            $get_post->published = $request->status;
            $get_post->save();
        }
        
        return 1;
        
    }

    public function forntendList()
    {
        $blogs = Post::where('published',1)->get();
        return view('frontend.blog.blog_list',compact('blogs'));
    }

    public function forntendView($slug)
    {
        $blog = Post::where('slug',$slug)->first();
        $page = 1;
        return view('frontend.blog.blog_view',compact('blog','page'));
    }

}
