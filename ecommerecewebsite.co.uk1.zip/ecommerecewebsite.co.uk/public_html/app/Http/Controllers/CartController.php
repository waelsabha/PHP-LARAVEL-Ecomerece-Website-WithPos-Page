<?php

namespace App\Http\Controllers;

use App\CartDetail;
use App\CartList;
use Illuminate\Http\Request;
use App\Product;
use App\SubSubCategory;
use App\Category;
use App\Order;
use Session;
use App\Color;

use App\GiftRecipient;
use App\FreeProduct;
use Carbon\Carbon;
use Cookie;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;


class CartController extends Controller
{
    public function __construct()
    {
        //
        update_all_stock_from_pos();
        // update_cartDb_to_cartSession();
    }

    public function index(Request $request)
    {
        //dd($cart->all());
        $categories = Category::all();

        if (Session::has('cart') && count(Session::get('cart')) > 0) {
            $cart_session = Session::get('cart');
            foreach ($cart_session as $key => $cartItem){
                $check_product = Product::where('id',$cartItem['id'])->first();
                if($check_product)
                {
                    if($check_product->published == 0)
                    {
                        if(Session::has('uid'))
                        {
                            $cart_list = CartList::where('unique_id',Session::get('uid'))->first();
                            if($cart_list)
                            {
                                $cart_details = CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->first();
                                if($cart_details)
                                {
                                    CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->delete();
                                }
                            }
                        }
                        unset($cart_session[$key]);
                        Session::forget('cart');
                        Session::put('cart', $cart_session);
                        flash('Some items removed, since they are not available.')->warning();
                        // dd(Session::get('cart'));
                    }
                }
            }
        }
        Session::save();
        
   
        $this->addFreeGift('registration');
        return view('frontend.view_cart', compact('categories'));
    }

    public function showCartModal(Request $request)
    {
        $product = Product::find($request->id);
        return view('frontend.partials.addToCart', compact('product'));
    }

    public function updateNavCart(Request $request)
    {
        
        return view('frontend.partials.cart');
    }

    public function updateSideNavCart(Request $request)
    {  
        return view('frontend.partials.side_nav_cart');
    }
    public function addGiftWrapper(Request $request)
    {
       $gift_wrapper = 'false';
       $gift_wrapper_count_old = 0;
       $gift_wrapper_count = 0; 
        
        if(Session::get('cart')){
           
            
            $product = Product::find($request->id);
           

            $cart = collect();

            foreach (Session::get('cart') as $key => $cartItem){
               
                $product_variation = $cartItem['variant'];
                if(isset($cartItem['gift_wrapper']))
                {
                    $gift_wrapper_count_old = $gift_wrapper_count_old+$cartItem['gift_wrapper'];
                    
                }
                
                if($cartItem['id'] == $request->id){
                    if($request->click == 'true')
                    {
                        $cartItem['gift_wrapper'] = 1;
                        $gift_wrapper_count = $gift_wrapper_count_old+1;
                        
                    }
                    if($request->click == 'false')
                    {
                        $cartItem['gift_wrapper'] = 0;
                        $gift_wrapper_count = $gift_wrapper_count_old - 1;
                       
                    }
                    
                }

                $cart->push($cartItem);
                
            }

            
                Session::put('cart', $cart);
                return $gift_wrapper_count;
        }
    }

    public function addFreeGift($request)
    {
       
        if(isset(Auth::user()->id))
        {           
            $user = Auth::user()->id;
            //  dd('heere');  
            $free_gift_user = GiftRecipient::where('user_id',$user)->where('offer_type',$request)->where('status',1)->first();

            $free_gift_products = FreeProduct::where('offer_type',$request)->where('status',1)->pluck('product_id')->toArray();
            
            $cart = collect();
        
            if(Session::get('cart')){
                if(count($cart = Session::get('cart')) < 1)
                {
                    if($free_gift_user)
                    {
                        foreach($free_gift_products as $key2 => $free_gift_product)
                        {
                            $product = Product::where('id',$free_gift_product)->first();
                            $free_prod = FreeProduct::where('product_id',$product->id)->first();
                            $data['id'] = $free_gift_product;
                            $data['free_gift'] = 'registration';
                            $data['quantity'] = 1;
                            $data['variant'] = '';
                            $data['price'] = 0;
                            $data['tax'] = 0;
                            $data['shipping'] = 0;
                            $data['product_referral_code'] = null;
                            $data['digital'] = $product->digital;
                            $data['one_dirham'] = 0;
                            
                            $valid = validity_check($free_prod->validity,$free_gift_user->created_at);

                            $now = Carbon::now();

                            $diff = $now->diffInMinutes($valid);
                            if($now->gt($valid))
                            {

                            }
                            else
                            {

                                $cart->push($data);
                                flash(translate('Free Gift has been added to your cart. Checkout within '.$free_prod->valid_text))->warning();
                            }
                            
                        }
                    
                        Session::put('cart', $cart);
                        
                        return 'true';
                    }
                }
                foreach (Session::get('cart') as $key => $cartItem){
                    
                            if($free_gift_user)
                            {
                                foreach($free_gift_products as $key2 => $free_gift_product)
                                {
                                    if(!$this->in_array_r($free_gift_product,Session::get('cart'))) 
                                    {
                                        
                                        $product = Product::where('id',$free_gift_product)->first();
                                        $free_prod = FreeProduct::where('product_id',$product->id)->first();
                                        $data['id'] = $free_gift_product;
                                        $data['free_gift'] = 'registration';
                                        $data['quantity'] = 1;
                                        $data['variant'] = '';
                                        $data['price'] = 0;
                                        $data['tax'] = 0;
                                        $data['shipping'] = 0;
                                        $data['product_referral_code'] = null;
                                        $data['digital'] = $product->digital;
                                        $data['one_dirham'] = 0;
                                        
                                        $valid = validity_check($free_prod->validity,$free_gift_user->created_at);
            
                                        $now = Carbon::now();
            
                                        $diff = $now->diffInMinutes($valid);
                                        if($now->gt($valid))
                                        {
            
                                        }
                                        else
                                        {
            
                                            $cart->push($data);
                                            flash(translate('Free Gift has been added to your cart. Checkout within '.$free_prod->valid_text))->warning();
                                        }
                                    } 
                                    
                                    
                                }
                            
                                Session::put('cart', $cart);
                                
                                
                            }          
                       
                }
                //    Session::put('cart', $cart);
                   
            }
            else
            {
                
                    if($free_gift_user)
                    {
                        foreach($free_gift_products as $key2 => $free_gift_product)
                        {
                            $product = Product::where('id',$free_gift_product)->first();
                            $free_prod = FreeProduct::where('product_id',$product->id)->first();
                            $data['id'] = $free_gift_product;
                            $data['free_gift'] = 'registration';
                            $data['quantity'] = 1;
                            $data['variant'] = '';
                            $data['price'] = 0;
                            $data['tax'] = 0;
                            $data['shipping'] = 0;
                            $data['product_referral_code'] = null;
                            $data['digital'] = $product->digital;
                            $data['one_dirham'] = 0;
                            
                            $valid = validity_check($free_prod->validity,$free_gift_user->created_at);

                            $now = Carbon::now();

                            $diff = $now->diffInMinutes($valid);
                            if($now->gt($valid))
                            {

                            }
                            else
                            {

                                $cart->push($data);
                                flash(translate('Free Gift has been added to your cart. Checkout within '.$free_prod->valid_text))->warning();
                            }
                            
                        }
                    
                        Session::put('cart', $cart);
                        
                        return 'true';
                    }
                    
            }
        }

    }

    function in_array_r($needle, $haystack, $strict = false) {
        foreach ($haystack as $item) {
            if (($strict ? $item === $needle : $item == $needle) || (is_array($item) && $this->in_array_r($needle, $item, $strict))) {
                
                return true;
            }
        }
        
        return false;
    }

   public function addToCart(Request $request)
    {
        $product = Product::find($request->id);

        $data = array();
        $data['id'] = $product->id;
        $str = '';
        $tax = 0;
        $request->session()->forget('coupon_id');
        $request->session()->forget('coupon_discount');
        if($product->digital != 1 && $request->quantity < $product->min_qty) {
            return view('frontend.partials.minQtyNotSatisfied', [
                'min_qty' => $product->min_qty
            ]);
        }


        $flash_deals_check = \App\FlashDeal::where('status', 1)->get();
       
        //discount calculation based on flash deal and regular discount
        //calculation of taxes
        $data['one_dirham'] = 0;
        if(env('ONE_DHM_DEAL') == 1)
        {
            
            foreach ($flash_deals_check as $flash_deal_check) {
                if ($flash_deal_check != null && $flash_deal_check->status == 1  && strtotime(date('d-m-Y')) >= $flash_deal_check->start_date && strtotime(date('d-m-Y')) <= $flash_deal_check->end_date)
                {
                    // only for 1 dirham  sale
                    $cart_item_pid = array();
                    $flash_deal_product_request_id_check = \App\FlashDealProduct::where('flash_deal_id', $flash_deal_check->id)->where('product_id', $data['id'])->first();
                    if($flash_deal_product_request_id_check)
                    {
                        $data['one_dirham'] = 1;
                    }
                    if($request->session()->has('cart')){
                
                        foreach ($request->session()->get('cart') as $key => $cartItem){
                            
                            $cart_item_pid[] = $cartItem['id'];
                        }
            
                        $flash_deal_product = \App\FlashDealProduct::where('flash_deal_id', $flash_deal_check->id)->whereIn('product_id', $cart_item_pid)->first();

                        if(Auth::user())
                        {
                            $all_orders = Order::where('user_id',Auth::user()->id)->where('deal_availed',1)->get();
                            foreach($all_orders as $order_check)
                            {
                                if($order_check->deal_availed == 1)
                                {
                                    return 'once'; //falsh deal item already selected
                                }
                                
                            }
                        }
                        
                        
                       
                        if($flash_deal_product && $flash_deal_product_request_id_check)
                        {
                            
                            return 'false'; //falsh deal item already selected
                        }
                        
            
            
                    }
                    

                    
                }

            }
        }
        else
        {
            $data['one_dirham'] = 0;
        }
        

        //check the color enabled or disabled for the product
        if($request->has('color')){
            $data['color'] = $request['color'];
            $str = Color::where('code', $request['color'])->first()->name;
        }

        if ($product->digital != 1) {
            //Gets all the choice values of customer choice option and generate a string like Black-S-Cotton
            foreach (json_decode(Product::find($request->id)->choice_options) as $key => $choice) {
                if($str != null){
                    $str .= '-'.str_replace('', '', $request['attribute_id_'.$choice->attribute_id]);
                    $item = $request['attribute_id_'.$choice->attribute_id];
                }
                else{
                    $str .= str_replace('', '', $request['attribute_id_'.$choice->attribute_id]);
                    $item = $request['attribute_id_'.$choice->attribute_id];
                }
            }
        }

        $data['variant'] = $str;

        if($str != null && $product->variant_product){
            $product_stock = $product->stocks->where('product_id',$product->id)->where('variant', $item)->first();
            $price = $product_stock->price   ;




            $pricebefore = $product_stock->price;
            if($product->tax_type == 'percent'){
                $tax = ($pricebefore*$product->tax)/100;
            }
            elseif($product->tax_type == 'amount'){
                $tax = $product->tax;
            }
    
            // if($product->tax_type == 'percent'){
            //     $price += ($price*$product->tax)/100;
            // }
            // elseif($product->tax_type == 'amount'){
            //     $price += $product->tax;
            // }




            
            $quantity = $product_stock->qty;

            if($quantity >= $request['quantity']){
                // $variations->$str->qty -= $request['quantity'];
                // $product->variations = json_encode($variations);
                // $product->save();
            }
            else{
                return view('frontend.partials.outOfStockCart');
            }
        }
        else{
            
            $price = $product->unit_price;
            // if($product->tax_type == 'percent'){
            //     $price += ($price*$product->tax)/100;
            // }
            // elseif($product->tax_type == 'amount'){
            //     $price += $product->tax;
            // }

            $pricebefore = $product->unit_price;
            if($product->tax_type == 'percent'){
                $tax = ($pricebefore*$product->tax)/100;
            }
            elseif($product->tax_type == 'amount'){
                $tax = $product->tax;
            }
    


        }

        $flash_deals = \App\FlashDeal::where('status', 1)->get();
        $inFlashDeal = false;
        //discount calculation based on flash deal and regular discount
        //calculation of taxes
        
        foreach ($flash_deals as $flash_deal) {
            if ($flash_deal != null && $flash_deal->status == 1  && strtotime(date('d-m-Y')) >= $flash_deal->start_date && strtotime(date('d-m-Y')) <= $flash_deal->end_date)
            {
                // only for 1 dirham  sale
                
            }
            
            if ($flash_deal != null && $flash_deal->status == 1  && strtotime(date('d-m-Y')) >= $flash_deal->start_date && strtotime(date('d-m-Y')) <= $flash_deal->end_date && \App\FlashDealProduct::where('flash_deal_id', $flash_deal->id)->where('product_id', $product->id)->first() != null) {
                $flash_deal_product = \App\FlashDealProduct::where('flash_deal_id', $flash_deal->id)->where('product_id', $product->id)->first();
                if($flash_deal_product->discount_type == 'percent'){
                    $price -= ($price*$flash_deal_product->discount)/100;
                }
                elseif($flash_deal_product->discount_type == 'amount'){
                    $price -= $flash_deal_product->discount;
                }



                $inFlashDeal = true;
                break;
            }
        }
        if (!$inFlashDeal) {
            if($product->discount_type == 'percent'){
                $price -= ($price*$product->discount)/100;
            }
            elseif($product->discount_type == 'amount'){
                $price -= $product->discount;
            }
        }


   
        

        $data['quantity'] = $request['quantity'];
        $data['price'] = $price;
        $data['tax'] = $tax;
        $data['shipping'] = 0;
        $data['product_referral_code'] = null;
        $data['digital'] = $product->digital;

        if ($request['quantity'] == null){
            $data['quantity'] = 1;
        }

        if(Cookie::has('referred_product_id') && Cookie::get('referred_product_id') == $product->id) {
            $data['product_referral_code'] = Cookie::get('product_referral_code');
        }

        if($request->session()->has('cart')){
            $foundInCart = false;
            $cart = collect();

            foreach ($request->session()->get('cart') as $key => $cartItem){
               
                if($cartItem['id'] == $request->id){
                    if($cartItem['variant'] == $str){
                        $foundInCart = true;
                        $cartItem['quantity'] += $request['quantity'];
                    }
                }
               
                $cart->push($cartItem);
            }

            if (!$foundInCart) {

                $cart->push($data);
         
            }
            $request->session()->put('cart', $cart);

           
        }
        else{
            $cart = collect([$data]);
            $request->session()->put('cart', $cart);
            
        }
        if(Auth::check())
        {
            $ip = null;
            $uid = null;
            $user_id = Auth::user()->id;
            $cart_list = CartList::where('user_id',$user_id)->first();
        }
        else 
        {
            $user_id = null;
            $ip = $request->ip();
            $uid = ($request->uid);
            Log::info('uid ---'.$uid);
            $cart_list = CartList::where('unique_id',$uid)->first();
            if(!$cart_list)
            {
                $cart_list_ip = CartList::where('ip_address',$ip)->first();
                if($cart_list_ip)
                {
                    CartList::where('ip_address',$ip)->update(['unique_id'=>$uid]);
                    $cart_list = CartList::where('unique_id',$uid)->first();
                }
            }
        }
        
        Log::info('-------------------------here');
        if($cart_list)
        {
            foreach ($request->session()->get('cart') as $key => $cartItem){
                $cart_details_get = CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->first();
                if($cart_details_get)
                {
                    Log::info('here');
                    if($cartItem['variant'] == '')
                    {
                        
                        CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->update(['quantity' => $cartItem['quantity']]);
                    }
                    else
                    {
                        $check_variant = CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->where('variation',$cartItem['variant'])->first();
                        if($check_variant)
                        {
                            CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->where('variation',$cartItem['variant'])->update(['quantity' => $cartItem['quantity']]);
                        }
                        else
                        {
                            $cart_details = new CartDetail;
                            $cart_details->cart_list_id = $cart_list->id;
                            $cart_details->product_id = $cartItem['id'];
                            $cart_details->variation = $cartItem['variant'];
                            $cart_details->price = $cartItem['price'];
                            $cart_details->tax = $cartItem['tax'];
                            $cart_details->shipping_cost = $cartItem['shipping'];
                            $cart_details->quantity = $cartItem['quantity'];
                            $cart_details->save();
                        }
                        
                       
                    }
                    
                }
                else
                {
                    $cart_details = new CartDetail;
                    $cart_details->cart_list_id = $cart_list->id;
                    $cart_details->product_id = $cartItem['id'];
                    $cart_details->variation = $cartItem['variant'];
                    $cart_details->price = $cartItem['price'];
                    $cart_details->tax = $cartItem['tax'];
                    $cart_details->shipping_cost = $cartItem['shipping'];
                    $cart_details->quantity = $cartItem['quantity'];
                    $cart_details->save();
                }
                
            }
        }
        else
        {
            $cart_list = new CartList;
            $cart_list->unique_id = $uid;
            $cart_list->user_id = $user_id;
            $cart_list->ip_address = $ip;
            $cart_list->save();

           
            foreach ($request->session()->get('cart') as $key => $cartItem){
                $cart_details_get = CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->first();
                if($cart_details_get)
                {
                    if($str == '')
                    {
                        
                        CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->update(['quantity' => $cartItem['quantity']]);
                    }
                    else
                    {
                        $cart_details_get = CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cartItem['id'])->where('variation',$cartItem['variant'])->update(['quantity' => $cartItem['quantity']]);
                       
                    }
                    
                }
                else
                {
                    $cart_details = new CartDetail;
                    $cart_details->cart_list_id = $cart_list->id;
                    $cart_details->product_id = $cartItem['id'];
                    $cart_details->variation = $cartItem['variant'];
                    $cart_details->price = $cartItem['price'];
                    $cart_details->tax = $cartItem['tax'];
                    $cart_details->shipping_cost = $cartItem['shipping'];
                    $cart_details->quantity = $cartItem['quantity'];
                    $cart_details->save();
                }
                
            }

        }
        return view('frontend.partials.addedToCart', compact('product', 'data'));
    }


    public function cartDb()
    {

    }
    //removes from Cart
    public function removeFromCart(Request $request)
    {
        if($request->session()->has('cart')){
            $cart = $request->session()->get('cart', collect([]));
            $cart_item = $cart[$request->key];
            if(Auth::check())
            {
                $ip = null;
                $user_id = Auth::user()->id;
                $cart_list = CartList::where('user_id',$user_id)->first();
            }
            else 
            {
                $user_id = null;
                $ip = $request->ip();
                $uid = ($request->uid);
                $cart_list = CartList::where('unique_id',$uid)->first();
            }
            if($cart_list)
            {
                CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$cart_item['id'])->where('variation',$cart_item['variant'])->delete();
            }
            $cart->forget($request->key);
            $request->session()->put('cart', $cart);
        }


        $request->session()->forget('coupon_id');
        $request->session()->forget('coupon_discount');

        return view('frontend.partials.cart_details');
    }

    //updated the quantity for a cart item
    public function updateQuantity(Request $request)
    {
        $cart = $request->session()->get('cart', collect([]));
        $cart = $cart->map(function ($object, $key) use ($request) {
            if($key == $request->key){
                $product = \App\Product::find($object['id']);
                if($object['variant'] != null && $product->variant_product){
                    $product_stock = $product->stocks->where('product_id',$product->id)->where('variant', $object['variant'])->first();
                    $quantity = $product_stock->qty;
                    if($quantity >= $request->quantity){
                        if($request->quantity >= $product->min_qty){
                            $object['quantity'] = $request->quantity;
                            Log::info('inside update qty');
                            if(Auth::check())
                            {
                                $ip = null;
                                $user_id = Auth::user()->id;
                                $cart_list = CartList::where('user_id',$user_id)->first();
                            }
                            else 
                            {
                                Log::info('inside else'.$object['quantity']);
                                $user_id = null;
                                $ip = $request->ip();
                                $uid = ($request->uid);
                
                                $cart_list = CartList::where('unique_id',$uid)->first();
                            }
                            if($cart_list)
                            {
                                Log::info('cart it--'.$cart_list->id.'--id--'.$object['id'].'--variant--'.$object['variant'].'--qty--'.$object['quantity']);
                                CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$object['id'])->where('variation',$object['variant'])->update(['quantity'=>$object['quantity']]);
                            }
                        }
                    }
                }
                elseif($request->quantity >= $product->min_qty){
                    $object['quantity'] = $request->quantity;
                    if(Auth::check())
                    {
                        $ip = null;
                        $user_id = Auth::user()->id;
                        $cart_list = CartList::where('user_id',$user_id)->first();
                    }
                    else 
                    {
                        $user_id = null;
                        $ip = $request->ip();
                        $uid = ($request->uid);
                
                        $cart_list = CartList::where('unique_id',$uid)->first();
                    }
                    if($cart_list)
                    {
                        Log::info('cart it--'.$cart_list->id.'--id--'.$object['id'].'--variant--'.$object['variant'].'--qty--'.$object['quantity']);
                        CartDetail::where('cart_list_id',$cart_list->id)->where('product_id',$object['id'])->where('variation',$object['variant'])->update(['quantity'=>$object['quantity']]);
                    }
                }
            }
            return $object;
        });
        $request->session()->put('cart', $cart);
        $request->session()->forget('coupon_id');
        $request->session()->forget('coupon_discount');

        return view('frontend.partials.cart_details');
    }

    public function updateCartDb(Request $request)
    {
        Log::info('function updateCartDb');
        $uid = $request->uid;
        $update = update_cartDb_to_cartSession($uid);
        return 'true';
    }
    
    public function cartListCheck(Request $request)
    {
        $uid = ($request->uid_val);
        $ip = $request->ip();
        $cartList = CartList::where('unique_id',$uid)->first();
        if($cartList)
        {

        }
        else
        {

        }

    }
    
}
