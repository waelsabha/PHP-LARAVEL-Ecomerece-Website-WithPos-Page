<?php

namespace App\Http\Controllers;

use App\Models\ProductStock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\File;
use App\Product;
use App\ProductExtra;
use App\ProductMetadata;
use App\ShippingCharge;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;

use App\Redirection;

use Mail;
use App\Mail\EmailManager;


use Illuminate\Support\Facades\Storage;

use SoapClient;



class TestController extends Controller
{
    
    public function readFile()
    {
        $products_test = DB::connection('mysql2')->select(DB::raw('SELECT * FROM products_data'));
        dd($products_test);

        $products_pos = DB::connection('mysql2')->select(DB::raw('SELECT * FROM variation_location_details'));
        
        foreach($products_pos as $key => $var_loc_det)
        {
            if($var_loc_det->location_id == 2)
            {
                $products_test = DB::connection('mysql2')->table('products')->where('id',$var_loc_det->product_id)->first();
                // dd($products_test->name);
                $my_pro = Product::where('name',$products_test->name)->first();
                if($my_pro)
                {
                    $product_update = Product::where('name',$products_test->name)
                                                ->update([
                                                    'current_stock' => $var_loc_det->qty_available
                                                ]);
                }
                // dd($products_test);
            }
        }
        // foreach($products_test as $key => $product_tes)
        // {
        //     // dd($product_tes);
        //     // $image_final = array();

        //     // $product_update = Product::where('name',$product_tes->p_name)
                                                        
        //     //                                             ->update([
        //     //                                                         'attributes' => json_encode($image_final),
        //     //                                                         'choice_options' => json_encode($image_final),
        //     //                                                         'colors'        => json_encode($image_final),
        //     //                                                         'variations'    => json_encode($image_final)
        //     //                                                     ]);



        //     // $test_images = $product_tes->p_images;
            
        //     // if($test_images)
        //     // {
        //     //     $images = explode(',',$test_images);
        //     //     $path = "uploads/products/photos/";
        //     //     foreach($images as $key2 => $img)
        //     //     {
        //     //         if($key2 == 0)
        //     //         {
        //     //             $image_final = $path.$img;
        //     //             $product_active = Product::where('name',$product_tes->p_name)->first();
        //     //             if($product_active)
        //     //             {
                            
        //     //             }
        //     //         }
                    
    
        //     //     }
        //     // }
            
        //     // dd(json_encode($image_final));

            

        // }
        
        // dd($products);
        
    }

    public function update()
    {
        $shippings = ShippingCharge::all();

        foreach($shippings as $key => $shipping)
        {
            if($shipping->sc_color == 'green')
            {
                ShippingCharge::where('sc_id',$shipping->sc_id)->update([
                                'sc_rate_5kg' => 15
                ]);
            }

            if($shipping->sc_color == 'yellow')
            {
                ShippingCharge::where('sc_id',$shipping->sc_id)->update([
                                'sc_rate_5kg' => 35
                ]);
            }
        }

    }

    public function aryasDbProductExtra()
    {
        $products_test = DB::connection('mysql3')->table('products_data')->get();
       

        foreach($products_test as $key => $product)
        {

            // if($product->p_sku == 'CB005')
            // {
                $products_extra = DB::connection('mysql3')->table('products_extra')->where('pr_prd_id',$product->pid)->first();
            //  dd($product->pid);
                if($products_extra)
                {
                    $my_product = Product::where('sku',$product->p_sku)->first();

                    if($my_product){

                        $pr_extra_save = ProductExtra::where('product_id',$my_product->id)->first();

                        if(!$pr_extra_save)
                        {
                            $pr_extra_save = new ProductExtra;
                        }

                        $pr_extra_save->product_id = $my_product->id;
                        $pr_extra_save->material = $products_extra->pe_material;

                        if($products_extra->pe_battery == 'yes')
                        {
                            $battery = 1;
                        }
                        else{
                            $battery = 0;
                        }
                        // $pr_extra_save->battery = $battery;

                        // $pr_extra_save->battery_type = $products_extra->pe_batry_type;

                        // $pr_extra_save->battery_qty = $products_extra->pe_batry_qnty;
                        $pr_extra_save->product_dimention = $products_extra->pe_prd_dimn;
                        $pr_extra_save->package_dimention = $products_extra->pe_pckg_dimn;
                        $pr_extra_save->age_for = $products_extra->pe_manuf_age;
                        // $pr_extra_save->country_of_origin = $products_extra->pe_country_orgin;
                        // $pr_extra_save->product_warning = $products_extra->pe_warning;
                        // $pr_extra_save->product_usage = $products_extra->pe_usage;
                        $pr_extra_save->product_weight = $product->p_weight;
                        $pr_extra_save->product_weight_unit = $products_extra->pe_wgt_unit;
                        // dd($products_extra->pe_wgt_unit);
                        // $pr_extra_save->package_include = $products_extra->pe_pckg_include;
                        $pr_extra_save->package_unit = $products_extra->pe_unit_pckg;
                        $pr_extra_save->product_unit = $products_extra->pe_unit_prod;
                        $pr_extra_save->save();

                    }
                }
            // }
             
             

        }

    }

    public function aryasDbProductMetadata()
    {
        $image_string = '158306703265.webp,158306703266.webp,158306703267.webp,158306703268.webp';
        $images = explode(',',$image_string);
                    $path = "uploads/products/photos/";
                    foreach($images as $key2 => $img)
                    {
                        if($key2 == 0)
                        {
                            $image_final = $path.$img;
                           
                        }
                        $image[] = $path.$img;

                        
        
                    } 
                dd(json_encode($image));
        // $del_product = Product::all();
        // foreach($del_product as $key => $dont_del)
        // {
        //     $delete = Product::where('sku',$dont_del->sku)->first();
        //     Product::where('sku', $dont_del->sku)->where('id', '!=', $delete->id)->delete();
        // }



        // dd('done');
        $products_test = DB::connection('mysql3')->table('products_data')->get();
        foreach($products_test as $key => $product)
        {
            $my_product = Product::where('name',$product->p_name)->first();
            $image = array();
            if($my_product){
                $meta_pro = DB::connection('mysql3')->table('meta_data')->where('m_prd_id',$product->pid)->first();
                if(is_null($my_product->photos))
                {
                    $images = explode(',',$product->p_images);
                    $path = "uploads/products/photos/";
                    foreach($images as $key2 => $img)
                    {
                        if($key2 == 0)
                        {
                            $image_final = $path.$img;
                           
                        }
                        $image[] = $path.$img;

                        
        
                    } 

                    $my_product->photos = (json_encode($image));
                    if($product->p_main_image != '')
                    {
                        $my_product->thumbnail_img = $path.$product->p_main_image;
                    }
                    else{
                        $my_product->thumbnail_img = $image[0];
                    }
                    
                    $my_product->save();
                }
                if($meta_pro){

                    $save_my_meta = new ProductMetadata;
                    $save_my_meta->product_id = $my_product->id;

                    $save_my_meta->m_title = $meta_pro->m_title;
                    $save_my_meta->m_mdesc = $meta_pro->m_mdesc;
                    $save_my_meta->m_mkeywrd = $meta_pro->m_mkeywrd;
                    $save_my_meta->m_robot = $meta_pro->m_robot;
                    $save_my_meta->m_cpyrgt = $meta_pro->m_cpyrgt;
                    $save_my_meta->m_og_title = $meta_pro->m_og_title;
                    $save_my_meta->m_og_desc = $meta_pro->m_og_desc;
                    $save_my_meta->m_dc_title = $meta_pro->m_dc_title;
                    $save_my_meta->m_dc_desc = $meta_pro->m_dc_desc;
                    $save_my_meta->m_dc_sub = $meta_pro->m_dc_sub;
                    $save_my_meta->m_dc_crtor = $meta_pro->m_dc_crtor;
                    $save_my_meta->m_dc_crtd = $meta_pro->m_dc_crtd;
                    $save_my_meta->m_dc_modified = $meta_pro->m_dc_modified;
                    $save_my_meta->m_dc_type = $meta_pro->m_dc_type;
                    $save_my_meta->m_dc_type_img = $meta_pro->m_dc_type_img;
                    $save_my_meta->m_dc_lang = $meta_pro->m_dc_lang;
                    $save_my_meta->m_dc_format = $meta_pro->m_dc_format;
                    $save_my_meta->m_dc_filename = $meta_pro->m_dc_filename;
                    $save_my_meta->m_sts = $meta_pro->m_sts;

                    $save_my_meta->save();

                }

            }
        }
    }

    public function decryptOldDbUserPass()
    {
        // $data = 'N09UTjljOWp4RUpEa25jTjlCKzJ3Zz09';
        // $keys = 'thr33SeasInFoLogiCs';
        // $encryption_key = base64_decode($keys);
        // // Log::info($user->ul_email);
        // list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
        // $pass =  openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);

        // dd($pass);
        $users = DB::connection('mysql3')->table('user_login')->get();
       

        foreach($users as $key => $user)
        {
            // dd(explode('::', base64_decode($user->ul_pwd), 2));
            
            
            // dd($pass);
            $my_user = User::where('email',$user->ul_email)->first();

            if(!$my_user)
            {
                $keys = 'thr33SeasInFoLogiCs';
            $encryption_key = base64_decode($keys);
            Log::info($user->ul_email);
            list($encrypted_data, $iv) = explode('::', base64_decode($user->ul_pwd), 2);
            $pass =  openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);
                $my_user_save = User::where('email',$user->ul_email)->first();
                if(!$my_user_save)
                {
                    $my_user_save = new User;
                }
                
                
                $user_details = DB::connection('mysql3')->table('user_reg_details')->where('reg_session_id',$user->ul_email)->first();

                if($user_details)
                {
                    $my_user_save->phone = $user_details->reg_phone;
                    $my_user_save->address = $user_details->reg_adrs1 . $user_details->reg_adrs2;
                    $my_user_save->country = $user_details->reg_country;
                    $my_user_save->city = $user_details->reg_state;

                }
                
                $my_user_save->email = $user->ul_email;
                $my_user_save->name = $user->ul_name;
                $my_user_save->password = Hash::make($user->ul_pwd);
                // $my_user_save->email = $user->ul_email;
                $my_user_save->email_verified_at  = '2018-12-11 22:00:00';
                $my_user_save->save();

            }
            else{
                // $my_user->email_verified_at  = '2018-12-11 22:00:00';
                // $my_user->save();
            }

        } 
       








    }


    public function updateProductsStocksFromPOS()
    {
        $products_pos = DB::connection('mysql2')->table('products')->get();

        foreach($products_pos as $key => $product_pos)
        {
            if($product_pos->type =='single')
            {
                
                $get_variation_det = DB::connection('mysql2')->table('variation_location_details')->where('product_id',$product_pos->id)->where('location_id',10)->first();
                
                
                if($get_variation_det)
                {
                

                    $active_product = Product::where('sku',$product_pos->sku)->first();
                    
                    if($active_product)
                    {
                      
                        $active_product->current_stock = $get_variation_det->qty_available;
                        
                        $active_product->save();
                    }
                }

            }

            else{
                $get_variation_det = DB::connection('mysql2')->table('variation_location_details')->where('product_id',$product_pos->id)->where('location_id',10)->get();
                foreach($get_variation_det as $key2 => $variation_det)
                {
                    
                    $get_variation = DB::connection('mysql2')->table('variations')->where('id',$variation_det->variation_id)->first();

                    $var = $get_variation->name;
                    $var = str_replace(' ','',$var);
                   
                    $active_product_stock = ProductStock::where('variant',$var)->first();
                   
                    if($active_product_stock)
                    {
                        $active_product_stock->qty = $variation_det->qty_available;
                        $active_product_stock->save();
                    }
                }

            }
        }

    }

    public function centuryApiStatus()
    {
        // $client = new SoapWrapper("https://centuryexpress.me/webservice/webservice.php?wsdl"); 
        // $in = array("BookingNumber" => "44001285");
        // $result= $client->call("GetStatusDetails",$in);

        // dd($result);

        // $soapWrapper = new SoapWrapper;
        // $soapWrapper->add('GetStatusDetails', function ($service) {
        //     $service
        //       ->wsdl('https://centuryexpress.me/webservice/webservice.php?wsdl')
        //       ->trace(true)
        //       ->classmap([
        //         GetStatusDetailsRequest::class,
        //         GetStatusDetailsResponse::class,

                
        //       ]);
        //   });


        //   $response = $soapWrapper->call('GetStatusDetails.GetStatusDetails', [
        //     'BookingNumber' => '4679928', 
            
        //   ]);


        // $this->soapWrapper->add('Status', function ($service) {
        //     $service
        //       ->wsdl('https://centuryexpress.me/webservice/webservice.php?wsdl')
        //       ->trace(true);
        //     });

        //     $data = $this->soapWrapper->call('Status.GetStatusDetails', [[
        //         'BookingNumber' => '4679928'
        //   ]]);
        // SoapClient

        // $client = new SoapClient("https://centuryexpress.me/webservice/webservice.php?wsdl");
        // $in = array("BookingNumber" => "4795003");
        // $result= $client->__soapCall("GetStatusDetails",$in); 

       
        

        //   dd($abc);
    }

    public function checkPosAndActivePrice()
    {
        $products_pos = DB::connection('mysql2')->table('products')->get();

        foreach($products_pos as $key => $product_pos)
        {
            if($product_pos->type =='single')
            {
                $active_product = Product::where('sku',$product_pos->sku)->first();
                if($active_product)
                {
                    $var_amt = DB::connection('mysql2')->table('variations')->where('product_id', $product_pos->id)->first();
                    if($active_product->unit_price == $var_amt->sell_price_inc_tax)
                    {
                        // Log::info('');
                        // Log::info('pos sku---'.$product_pos->sku.'----pos p amt---'.$var_amt->sell_price_inc_tax.'----active amount----'.$active_product->unit_price);

                    }
                    else{

                        // $active_product->unit_price = $var_amt->sell_price_inc_tax;
                        // $active_product->save();

                        Log::info('pos sku---'.$product_pos->sku.'----pos p name---'.$product_pos->name);
                    }
                }
            }
            
            
        }
    }

    public function metaFileCreate(){

        $products = Product::all();
        
        foreach($products as $key => $product)
        {
            $meta_data = ProductMetadata::where('product_id',$product->id)->first();
            $meta_data->updated_at = date('Y-m-d H:i:s');
            $meta_data->save();
            if($meta_data)
            {
                $abc = view('invoices.rdf', compact('meta_data'))->render();
            
                Storage::disk('local')->put('rdf/prd_'. $meta_data->product_id .'.rdf', $abc);
            }
            else{

                $meta_data = new ProductMetadata;

                $meta_data->product_id = $product->id;
                // dd($request->meta_title);
                $meta_data->m_title = '';
                $meta_data->m_mdesc = '';
        
                
                    $meta_data->m_title = '';
                
        
                
                    $meta_data->m_mdesc = '';
                
        
                $meta_data->m_mkeywrd = '';
                $meta_data->m_robot = '';
                $meta_data->m_cpyrgt = '';
                $meta_data->m_dc_title = '';
                $meta_data->m_dc_desc = '';
                $meta_data->m_dc_sub = '';
                $meta_data->m_dc_crtor = '';
                $meta_data->m_dc_type = '';
                $meta_data->m_dc_type_img = '';
                $meta_data->m_dc_lang = '';
                $meta_data->m_dc_format = '';
                $meta_data->save();
        
                
                
                $abc = view('invoices.rdf', compact('meta_data'))->render();
            
                Storage::disk('local')->put('rdf/prd_'. $meta_data->product_id .'.rdf', $abc);

            }
            
        }

        
        
    }

    public function toWebp()
    {
        
        $files = Storage::disk('local')->files('uploads/produts/thumbnail');
        // dd($files);
        foreach($files as $file)
        {
            $storagePath = Storage::disk('local')->path($file);
            // $storagePath = Storage::disk('local')->getAdapter()->applyPathPrefix($file);
            // $extension = realpath($file);
            $mim_type = Storage::mimeType($file);
            // dd($mim_type);
            $type_explode = explode('/',$mim_type);

            $name = pathinfo($file, PATHINFO_FILENAME);
            // dd($name);
            $explode = explode('.',$file);
            if(($explode[1] == 'jpeg' || $explode[1] == 'jpg'|| $explode[1] == 'webp') && ($type_explode[1] == 'jpeg' || $type_explode[1] == 'jpg'  || $type_explode[1] == 'webp'))
            {
                
              $image = imagecreatefromjpeg($storagePath);
                
            }
            elseif($explode[1] == 'png' && $type_explode[1] == 'png')
            {
                $image = imagecreatefrompng($storagePath);
            }

            imagewebp($image,  Storage::disk('local')->path($explode[0]).'.webp', '50');
            
            // dd($file);
            // $extension = pathinfo($source, PATHINFO_EXTENSION);
        }

        
    }

    public function send_message()
    {
        dd('here');
       
        
    }

    public function unPublish()
    {
        $products = Product::all();
        foreach($products as $key => $product)
        {
            $product_dup = Product::where('sku',$product->sku)->get();

            if($product_dup->count() > 1)
            {
                Log::info('duplicat pid -- '.$product->name);
            }
            $products_pos = DB::connection('mysql2')->table('products')->where('sku',$product->sku)->first();
            if($products_pos)
            {
                if($products_pos->type == 'single')
                {
                    $variation_detail = DB::connection('mysql2')->table('variation_location_details')->where('product_id',$products_pos->id)->where('location_id',10)->first();
                    if($variation_detail)
                    {
                        if($variation_detail->qty_available == 0)
                        {   
                            $products->published = 0;
                            $product->save();
                            Log::info('product id -- '.$products->id);
                        }
                    }

                }

            }
        }
    }


    public function bulkAddSubsubcategory()
    {
        $products = Product::all();

        foreach($products as $key => $product)
        {
            if($product->category_id == 5 || $product->category_id == 10)
            {
                $product_update = Product::where('id',$product->id)->first();
                    $product->category_id = 4;
                    $subsubcat = array();
                    $sub_cat = json_decode($product->subcategory_id);
                    $options_sub_cat = array();
                    $check_sub = is_array($sub_cat);
                    if($check_sub == true)
                    {
                        foreach($sub_cat as $subbbcat)
                        {
                            
                            // $sub_cattt = strval($subbbcat);
                        
                            if($subbbcat == 14)
                            {
                                
                                array_push($subsubcat,"31");
                            }
                            if($subbbcat == 15)
                            {
                                array_push($subsubcat,"32");
                            }
                            if($subbbcat == 16)
                            {
                                array_push($subsubcat,"33");
                            }
                            if($subbbcat == 30)
                            {
                                array_push($subsubcat,"34");
                            }
                            if($product->category_id == 5)
                            {
                                array_push($options_sub_cat, "35");
                            }
                            if($product->category_id == 10)
                            {
                                array_push($options_sub_cat, "36");
                            }
                            
                            

                            
                        }

                        $product_update->subcategory_id = json_encode($options_sub_cat);
                        $product_update->subsubcategory_id = json_encode($subsubcat);
                        // dd(json_encode($subsubcat));
                        $product_update->save();


                    }
                    else{
                       
                        $sub_cat = strval($sub_cat);
                        
                        if($sub_cat == 14)
                        {
                             array_push($subsubcat,"31");
                        }
                        if($sub_cat == 15)
                        {
                            array_push($subsubcat,"32");
                        }
                        if($sub_cat == 16)
                        {
                            array_push($subsubcat,"33");
                        }
                        if($sub_cat == 30)
                        {
                            array_push($subsubcat,"34");
                        }
                        array_push($options_sub_cat, $sub_cat);
                        if($product->category_id == 5)
                        {
                            array_push($options_sub_cat,"35");
                        }
                        if($product->category_id == 10)
                        {
                            array_push($options_sub_cat,"36");
                        }

                        $product_update->subcategory_id = json_encode($options_sub_cat);
                    $product_update->subsubcategory_id = json_encode($subsubcat);
                    
                    $product_update->save();
                        
                    }
                    // dd($options_sub_cat);
                    
                
                    
            }
        }
    }

    public function change()
    {
        $products = Product::all();
        $options_sub_cat = array();
        foreach($products as $key => $product)
        {
            $product_update = Product::where('id',$product->id)->first();
            

            if($product->category_id == 5)
            {
               
                array_push($options_sub_cat,"35");
                $product_update->subcategory_id = json_encode($options_sub_cat);
            }
            if($product->category_id == 10)
            {
               
                array_push($options_sub_cat,"36");
                $product_update->subcategory_id = json_encode($options_sub_cat);
            }
            $product_update->save();

        }


        // foreach($products as $key => $product)
        // {
        //     $products_test = DB::connection('mysql3')->table('products_data')->where('p_sku',$product->sku)->first();
        //     if($products_test)
        //     {
        //         if($products_test->p_cat == 6)
        //         {
        //             $prd = Product::where('sku',$product->sku)->first();
        //             $prd->category_id = 5;
        //             // $prd->save();
        //         }

        //         if($products_test->p_cat == 33)
        //         {
        //             $prd = Product::where('sku',$product->sku)->first();
        //             $prd->category_id = 32;
        //             // $prd->save();
        //         }
        //     }
        // }
        

        
    }

    public function updateEdu()
    {
        $products = Product::all();
        foreach($products as $key => $product)
        {
            if($product->sku == 'TWC005')
            {
                $old_subcat = $product->subcategory_id;
            }
        }
    }

    public function UpdateHomeShow()
    {
        $file_url = Storage::path('Book3.xlsx');

        $Reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        $spreadSheet = $Reader->load($file_url);
        
        $excelSheet = $spreadSheet->getActiveSheet();
        $spreadSheetAry = $excelSheet->toArray();
        $sheetCount = count($spreadSheetAry);
        
        for ($i = 0; $i <= $sheetCount; $i ++) {

            if (isset($spreadSheetAry[$i][0])) {
                $product = Product::where('id',$spreadSheetAry[$i][0])->first();

                if($product)
                {
                    if(isset($spreadSheetAry[$i][2]))
                    {
                        $product->home_page_show = $spreadSheetAry[$i][2];
                        $product->save();
                    }
                }
            }
        }
    }


    public function UpdateArea()
    {
        $file_url = Storage::path('area.xlsx');

        $Reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        $spreadSheet = $Reader->load($file_url);
        
        $excelSheet = $spreadSheet->getActiveSheet();
        $spreadSheetAry = $excelSheet->toArray();
        $sheetCount = count($spreadSheetAry);
        
        for ($i = 0; $i <= $sheetCount; $i ++) {

            if (isset($spreadSheetAry[$i][0])) {
                $shipping_area = ShippingCharge::where('sc_town',$spreadSheetAry[$i][0])->first();

                if($shipping_area)
                {
                    
                }
                else
                {
                    $add_shipping_area = new ShippingCharge;
                    if(isset($spreadSheetAry[$i][0]))
                    {
                        $add_shipping_area->sc_town = $spreadSheetAry[$i][0];
                    }
                    if(isset($spreadSheetAry[$i][1]))
                    {
                        $add_shipping_area->sc_emirate = $spreadSheetAry[$i][1];
                    }
                    if(isset($spreadSheetAry[$i][2]))
                    {
                        $add_shipping_area->sc_zone = $spreadSheetAry[$i][2];
                    }
                    if(isset($spreadSheetAry[$i][6]))
                    {
                        if($spreadSheetAry[$i][6] == 35)
                        {
                            $add_shipping_area->sc_rate_5kg = 15;
                            $add_shipping_area->sc_add_1kg = 1;
                            $add_shipping_area->sc_schedule = $spreadSheetAry[$i][5];
                            $add_shipping_area->sc_return_charge = $spreadSheetAry[$i][6];
                            $add_shipping_area->sc_color = 'green';
                            $add_shipping_area->sc_sts = 1;

                        }
                        else if($spreadSheetAry[$i][6] == 80)
                        {
                            $add_shipping_area->sc_rate_5kg = 35;
                            $add_shipping_area->sc_add_1kg = 1;
                            $add_shipping_area->sc_schedule = $spreadSheetAry[$i][5];
                            $add_shipping_area->sc_return_charge = $spreadSheetAry[$i][6];
                            $add_shipping_area->sc_color = 'yellow';
                            $add_shipping_area->sc_sts = 1;
                        }
                        else
                        {
                            $add_shipping_area->sc_rate_5kg = 0;
                            $add_shipping_area->sc_add_1kg = 0;
                            $add_shipping_area->sc_schedule = $spreadSheetAry[$i][5];
                            $add_shipping_area->sc_return_charge = 0;
                            $add_shipping_area->sc_color = 'red';
                            $add_shipping_area->sc_sts = 1;  
                        }
                        $add_shipping_area->save();
                    }
                }
            }
        }
    }

    public function compress() {

       
        $source = Storage::path('uploads/products/thumbnail');
        $files = glob($source.'/*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE);
        foreach($files as $file) {
            
            $explode = explode('uploads/',$file);
            // dd($explode);
            $source_img = Storage::path('uploads/'.$explode[1]);
            $destination_img = Storage::path('uploads/'.$explode[1]);

            $info = getimagesize($source_img);

            $filesize = filesize($source_img);
            // file size in kb
            $filesize = round($filesize / 1024 , 1);

            if ($info['mime'] == 'image/jpeg') 
            $image = imagecreatefromjpeg($source_img);
    
            elseif ($info['mime'] == 'image/gif') 
                $image = imagecreatefromgif($source_img);
        
            elseif ($info['mime'] == 'image/png') 
                $image = imagecreatefrompng($source_img);
                 elseif ($info['mime'] == 'image/webp') 
                $image = imagecreatefromwebp($source_img);
            if($filesize > 100)
            {
                imagejpeg($image, $destination_img, 30);
            }
            else if($filesize < 70 && $filesize > 50)
            {
                imagejpeg($image, $destination_img, 40);
            }
            else
            {
                imagejpeg($image, $destination_img, 50);
            }
            
        }
        
        
        
        

    }
    
    


    public function ReadXlFile()
    {

       
        $file_url = Storage::path('Book2.xlsx');


        $Reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        $spreadSheet = $Reader->load($file_url);

        $excelSheet = $spreadSheet->getActiveSheet();
        $spreadSheetAry = $excelSheet->toArray();
        $sheetCount = count($spreadSheetAry);


        for ($i = 0; $i <= $sheetCount; $i ++) {
            $name = "";
            if (isset($spreadSheetAry[$i][0])) {
               
                $product = Product::where('sku',$spreadSheetAry[$i][0])->first();

                if($product)
                {
                    
                    

                    if(isset($spreadSheetAry[$i][1]) || isset($spreadSheetAry[$i][2]) || isset($spreadSheetAry[$i][3]) || isset($spreadSheetAry[$i][4]) || isset($spreadSheetAry[$i][5]))
                    {
                        $old_subcat_id = json_decode($product->subcategory_id);
                        if($old_subcat_id)
                        {
                            if(is_array($old_subcat_id))
                            {
                                if(!in_array("33",$old_subcat_id))
                                {
                                    array_push($old_subcat_id,"33");
                                    $product->subcategory_id = json_encode($old_subcat_id);
                                    $product->save();
                                }
                                
                            }
                            else{
                                if($old_subcat_id != 33)
                                {
                                    $new_sub_cat = array();
                                    $old_subcat_id = strval($old_subcat_id);
                                    array_push($new_sub_cat,$old_subcat_id);
                                    array_push($new_sub_cat,"33");
                                    $product->subcategory_id = json_encode($new_sub_cat);
                                    $product->save();
                                }
                                
                            }
                        }
                        else
                        {
                            array_push($old_subcat_id,"33");
                            $product->subcategory_id = json_encode($old_subcat_id);
                            $product->save(); 
                        }

                        $old_sub_sub_cat_id = json_decode($product->subcategory_id);

                        if($old_sub_sub_cat_id)
                        {
                            if(is_array($old_sub_sub_cat_id))
                            {
                                $new_sub_sub_cat = array();
                                if(isset($spreadSheetAry[$i][1]))
                                {
                                    $sub_sub1 = strval($spreadSheetAry[$i][1]);
                                    if(!in_array($sub_sub1,$old_sub_sub_cat_id))
                                    {
                                        
                                        array_push($new_sub_sub_cat,$sub_sub1);
                                    }
                                    
                                }
                                if(isset($spreadSheetAry[$i][2]))
                                {
                                    $sub_sub2 = strval($spreadSheetAry[$i][2]);
                                    if(!in_array($sub_sub2,$old_sub_sub_cat_id))
                                    {
                                        
                                        array_push($new_sub_sub_cat,$sub_sub2);
                                    }
                                    
                                }
                                if(isset($spreadSheetAry[$i][3]))
                                {
                                    $sub_sub3 = strval($spreadSheetAry[$i][3]);
                                    if(!in_array($sub_sub3,$old_sub_sub_cat_id))
                                    {
                                        
                                        array_push($new_sub_sub_cat,$sub_sub3);
                                    }
                                }
                                if(isset($spreadSheetAry[$i][4]))
                                {
                                    $sub_sub4 = strval($spreadSheetAry[$i][4]);
                                    if(!in_array($sub_sub4,$old_sub_sub_cat_id))
                                    {
                                        
                                        array_push($new_sub_sub_cat,$sub_sub4);
                                    }
                                }
                                if(isset($spreadSheetAry[$i][5]))
                                {
                                    $sub_sub5 = strval($spreadSheetAry[$i][5]);
                                    if(!in_array($sub_sub5,$old_sub_sub_cat_id))
                                    {
                                        
                                        array_push($new_sub_sub_cat,$sub_sub5);
                                    }
                                }
                                
                              $product->subsubcategory_id = json_encode($new_sub_sub_cat);
                              $product->save();
                            }
                            else{
                                $new_sub_sub_cat = array();
                                $old_sub_sub_cat_id = strval($old_sub_sub_cat_id);
                                array_push($new_sub_sub_cat,$old_sub_sub_cat_id);
                                

                                
                                if(isset($spreadSheetAry[$i][1]))
                                {
                                    $sub_sub1 = strval($spreadSheetAry[$i][1]);
                                    if($old_sub_sub_cat_id != $sub_sub1)
                                    {
                                        array_push($new_sub_sub_cat,$sub_sub1);
                                    }

                                    
                                }
                                if(isset($spreadSheetAry[$i][2]))
                                {
                                    $sub_sub2 = strval($spreadSheetAry[$i][2]);
                                    if($old_sub_sub_cat_id != $sub_sub2)
                                    {
                                        array_push($new_sub_sub_cat,$sub_sub2);
                                    }
                                }
                                if(isset($spreadSheetAry[$i][3]))
                                {
                                    $sub_sub3 = strval($spreadSheetAry[$i][3]);
                                    if($old_sub_sub_cat_id != $sub_sub3)
                                    {
                                        array_push($new_sub_sub_cat,$sub_sub3);
                                    }
                                }
                                if(isset($spreadSheetAry[$i][4]))
                                {
                                    $sub_sub4 = strval($spreadSheetAry[$i][4]);
                                    if($old_sub_sub_cat_id != $sub_sub4)
                                    {
                                        array_push($new_sub_sub_cat,$sub_sub4);
                                    }
                                }
                                if(isset($spreadSheetAry[$i][5]))
                                {
                                    $sub_sub5 = strval($spreadSheetAry[$i][5]);
                                    if($old_sub_sub_cat_id != $sub_sub5)
                                    {
                                        array_push($new_sub_sub_cat,$sub_sub5);
                                    }
                                }
                                
                                 $product->subsubcategory_id = json_encode($new_sub_sub_cat);
                                 $product->save();
                            }
                        }
                        else
                        {
                            $new_sub_sub_cat = array();
                            if(isset($spreadSheetAry[$i][1]))
                            {
                                $sub_sub1 = strval($spreadSheetAry[$i][1]);
                                array_push($new_sub_sub_cat,$sub_sub1);
                            }
                            if(isset($spreadSheetAry[$i][2]))
                            {
                                $sub_sub2 = strval($spreadSheetAry[$i][2]);
                                array_push($new_sub_sub_cat,$sub_sub2);
                            }
                            if(isset($spreadSheetAry[$i][3]))
                            {
                                $sub_sub3 = strval($spreadSheetAry[$i][3]);
                                array_push($new_sub_sub_cat,$sub_sub3);
                            }
                            if(isset($spreadSheetAry[$i][4]))
                            {
                                $sub_sub4 = strval($spreadSheetAry[$i][4]);
                                array_push($new_sub_sub_cat,$sub_sub4);
                            }
                            if(isset($spreadSheetAry[$i][5]))
                            {
                                $sub_sub5 = strval($spreadSheetAry[$i][5]);
                                array_push($new_sub_sub_cat,$sub_sub5);
                            }
                            
                          $product->subsubcategory_id = json_encode($new_sub_sub_cat);
                          $product->save();
                        }
                        // dd($product);
                    }
                }
            }

            
            $description = "";
            

            // if (! empty($name) || ! empty($description)) {
            //     $query = "insert into tbl_info(name,description) values(?,?)";
            //     $paramType = "ss";
            //     $paramArray = array(
            //         $name,
            //         $description
            //     );
            //     $insertId = $db->insert($query, $paramType, $paramArray);
            //     // $query = "insert into tbl_info(name,description) values('" . $name . "','" . $description . "')";
            //     // $result = mysqli_query($conn, $query);

            //     if (! empty($insertId)) {
            //         $type = "success";
            //         $message = "Excel Data Imported into the Database";
            //     } else {
            //         $type = "error";
            //         $message = "Problem in Importing Excel Data";
            //     }
            // }
        }

        dd($sheetCount);
        
        // $data = Excel::load($file_url, function($reader) {})->get();
        // dd($data);
        // if(!empty($data) && $data->count()){

        //     foreach ($data->toArray() as $key => $value) {

        //         if(!empty($value)){

        //             foreach ($value as $v) {        

        //                 $insert[] = ['title' => $v['title'], 'description' => $v['description']];

        //             }
        //         }
        //     }

        //     if(!empty($insert)){
        //         Item::insert($insert);
        //         return back()->with('success','Insert Record successfully.');
        //     }
        // }
    }

    public function emailSendCheck()
    {
        $array['content'] = "Test mail sent from Berry";
        $array['view'] = 'emails.newsletter';
        $array['subject'] = 'Testing from Berry';
        $array['from'] = 'noreply@birigroup.com';
        $send_to = ['jasimogral@hotmail.com','jasimogral@outlook.com'];
        Mail::to($send_to)->bcc('jasimogral@gmail.com','jasimogral@yahoo.com')->queue(new EmailManager($array));
        Log::info('send');
    }


    public function apiTest()
    {
        $header = ["accept: application/json"];
        // $data_pass = array_merge($data1);  
                // dd(array_merge($data1,$params));
            // dd(date('m/d/yy H:i'));
        $data1 = 65;
        $curl = curl_init();
        $url="http://127.0.0.1:8000/api/sales-update-website";
        // dd($url);
        curl_setopt_array($curl, array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_TIMEOUT => 30000,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $data1,
          CURLOPT_HTTPHEADER => array(
            "Authorization: 55784c3suNSIlFmrh4VfQKFMlwMifMHXfCkW",
            "accept: application/json"
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
          //echo "cURL Error #:" . $err;
            $res=$err;
        } else {
          $res= json_decode($response, true);
        } 
            dd($res);
    }

    public function apiDataToPos()
    {
        $data = array();

        $data['location_id'] = 10;
        $data['price_group'] = 0;
        $data['default_price_group'] = 0;
        $data['contact_id'] = 86;
        $data['pay_term_number'] = null;
        $data['pay_term_type'] = null;
        $data['transaction_date'] = date('m/d/yy H:i');
        $data['status'] = 'final';
        $data['invoice_scheme_id'] = 1;
        $data['search_product'] = null;
        $data['sell_price_tax'] = 'includes';
        $data['products'] = 1;
        $data['invoice_scheme_id'] = 1;

        
    }

    public function updateRedirection()
    {
        $products = Product::all();

        foreach($products as $key => $product)
        {
           $redirection = new Redirection;
           $redirection->page_name = $product->name;
           $redirection->new_url = 'product/'.$product->slug;
           $redirection->save();
        }
    }

    public function testingTree()
    {
        
        return view('frontend.test');
    }

    public function fetchingTree(Request $request)
    {
        $query = DB::connection('mysql')->select(DB::raw('SELECT * FROM country_state_city'));
            
            // $output = array();
            Log::info('here');
            foreach($query as $key => $row)
            {
                if(isset($row->id))
                {
                    Log::info('here2');
                
                $sub_data["id"] = $row->id;
                $sub_data["name"] = $row->name;
                $sub_data["text"] = $row->name;
                $sub_data["parent_id"] = $row->parent_id;
                $data[] = $sub_data;
                }
                
            }
            
            foreach($data as $key => &$value)
            {
                    // dd($value);
                    Log::info('here3');
                    $output[$value['id']] = &$value;
                
            }
            foreach($data as $key => &$value)
            {
                 
                    if($value['parent_id'] && isset($output[$value['parent_id']]))
                    {
                        Log::info('here4');
                        $output[$value['parent_id']]["nodes"][] = &$value;
                    }
                
            }
            foreach($data as $key => &$value)
            {
                if(isset($value['parent_id']))
                { 
                    if($value['parent_id'] && isset($output[$value['parent_id']]))
                    {
                        Log::info('here5');
                    unset($data[$key]);
                    }
                }
            }
            return json_encode($data);
    }


   
}
