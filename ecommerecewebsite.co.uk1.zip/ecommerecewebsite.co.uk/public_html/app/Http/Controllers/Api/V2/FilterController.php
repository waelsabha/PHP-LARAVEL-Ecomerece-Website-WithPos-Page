<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Resources\V2\BrandCollection;
use App\Http\Resources\V2\CategoryCollection;
use App\Models\Brand;
use App\Models\Category;


class FilterController extends Controller
{
    public function categories()
    {
        //if you want to show base categories
        return new CategoryCollection(Category::where('parent_id', 0)->get());

        //if you want to show featured categories
        //return new CategoryCollection(Category::where('featured', 1)->get());
    }

    public function brands()
    {
        //show only top 20 brands
        return new BrandCollection(Brand::where('top', 1)->limit(20)->get());
    }

    public function categoriesOnId($id)
    {
        //if you want to show base categories
        $check = Category::where('id',$id)->first();
        if($check)
        {
            if($check->parent_id != 0)
            {
                return new CategoryCollection(Category::where('parent_id', $id)->get()); 
            }
            else{
    
                return new CategoryCollection(Category::where('parent_id',$id)->get());
            }
        }
        else{
            if($id == 0)
            {
                return new CategoryCollection(Category::where('parent_id', 0)->get());
            }
        }

    }

    public function categoriesMainId($id)
    {
        //if you want to show base categories
        $check = Category::where('id',$id)->first();
        if($check)
        {
            if($check->parent_id != 0)
            {
                return new CategoryCollection(Category::where('parent_id', $check->parent_id)->get()); 
            }
            else{
                return new CategoryCollection(Category::where('parent_id', 0)->get());
            }
        }
        else{
            return new CategoryCollection(Category::where('parent_id', 0)->get());
        }

    }


}
