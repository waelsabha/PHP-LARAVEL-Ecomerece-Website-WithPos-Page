<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Resources\V2\CartCollection;
use App\Models\Cart;
use App\Models\Color;
use App\Models\FlashDeal;
use App\Models\FlashDealProduct;
//use App\Models\Product;
use App\Models\ProductStock;
use App\Shop;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Product;
use App\Newsletter;
use Illuminate\Support\Facades\Log;

class CartController extends Controller
{
    public function summary($user_id, $owner_id)
    {
        $items = Cart::where('user_id', $user_id)->where('owner_id', $owner_id)->get();

        if ($items->isEmpty()) {
            return response()->json([
                'sub_total' => format_price(0.00),
                'tax' => format_price(0.00),
                'shipping_cost' => format_price(0.00),
                'discount' => format_price(0.00),
                'grand_total' => format_price(0.00),
                'grand_total_value' => 0.00,
                'coupon_code' => "",
                'coupon_applied' => false,
                
            ]);
        }

        $sum = 0.00;
        $sub_total = 0.00;
        foreach ($items as $cartItem) {
            $sub_total += ($cartItem->price + $cartItem->tax) * $cartItem->quantity;
            $item_sum = 0;
            $item_sum += ($cartItem->price + $cartItem->tax) * $cartItem->quantity;
            // $item_sum += $cartItem->shipping_cost - $cartItem->discount;
            $sum +=  $item_sum - $cartItem->discount ;   //// 'grand_total' => $request->g
        }

        

        $get_shipping_cost = Cart::where('user_id', $user_id)->where('owner_id', $owner_id)->first();
        $shipping_cost =$get_shipping_cost->shipping_cost;
        if($sum >= 100)
        {
            $shipping_cost = 0;
            $get_shipping_cost_all = Cart::where('user_id', $user_id)->where('owner_id', $owner_id)->get();
            foreach($get_shipping_cost_all as $key => $single_shipping_co)
            {
                Cart::where('id',$single_shipping_co->id)->update(['shipping_cost' => 0.00]);
            }
            
        }
        $sum +=  $shipping_cost;
        return response()->json([
            'sub_total' => format_price($sub_total),
            'tax' => format_price($items->sum('tax')),
            'shipping_cost' => format_price($shipping_cost),
            'discount' => format_price($items->sum('discount')),
            'grand_total' => format_price($sum),
            'grand_total_value' => convert_price($sum),
            'coupon_code' => $items[0]->coupon_code,
            'coupon_applied' => $items[0]->coupon_applied == 1,
           
        ]);


    }
    
    public function summaryGuest($device_id, $owner_id)
    {
        $items = Cart::where('device_id', $device_id)->where('owner_id', $owner_id)->get();

        if ($items->isEmpty()) {
            return response()->json([
                'sub_total' => format_price(0.00),
                'tax' => format_price(0.00),
                'shipping_cost' => format_price(0.00),
                'discount' => format_price(0.00),
                'grand_total' => format_price(0.00),
                'grand_total_value' => 0.00,
                'coupon_code' => "",
                'coupon_applied' => false,
                
            ]);
        }

        $sum = 0.00;
        $sub_total = 0.00;
        
        foreach ($items as $cartItem) {
            $sub_total += ($cartItem->price + $cartItem->tax) * $cartItem->quantity;
            $item_sum = 0;
            $item_sum += ($cartItem->price + $cartItem->tax) * $cartItem->quantity;
            // $item_sum += $cartItem->shipping_cost - $cartItem->discount;
            $sum +=  $item_sum - $cartItem->discount ;   //// 'grand_total' => $request->g
        }

        $get_shipping_cost = Cart::where('device_id', $device_id)->where('owner_id', $owner_id)->first();
        $shipping_cost =$get_shipping_cost->shipping_cost;
        if($sum >= 100)
        {
            $shipping_cost = 0;
            $get_shipping_cost_all = Cart::where('device_id', $device_id)->where('owner_id', $owner_id)->get();
            foreach($get_shipping_cost_all as $key => $single_shipping_co)
            {
                Cart::where('id',$single_shipping_co->id)->update(['shipping_cost' => 0.00]);
            }
        }
        $sum +=  $shipping_cost;
        return response()->json([
            'sub_total' => format_price($sub_total),
            'tax' => format_price($items->sum('tax')),
            'shipping_cost' => format_price($shipping_cost),
            'discount' => format_price($items->sum('discount')),
            'grand_total' => format_price($sum),
            'grand_total_value' => round(convert_price($sum),2),
            'coupon_code' => $items[0]->coupon_code,
            'coupon_applied' => $items[0]->coupon_applied == 1,
           
        ]);


    }

    public function getList($user_id,$device_id=null)
    {
        Log::info('-----device Id ------');
        Log::info($device_id);
        if($device_id != null)
        {
            $cart_items_device = Cart::where('device_id',$device_id)->get();
            if(!empty($cart_items_device)){
                foreach($cart_items_device as $key => $cart_item_device){
                    Cart::where('id',$cart_item_device->id)->update(['user_id'=>$user_id,'device_id'=>NULL]);
                }
            }
        }
        
        $owner_ids = Cart::where('user_id', $user_id)->select('owner_id')->groupBy('owner_id')->pluck('owner_id')->toArray();
        $currency_symbol = currency_symbol();
        $shops = [];
        if (!empty($owner_ids)) {
            foreach ($owner_ids as $owner_id) {
                $shop = array();
                $shop_items_raw_data = Cart::where('user_id', $user_id)->where('owner_id', $owner_id)->get()->toArray();
                $shop_items_data = array();
                if (!empty($shop_items_raw_data)) {
                    foreach ($shop_items_raw_data as $shop_items_raw_data_item) {
                        $product = Product::where('id', $shop_items_raw_data_item["product_id"])->first();
                        $shop_items_data_item["id"] = intval($shop_items_raw_data_item["id"]) ;
                        $shop_items_data_item["owner_id"] =intval($shop_items_raw_data_item["owner_id"]) ;
                        $shop_items_data_item["user_id"] =intval($shop_items_raw_data_item["user_id"]) ;
                        $shop_items_data_item["product_id"] =intval($shop_items_raw_data_item["product_id"]) ;
                        $shop_items_data_item["product_name"] = $product->name .' '. $shop_items_raw_data_item["variation"];
                        if($product->variant_product == 1)
                        {
                            $product_stock = ProductStock::where('product_id', $shop_items_raw_data_item["product_id"])->where('variant',$shop_items_raw_data_item["variation"])->first();
                            $var_images = json_decode($product_stock->variant_image);
                            //Log::info($var_images[0]);
                            $shop_items_data_item["product_thumbnail_image"] = $var_images[0];
                        }
                        else
                        {
                            $shop_items_data_item["product_thumbnail_image"] = ($product->thumbnail_img);
                        }
                        
                        $shop_items_data_item["variation"] = $shop_items_raw_data_item["variation"];
                        $shop_items_data_item["price"] =(double) $shop_items_raw_data_item["price"];
                        $shop_items_data_item["currency_symbol"] = $currency_symbol;
                        $shop_items_data_item["tax"] =(double) $shop_items_raw_data_item["tax"];
                        $shop_items_data_item["shipping_cost"] =(double) $shop_items_raw_data_item["shipping_cost"];
                        $shop_items_data_item["quantity"] =intval($shop_items_raw_data_item["quantity"]) ;
                        $shop_items_data_item["lower_limit"] = intval($product->min_qty) ;
                        if($product->variant_product == 1)
                        {
                            $shop_items_data_item["upper_limit"] = intval($product->stocks->where('variant', $shop_items_raw_data_item['variation'])->first()->qty);
                        }
                        else
                        {
                            $shop_items_data_item["upper_limit"] = intval($product->current_stock);
                        }
                        //$shop_items_data_item["upper_limit"] = intval($product->stocks->where('variant', $shop_items_raw_data_item['variation'])->first()->qty) ;

                        $shop_items_data[] = $shop_items_data_item;

                    }
                }


                $shop_data = Shop::where('user_id', $owner_id)->first();
                if ($shop_data) {
                    $shop['name'] = $shop_data->name;
                    $shop['owner_id'] =(int) $owner_id;
                    $shop['cart_items'] = $shop_items_data;
                } else {
                    $shop['name'] = "Inhouse";
                    $shop['owner_id'] =(int) $owner_id;
                    $shop['cart_items'] = $shop_items_data;
                }
                $shops[] = $shop;
            }
        }

        //dd($shops);

        return response()->json($shops);
    }

    public function getListGuest(Request $request)
    {
        $device_id = $request->device_id;
        $get_cart = Cart::where('device_id',$device_id)->get();
        foreach($get_cart as $key => $cart_items)
        {
            Log::info('inside foreach');
            Log::info('device id ----' .$device_id);
            Log::info('product id ----' .$cart_items->product_id);
            $get_product = Product::where('id',$cart_items->product_id)->first();
            Log::info('product name ----' .$get_product->name);
            if(!empty($get_product))
            {
                if($get_product->variant_product == 1){
                    $get_prod_var = ProductStock::where('product_id',$cart_items->product_id)->where('variant',$cart_items->variation)->first();
                    if($get_prod_var)
                    {
                        $qty_p = $get_prod_var->qty;
                        if($get_prod_var->qty == 0){
                            Cart::where('id', $cart_items->id)->delete();
                        } 
                    }
                }
                else{
                    $qty_p = $get_product->current_stock;
                    if($get_product->current_stock == 0){
                        Cart::where('id', $cart_items->id)->delete();
                    }
                }
            }
            else{
                Log::info('in else');
            }
            
        }
        
        $owner_ids = Cart::where('device_id', $device_id)->select('owner_id')->groupBy('owner_id')->pluck('owner_id')->toArray();
        $currency_symbol = currency_symbol();
        $shops = [];
        $shop_items_data_item =[];
        if (!empty($owner_ids)) {
            foreach ($owner_ids as $owner_id) {
                $shop = array();
                $shop_items_raw_data = Cart::where('device_id', $device_id)->where('owner_id', $owner_id)->get()->toArray();
                $shop_items_data = array();
                if (!empty($shop_items_raw_data)) {
                    foreach ($shop_items_raw_data as $shop_items_raw_data_item) {
                        $product = Product::where('id', $shop_items_raw_data_item["product_id"])->first();
                        $pro_price = $shop_items_raw_data_item["price"];
                        //Log::info('main price ----'.$pro_price);
                        if($product)
                        {
                            if($product->published != 0)
                            {
                                $discount_pr = home_discounted_base_price($shop_items_raw_data_item["product_id"]);
                                if($discount_pr > 0)
                                {
                                    if($shop_items_raw_data_item["price"] != $discount_pr)
                                    {
                                        $pro_price = $discount_pr;
                                    }
                                }
                                else{
                                    $pro_price = $product->unit_price;
                                }
                                
                                if($product->variant_product == 1)
                                {
                                    $product_stock = ProductStock::where('product_id', $shop_items_raw_data_item["product_id"])->where('variant',$shop_items_raw_data_item["variation"])->first();
                                    $var_images = json_decode($product_stock->variant_image);
                                    //Log::info($var_images[0]);
                                    $shop_items_data_item["product_thumbnail_image"] = $var_images[0];
                                    $product_qty = $product_stock->qty;
                                }
                                else
                                {
                                    $shop_items_data_item["product_thumbnail_image"] = ($product->thumbnail_img);
                                    $product_qty = $product->current_stock;
                                }
                                $shop_items_data_item["id"] = intval($shop_items_raw_data_item["id"]) ;
                                $shop_items_data_item["owner_id"] =intval($shop_items_raw_data_item["owner_id"]) ;
                                $shop_items_data_item["user_id"] =intval($shop_items_raw_data_item["device_id"]) ;
                                $shop_items_data_item["product_id"] =intval($shop_items_raw_data_item["product_id"]) ;
                                $shop_items_data_item["product_name"] = $product->name .' '. $shop_items_raw_data_item["variation"];

                                
                                $shop_items_data_item["variation"] = $shop_items_raw_data_item["variation"];
                                $shop_items_data_item["price"] =(double) $pro_price;
                                $shop_items_data_item["currency_symbol"] = $currency_symbol;
                                $shop_items_data_item["tax"] =(double) $shop_items_raw_data_item["tax"];
                                $shop_items_data_item["shipping_cost"] =(double) $shop_items_raw_data_item["shipping_cost"];
                                $shop_items_data_item["quantity"] =intval($shop_items_raw_data_item["quantity"]) ;
                                $shop_items_data_item["lower_limit"] = intval($product->min_qty) ;
                                if($product->variant_product == 1)
                                {
                                    $shop_items_data_item["upper_limit"] = intval($product->stocks->where('variant', $shop_items_raw_data_item['variation'])->first()->qty);
                                }
                                else
                                {
                                    $shop_items_data_item["upper_limit"] = intval($product->current_stock);
                                }
                                //$shop_items_data_item["upper_limit"] = intval($product->stocks->where('variant', $shop_items_raw_data_item['variation'])->first()->qty) ;

                                $shop_items_data[] = $shop_items_data_item;
                            }
                        }
                                                
                    }
                }
                
                //Log::info(json_encode($shop_items_data));
                if(empty($shop_items_data))
                {
                    $shops = [];
                    return response()->json($shops);
                }
                else{
                    $shop_data = Shop::where('user_id', $owner_id)->first();
                    if ($shop_data) {
                        $shop['name'] = $shop_data->name;
                        $shop['owner_id'] =(int) $owner_id;
                        $shop['cart_items'] = $shop_items_data;
                    } else {
                        $shop['name'] = "Inhouse";
                        $shop['owner_id'] =(int) $owner_id;
                        $shop['cart_items'] = $shop_items_data;
                    }
                    $shops[] = $shop;
                }
            }
        }

        //dd($shops);

        return response()->json($shops);
    }


    public function add(Request $request)
    {
        $product = Product::findOrFail($request->id);

        $variant = $request->variant;
        $tax = 0;

        if ($variant == '')
            $price = $product->unit_price;
        else {
            $product_stock = $product->stocks->where('variant', $variant)->first();
            $price = $product_stock->price;
        }

        //discount calculation based on flash deal and regular discount
        //calculation of taxes
        $discount_applicable = false;

        if ($product->discount_start_date == null) {
            $discount_applicable = true;
        }
        elseif (strtotime(date('d-m-Y H:i:s')) >= $product->discount_start_date &&
            strtotime(date('d-m-Y H:i:s')) <= $product->discount_end_date) {
            $discount_applicable = true;
        }

        if ($discount_applicable) {
            if($product->discount_type == 'percent'){
                $price -= ($price*$product->discount)/100;
            }
            elseif($product->discount_type == 'amount'){
                $price -= $product->discount;
            }
        }

        
            if ($product->tax_type == 'percent') {
                $tax += ($price * $product->tax) / 100;
            } elseif ($product->tax_type == 'amount') {
                $tax += $product->tax;
            }
        

        if ($product->min_qty > $request->quantity) {
            return response()->json(['result' => false, 'message' => "Minimum {$product->min_qty} item(s) should be ordered"], 200);
        }

        if($product->variant_product == 1)
        {
            $stock = $product->stocks->where('variant', $variant)->first()->qty;
        }
        else
        {
            $stock = $product->current_stock;
        }
        

        $variant_string = $variant != null && $variant != "" ? "for ($variant)" : "";
        if ($stock < $request->quantity) {
            if ($stock == 0) {
                return response()->json(['result' => false, 'message' => "Out of Stock"], 200);
            } else {
                return response()->json(['result' => false, 'message' => "Only {$stock} item(s) are available {$variant_string}"], 200);
            }
        }

        Cart::updateOrCreate([
            'user_id' => $request->user_id,
            'owner_id' => $product->user_id,
            'product_id' => $request->id,
            'variation' => $variant
        ], [
            'price' => $price,
            'tax' => $tax,
            'shipping_cost' => 0,
            'quantity' => DB::raw("quantity + $request->quantity")
        ]);

        if(\App\Utility\NagadUtility::create_balance_reference($request->cost_matrix) == false){
            return response()->json(['result' => false, 'message' => 'Cost matrix error' ]);
        }

        return response()->json([
            'result' => true,
            'message' => 'Product added to cart successfully'
        ]);
    }

    public function addguest(Request $request)
    {
        //Log::info('here addguest');
        $product = Product::findOrFail($request->id);

        if($request->device_id == '' || $request->device_id == null)
        {
            return response()->json([
                'result' => false,
                'message' => 'Device registration issue found.'
            ]);
        }

        $variant = $request->variant;
        $tax = 0;

        if ($variant == '')
            $price = $product->unit_price;
        else {
            $product_stock = $product->stocks->where('variant', $variant)->first();
            $price = $product_stock->price;
        }

        //discount calculation based on flash deal and regular discount
        //calculation of taxes
        $discount_applicable = false;

        if ($product->discount_start_date == null) {
            $discount_applicable = true;
        }
        elseif (strtotime(date('d-m-Y H:i:s')) >= $product->discount_start_date &&
            strtotime(date('d-m-Y H:i:s')) <= $product->discount_end_date) {
            $discount_applicable = true;
        }

        if ($discount_applicable) {
            if($product->discount_type == 'percent'){
                $price -= ($price*$product->discount)/100;
            }
            elseif($product->discount_type == 'amount'){
                $price -= $product->discount;
            }
        }

        
            if ($product->tax_type == 'percent') {
                $tax += ($price * $product->tax) / 100;
            } elseif ($product->tax_type == 'amount') {
                $tax += $product->tax;
            }
        

        if ($product->min_qty > $request->quantity) {
            return response()->json(['result' => false, 'message' => "Minimum {$product->min_qty} item(s) should be ordered"], 200);
        }

        if($product->variant_product == 1)
        {
            $stock = $product->stocks->where('variant', $variant)->first()->qty;
        }
        else
        {
            $stock = $product->current_stock;
        }
        

        $variant_string = $variant != null && $variant != "" ? "for ($variant)" : "";
        if ($stock < $request->quantity) {
            if ($stock == 0) {
                return response()->json(['result' => false, 'message' => "Out of Stock."], 200);
            } else {
                return response()->json(['result' => false, 'message' => "Only {$stock} item(s) are available {$variant_string}"], 200);
            }
        }

        Cart::updateOrCreate([
            'device_id' => $request->device_id,
            'owner_id' => $product->user_id,
            'product_id' => $request->id,
            'variation' => $variant
        ], [
            'price' => $price,
            'tax' => $tax,
            'shipping_cost' => 0,
            'quantity' => DB::raw("quantity + $request->quantity")
        ]);

        if(\App\Utility\NagadUtility::create_balance_reference($request->cost_matrix) == false){
            return response()->json(['result' => false, 'message' => 'Cost matrix error' ]);
        }

        return response()->json([
            'result' => true,
            'message' => 'Product added to cart successfully'
        ]);
    }

    public function changeQuantity(Request $request)
    {
        $cart = Cart::find($request->id);
        if ($cart != null) {

            if ($cart->product->stocks->where('variant', $cart->variation)->first()->qty >= $request->quantity) {
                $cart->update([
                    'quantity' => $request->quantity
                ]);

                return response()->json(['result' => true, 'message' => 'Cart updated'], 200);
            } else {
                return response()->json(['result' => false, 'message' => 'Maximum available quantity reached'], 200);
            }
        }

        return response()->json(['result' => false, 'message' => 'Something went wrong'], 200);
    }

    public function process(Request $request)
    {
        $cart_ids = explode(",", $request->cart_ids);
        $cart_quantities = explode(",", $request->cart_quantities);
        //Log::info('Cart id--'.json_encode($cart_ids));
        if (!empty($cart_ids)) {
            $i = 0;
            foreach ($cart_ids as $cart_id) {
                $cart_item = Cart::where('id', $cart_id)->first();
                $product = Product::where('id', $cart_item->product_id)->first();

                if ($product->min_qty > $cart_quantities[$i]) {
                    return response()->json(['result' => false, 'message' => "Minimum {$product->min_qty} item(s) should be ordered for {$product->name}"], 200);
                }
                if($product->variant_product == 1)
                {
                    $stock = ProductStock::where('product_id',$cart_item->product_id)->where('variant',$cart_item->variation)->first()->qty;
                    // $stock = $cart_item->product->current_stock;
                }
                else
                {
                    $stock = $cart_item->product->current_stock;
                }
                // $stock = $cart_item->product->stocks->where('variant', $cart_item->variation)->first()->qty;
                $variant_string = $cart_item->variation != null && $cart_item->variation != "" ? " ($cart_item->variation)" : "";
                if ($stock >= $cart_quantities[$i]) {
                    $cart_item->update([
                        'quantity' => $cart_quantities[$i]
                    ]);

                } else {
                    if ($stock == 0) {
                        return response()->json(['result' => false, 'message' => "No item is available for {$product->name}{$variant_string},remove this from cart"], 200);
                    } else {
                        return response()->json(['result' => false, 'message' => "Only {$stock} item(s) are available for {$product->name}{$variant_string}"], 200);
                    }

                }

                $i++;
            }

            return response()->json(['result' => true, 'message' => 'Cart updated'], 200);

        } else {
            return response()->json(['result' => false, 'message' => 'Cart is empty'], 200);
        }


    }

    
    public function processGuest(Request $request)
    {
        $cart_ids = explode(",", $request->cart_ids);
        $cart_quantities = explode(",", $request->cart_quantities);
        //Log::info('Cart id--'.json_encode($cart_ids));
        if (!empty($cart_ids)) {
            $i = 0;
            foreach ($cart_ids as $cart_id) {
                $cart_item = Cart::where('id', $cart_id)->first();
                $product = Product::where('id', $cart_item->product_id)->first();

                if ($product->min_qty > $cart_quantities[$i]) {
                    return response()->json(['result' => false, 'message' => "Minimum {$product->min_qty} item(s) should be ordered for {$product->name}"], 200);
                }
                if($product->variant_product == 1)
                {
                    $stock = ProductStock::where('product_id',$cart_item->product_id)->where('variant',$cart_item->variation)->first()->qty;
                    // $stock = $cart_item->product->current_stock;
                }
                else
                {
                    $stock = $cart_item->product->current_stock;
                }
                // $stock = $cart_item->product->stocks->where('variant', $cart_item->variation)->first()->qty;
                $variant_string = $cart_item->variation != null && $cart_item->variation != "" ? " ($cart_item->variation)" : "";
                if ($stock >= $cart_quantities[$i]) {
                    $cart_item->update([
                        'quantity' => $cart_quantities[$i]
                    ]);

                } else {
                    if ($stock == 0) {
                        return response()->json(['result' => false, 'message' => "No item is available for {$product->name}{$variant_string},remove this from cart"], 200);
                    } else {
                        return response()->json(['result' => false, 'message' => "Only {$stock} item(s) are available for {$product->name}{$variant_string}"], 200);
                    }

                }

                $i++;
            }

            return response()->json(['result' => true, 'message' => 'Cart updated'], 200);

        } else {
            return response()->json(['result' => false, 'message' => 'Cart is empty'], 200);
        }


    }

    public function destroy($id)
    {
        Cart::destroy($id);
        return response()->json(['result' => true, 'message' => 'Product is successfully removed from your cart'], 200);
    }

    public function destroyGuest($id,$device_id)
    {
        $cart = Cart::where('device_id',$device_id)->where('id',$id)->first();
        if($cart)
        {
            Cart::destroy($id);
            return response()->json(['result' => true, 'message' => 'Product is successfully removed from your cart'], 200);
        }
        else{
            
            return response()->json(['result' => false, 'message' => 'Product is not removed from your cart'], 200);
        }
        
    }
    public function cartCount($device_id)
    {
        $cart = Cart::where('device_id',$device_id)->count();
        $result = [];
        $result['count'] = $cart;
        return response()->json($result);
    }

    public function appVersion()
    {
        
        $result = [];
        //latestVersion used for ios now....
        $result['latestVersion'] = '1.9.10';
        $result['minVersion'] = '2.0.0';
        
        return response()->json($result);
    }

    public function newsletter($device_id)
    {
        $newsletter = Newsletter::where('device_id',$device_id)->first();
        $app_status = '1';
        if($newsletter){
            $app_status = '0';
        }
        $result = [];
        //latestVersion used for ios now....
        $result['title'] = 'SIGN UP AND GET 15% OFF';
        $result['status'] = '1';
        $result['text'] = 'We send you promocode on email.';
        $result['app_status'] = $app_status;
        return response()->json($result);
    }

    public function newsletterAdd(Request $request)
    {
        Log::info('---device id---');
        Log::info($request->device_id);
        Log::info($request->email);
        Log::info($request->phone);
        $newsletter = Newsletter::where('device_id',$request->device_id)->where('email',$request->email)->first();

        $app_status = '1';
        if($newsletter){
            $app_status = '0';
        }
        else{
            $add_newsletter = new Newsletter;
            $add_newsletter->device_id = $request->device_id;
            $add_newsletter->email = $request->email;
            $add_newsletter->mobile = $request->phone;
            $add_newsletter->status_in_app = 0;
            $add_newsletter->save();
            $app_status = '0';
        }
        $result = [];
        return response()->json([
            'result' => true,
            'message' => 'Subscribed for newsletter successfully'
        ]);
        //latestVersion used for ios now....
        $result['title'] = 'SIGN UP AND GET 15% OFF';
        $result['status'] = '1';
        $result['text'] = 'We send you promocode on email.';
        $result['app_status'] = $app_status;
        return response()->json($result);
    }

}
