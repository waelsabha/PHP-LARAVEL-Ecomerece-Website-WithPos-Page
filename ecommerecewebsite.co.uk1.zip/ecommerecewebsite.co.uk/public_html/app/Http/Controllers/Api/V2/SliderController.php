<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Resources\V2\SliderCollection;
use App\Http\Resources\V2\SliderCollectionTwo;
use App\Slider;

class SliderController extends Controller
{
    public function index()
    {
        $sliders = Slider::where('published',1)->where('show_in_app',1)->latest()->get(['photo']);
        if($sliders->isEmpty())
        {
            return [
                'success' => false,
                'status' => 204
            ];
        }
        return new SliderCollection(json_decode($sliders));
    }

    public function sliderstest()
    {
        $sliders = Slider::where('published',1)->where('show_in_app',1)->latest()->get(['photo']);
        if($sliders->isEmpty())
        {
            return [
                'success' => false,
                'status' => 204
            ];
        }
        return[
            'data'=>json_decode($sliders)
        ];
        return new SliderCollectionTwo(json_decode($sliders));
    }
}
