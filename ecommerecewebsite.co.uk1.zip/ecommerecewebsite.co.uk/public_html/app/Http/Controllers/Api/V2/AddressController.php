<?php

namespace App\Http\Controllers\Api\V2;

use App\City;
use App\Country;
use App\Http\Resources\V2\AddressCollection;
use App\Address;
use App\Http\Resources\V2\CitiesCollection;
use App\Http\Resources\V2\CountriesCollection;
use App\Http\Resources\V2\StatesCollection;
use App\ShippingCharge;
use Illuminate\Http\Request;
use App\Models\Cart;

use Illuminate\Support\Facades\Log;

class AddressController extends Controller
{
    public function addresses($id)
    {
        return new AddressCollection(Address::where('user_id', $id)->get());
    }

    public function addressesGuest($id)
    {
        // Log::info('addressesGuest------------');
        // Log::info($id);
        // Log::info(json_encode(Address::where('device_id', $id)->get()));
        return new AddressCollection(Address::where('device_id', $id)->get());
    }

    public function createShippingAddress(Request $request)
    {
        $shipping = ShippingCharge::where('sc_town',$request->city)->first();
        $address = new Address;
        $address->user_id = $request->user_id;
        $address->address = $request->address;
        $address->building_name = $request->building_name;
        $address->flat_no = $request->flat_no;
        $address->country = $request->country;
        $address->area = $request->city;
        // $address->postal_code = $request->postal_code;
        $address->phone = $request->phone;

        $address->emirate = $shipping->sc_emirate;        
        $address->shipping_charges_id = $shipping->sc_id;
        
  
        $address->save();


        return response()->json([
            'result' => true,
            'message' => 'Shipping information has been added successfully'
        ]);
    }
   
    public function createShippingAddressGuest(Request $request)
    {
        $shipping = ShippingCharge::where('sc_town',$request->city)->first();
        $address = new Address;
        $address->device_id = $request->device_id;
        $address->email = $request->email;
        $address->address = $request->address;
        $address->building_name = $request->building_name;
        $address->landmark = $request->landmark;
        $address->flat_no = $request->flat_no;
        $address->country = $request->country;
        $address->area = $request->city;
        // $address->postal_code = $request->postal_code;
        $address->phone = $request->phone;

        $address->emirate = $shipping->sc_emirate;
       
        
        $address->shipping_charges_id = $shipping->sc_id;
        
        
        $address->save();


        return response()->json([
            'result' => true,
            'message' => 'Shipping information has been added successfully'
        ]);
    }

    public function updateShippingAddress(Request $request)
    {
        $address = Address::find($request->id);
        $address->address = $request->address;
        $address->country = $request->country;
        $address->city = $request->city;
        $address->postal_code = $request->postal_code;
        $address->phone = $request->phone;
        $address->save();

        return response()->json([
            'result' => true,
            'message' => 'Shipping information has been updated successfully'
        ]);
    }


    public function deleteShippingAddress($id)
    {
        $address = Address::find($id);
        $address->delete();
        return response()->json([
            'result' => true,
            'message' => 'Shipping information has been deleted'
        ]);
    }

    public function makeShippingAddressDefault(Request $request)
    {
        Address::where('user_id', $request->user_id)->update(['set_default' => 0]); //make all user addressed non default first

        $address = Address::find($request->id);
        $address->set_default = 1;
        $address->save();
        return response()->json([
            'result' => true,
            'message' => 'Default shipping information has been updated'
        ]);
    }

    public function updateAddressInCart(Request $request)
    {
        try {
            Cart::where('user_id', $request->user_id)->update(['address_id' => $request->address_id]);

        } catch (\Exception $e) {
            return response()->json([
                'result' => false,
                'message' => 'Could not save the address'
            ]);
        }
        return response()->json([
            'result' => true,
            'message' => 'Address is saved'
        ]);


    }

    public function updateAddressInCartGuest(Request $request)
    {
        // Log::info("updateAddressInCartGuest");
        // Log::info($request->address_id);
        // Log::info($request->device_id);
        try {
            Cart::where('device_id', $request->device_id)->update(['address_id' => $request->address_id]);

        } catch (\Exception $e) {
            return response()->json([
                'result' => false,
                'message' => 'Could not save the address'
            ]);
        }
        return response()->json([
            'result' => true,
            'message' => 'Address is saved'
        ]);


    }

    public function getCities($state)
    {

        $shipping_charges_db = ShippingCharge::where('sc_emirate',$state)->where('sc_sts',1)->where('sc_color','!=','red')->get();
            
        $emirates = $shipping_charges_db->unique('sc_emirate');
        
        $areas = $shipping_charges_db->unique('sc_town');
        $areas_collection = collect();
        foreach($areas as $area)
        {
            if(rtrim($area->sc_town) == $area->sc_town) 
            {
                if(!empty($area->sc_town))
                {
                    $arr = array();
                    
                    $areas_collection->push($arr);
                }
                
            }

        }

        return new CitiesCollection(ShippingCharge::where('sc_emirate',$state)->where('sc_sts',1)->where('sc_color','!=','red')->get());
    }

    public function getStates($country)
    {
        // Log::info('----'.$country);
        $country = Country::where('name',$country)->first();
        $shipping_charges_db = ShippingCharge::where('sc_country',$country->id)->where('sc_sts',1)->where('sc_color','!=','red')->get();
            
        $emirates = $shipping_charges_db->unique('sc_emirate');
        
        $areas = $shipping_charges_db->unique('sc_town');
        $emirates_collection = collect();
        foreach($emirates as $emirate)
        {
            if(rtrim($emirate->sc_emirate) == $emirate->sc_emirate) 
            {
                if(!empty($emirate->sc_emirate))
                {
                    $arr = array();
                    $arr = ["sc_emirate" =>$emirate->sc_emirate ];
                    $emirates_collection->push($arr);
                }
                
            }

        }
        // dd($emirates_collection);
        return new StatesCollection($emirates_collection);
    }

    

    public function getCountries()
    {
        return new CountriesCollection(Country::where('status', 1)->get());
    }
}
