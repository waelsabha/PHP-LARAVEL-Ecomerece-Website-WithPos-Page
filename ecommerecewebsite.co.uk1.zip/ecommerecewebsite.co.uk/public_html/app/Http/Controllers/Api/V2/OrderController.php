<?php

namespace App\Http\Controllers\Api\V2;

use App\Address;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Cart;
use App\Models\Product;
use App\ProductStock;
use App\Models\OrderDetail;
use App\Models\Coupon;
use App\Models\CouponUsage;
use App\Models\BusinessSetting;
use App\ShippingCharge;
use App\User;
use DB;
use Illuminate\Support\Facades\Log;

class OrderController extends Controller
{
    public function store(Request $request, $set_paid = false)
    {
        if(isset($request->owner_id))
        {
            $owner_id = $request->owner_id;
        }
        else
        {
            $owner_id = 9;
        }
        if($request->user_id == '' || $request->user_id == null)
        {
            $cartItems = Cart::where('device_id', $request->device_id)->where('owner_id', $owner_id)->get();
        }
        else{
            $cartItems = Cart::where('user_id', $request->user_id)->where('owner_id', $owner_id)->get();
        }
        
        
        if ($cartItems->isEmpty()) {
            return response()->json([
                'order_id' => 0,
                'result' => false,
                'message' => 'Cart is Empty'
            ]);
        }

        $user = User::find($request->user_id);
        $country_id = null;

        $address = Address::where('id', $cartItems->first()->address_id)->first();
        $shippingAddress = [];
        if ($address != null) {
            $shippingAddress['name'] = $user->name;
            $shippingAddress['email'] = $user->email;
            $shippingAddress['address'] = $address->address;
            $shippingAddress['country'] = $address->country;
            $shippingAddress['area'] = $address->area;
            $shippingAddress['emirate'] = $address->emirate;
            $shippingAddress['postal_code'] = $address->postal_code;
            $shippingAddress['building_name'] = $address->building_name;
            $shippingAddress['flat_no'] = $address->flat_no;
            $shippingAddress['landmark'] = $address->landmark;
            $shippingAddress['phone'] = $address->phone;

            $shipping_charges = ShippingCharge::where('sc_id',$address->shipping_charges_id)->first();
            if($shipping_charges)
            {
                $country_id = $shipping_charges->sc_country;
            }
        }

        $sum = 0.00;
        $shipping_co = 0.00;
        $sum_before_discount = 0.00;
        foreach ($cartItems as $cartItem) {
            $item_sum = 0;
            $item_sum += ($cartItem->price + $cartItem->tax) * $cartItem->quantity;
            $sum_before_discount += ($cartItem->price + $cartItem->tax) * $cartItem->quantity;
            $item_sum -=  $cartItem->discount;
            $sum += $item_sum;   //// 'grand_total' => $request->g
            if($cartItem->shipping_cost > 0)
            {
                if($shipping_co == 0.00)
                {
                    $shipping_co = $cartItem->shipping_cost;
                }
                
            }
            
        }

        if($sum_before_discount >= 100)
        {
            $shipping_co = 0.00;
        }
        $sum += $shipping_co;
        // create an order
        $order = Order::create([
            'user_id' => $request->user_id,
            // 'seller_id' =>$request->owner_id,
            'shipping_address' => json_encode($shippingAddress),
            'payment_type' => $request->payment_type,
            'payment_status' => $set_paid ? 'paid' : 'unpaid',
            'grand_total' => $sum,
            'coupon_discount' => $cartItems->sum('discount'),
            'shipping_cost' => $shipping_co,
            'code' => date('Ymd-his'),
            'date' => strtotime('now'),
            'order_device_app' => 2,
            'country_id' => $country_id 

        ]);

        foreach ($cartItems as $cartItem) {
            $product = Product::find($cartItem->product_id);
            if($product->variant_product == '1')
            {
                $products_stocks = ProductStock::where('variant', $cartItem->variation)->first();
                $products_stocks->qty -= $cartItem->quantity;
                $products_stocks->save();
            }
            else
            {
                $product->current_stock -=$cartItem->quantity;
                $product->save();
            }
            // $product_stocks = $product->stocks->where('variant', $cartItem->variation)->first();
            // $product_stocks->qty -= $cartItem->quantity;
            // $product_stocks->save();

            /*if ($cartItem->variation) {
                $product_stocks = $product->stocks->where('variant', $cartItem->variation)->first();
                $product_stocks->qty -= $cartItem->quantity;
                $product_stocks->save();
            } else {
                $product->update([
                    'current_stock' => DB::raw('current_stock - ' . $cartItem->quantity)
                ]);
            }*/

            // save order details
            OrderDetail::create([
                'order_id' => $order->id,
                'seller_id' => $product->user_id,
                'product_id' => $product->id,
                'variation' => $cartItem->variation,
                'price' => $cartItem->price * $cartItem->quantity,
                'tax' => $cartItem->tax * $cartItem->quantity,
                'shipping_cost' => $shipping_co,
                'shipping_type' => 'home_delivery',
                'quantity' => $cartItem->quantity,
                'payment_status' => $set_paid ? 'paid' : 'unpaid',
                'mobile_app_cart_id' => $cartItem->id
            ]);
            $product->update([
                'num_of_sale' => DB::raw('num_of_sale + ' . $cartItem->quantity)
            ]);
        }
        // apply coupon usage

        if ($cartItems->first()->coupon_code != '') {
            CouponUsage::create([
                'user_id' => $request->user_id,
                'coupon_id' => Coupon::where('code', $cartItems->first()->coupon_code)->first()->id
            ]);
        }
        if($request->payment_type == 'ngenius')
        {
            if($order->payment_status == 'paid'){
                Cart::where('device_id', $request->device_id)->where('owner_id', $owner_id)->delete();
            }
        }
        else{
            Cart::where('device_id', $request->device_id)->where('owner_id', $owner_id)->delete();
        }
        //Cart::where('user_id', $request->user_id)->where('owner_id', $owner_id)->delete();
        
        // if(isset($owner_id))
        // {
        //     return response()->json([
        //         'order_id' => $order->id,
        //         'result' => true,
        //         'message' => translate('Your order has been placed successfully')
        //     ]);
            
        // }
        // else
        // {
            return $order->id;
        // }
        
    }

    public function storeGuest(Request $request, $set_paid = false)
    {
        if(isset($request->owner_id))
        {
            $owner_id = $request->owner_id;
        }
        else
        {
            $owner_id = 9;
        }
        
        $cartItems = Cart::where('device_id', $request->device_id)->where('owner_id', $owner_id)->get();
        
        // Log::info("store Guest");
        // Log::info("device id---".$request->device_id);

        if ($cartItems->isEmpty()) {
            return response()->json([
                'order_id' => 0,
                'result' => false,
                'message' => 'Cart is Empty'
            ]);
        }

        // $user = User::find($request->user_id);
        $country_id = null;
        // Log::info(json_encode($cartItems));
        // Log::info("device id---".$cartItems->first()->address_id);
        $address = Address::where('id', $cartItems->first()->address_id)->first();
        $shippingAddress = [];
        if ($address != null) {
            $shippingAddress['name'] = $address->name;
            $shippingAddress['email'] = $address->email;
            $shippingAddress['address'] = $address->address;
            $shippingAddress['country'] = $address->country;
            $shippingAddress['area'] = $address->area;
            $shippingAddress['emirate'] = $address->emirate;
            $shippingAddress['postal_code'] = $address->postal_code;
            $shippingAddress['building_name'] = $address->building_name;
            $shippingAddress['flat_no'] = $address->flat_no;
            $shippingAddress['landmark'] = $address->landmark;
            $shippingAddress['phone'] = $address->phone;

            $shipping_charges = ShippingCharge::where('sc_id',$address->shipping_charges_id)->first();
            if($shipping_charges)
            {
                $country_id = $shipping_charges->sc_country;
            }
        }

        $sum = 0.00;
        $shipping_co = 0.00;
        $sum_before_discount = 0.00;
        foreach ($cartItems as $cartItem) {
            $item_sum = 0;
            $item_sum += ($cartItem->price + $cartItem->tax) * $cartItem->quantity;
            $sum_before_discount += ($cartItem->price + $cartItem->tax) * $cartItem->quantity;
            $item_sum -=  $cartItem->discount;
            $sum += $item_sum;   //// 'grand_total' => $request->g
            if($cartItem->shipping_cost > 0)
            {
                if($shipping_co == 0.00)
                {
                    $shipping_co = $cartItem->shipping_cost;
                }
                
            }
            
        }

        if($sum_before_discount >= 100)
        {
            $shipping_co = 0.00;
        }
        $sum += $shipping_co;

        // create an order
        $order = Order::create([
            'device_id' => $request->device_id,
            // 'seller_id' =>$request->owner_id,
            'shipping_address' => json_encode($shippingAddress),
            'payment_type' => $request->payment_type,
            'payment_status' => $set_paid ? 'paid' : 'unpaid',
            'grand_total' => $sum,
            'coupon_discount' => $cartItems->sum('discount'),
            'shipping_cost' => $shipping_co,
            'code' => date('Ymd-his'),
            'date' => strtotime('now'),
            'order_device_app' => 2,
            'country_id' => $country_id 

        ]);

        foreach ($cartItems as $cartItem) {
            $product = Product::find($cartItem->product_id);
            if($product->variant_product == '1')
            {
                $products_stocks = ProductStock::where('variant', $cartItem->variation)->first();
                $products_stocks->qty -= $cartItem->quantity;
                $products_stocks->save();
            }
            else
            {
                $product->current_stock -=$cartItem->quantity;
                $product->save();
            }
            // $product_stocks = $product->stocks->where('variant', $cartItem->variation)->first();
            // $product_stocks->qty -= $cartItem->quantity;
            // $product_stocks->save();

            /*if ($cartItem->variation) {
                $product_stocks = $product->stocks->where('variant', $cartItem->variation)->first();
                $product_stocks->qty -= $cartItem->quantity;
                $product_stocks->save();
            } else {
                $product->update([
                    'current_stock' => DB::raw('current_stock - ' . $cartItem->quantity)
                ]);
            }*/

            // save order details
            OrderDetail::create([
                'order_id' => $order->id,
                'seller_id' => $product->user_id,
                'product_id' => $product->id,
                'variation' => $cartItem->variation,
                'price' => $cartItem->price * $cartItem->quantity,
                'tax' => $cartItem->tax * $cartItem->quantity,
                'shipping_cost' => $cartItem->shipping_cost,
                'shipping_type' => 'home_delivery',
                'quantity' => $cartItem->quantity,
                'payment_status' => $set_paid ? 'paid' : 'unpaid',
                'mobile_app_cart_id' => $cartItem->id
            ]);
            $product->update([
                'num_of_sale' => DB::raw('num_of_sale + ' . $cartItem->quantity)
            ]);
        }
        // apply coupon usage

        if ($cartItems->first()->coupon_code != '') {
            CouponUsage::create([
                'device_id' => $request->device_id,
                'coupon_id' => Coupon::where('code', $cartItems->first()->coupon_code)->first()->id
            ]);
        }
        if($request->payment_type == 'ngenius')
        {
            if($order->payment_status == 'paid'){
                Cart::where('device_id', $request->device_id)->where('owner_id', $owner_id)->delete();
            }
        }
        else{
            Cart::where('device_id', $request->device_id)->where('owner_id', $owner_id)->delete();
        }

        //Cart::where('device_id', $request->device_id)->where('owner_id', $owner_id)->delete();
        // if(isset($owner_id))
        // {
        //     return response()->json([
        //         'order_id' => $order->id,
        //         'result' => true,
        //         'message' => translate('Your order has been placed successfully')
        //     ]);
            
        // }
        // else
        // {
            return $order->id;
        // }
        
    }
}
