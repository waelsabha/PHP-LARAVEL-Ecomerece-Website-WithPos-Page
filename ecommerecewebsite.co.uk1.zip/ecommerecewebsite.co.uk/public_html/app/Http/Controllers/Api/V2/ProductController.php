<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Resources\V2\ProductCollection;
use App\Http\Resources\V2\ProductMiniCollection;
use App\Http\Resources\V2\ProductDetailCollection;
use App\Http\Resources\V2\SearchProductCollection;
use App\Http\Resources\V2\FlashDealCollection;
use App\Http\Resources\V2\ProductSimilarCollection;
use App\Http\Resources\V2\ProductExtraCollection;
use App\Models\Brand;
use App\Models\Category;
use App\Models\FlashDeal;
use App\Models\FlashDealProduct;
use App\Models\Product;
use App\Models\Shop;
use App\Models\Color;
use App\ProductExtra;
use App\SubCategory;
use App\SubSubCategory;
use Illuminate\Http\Request;
use App\Utility\CategoryUtility;

use Illuminate\Support\Facades\Log;

class ProductController extends Controller
{
    public function index()
    {
        return new ProductMiniCollection(Product::latest()->paginate(10));
    }

    public function show($id)
    {
        //Log::info('id---'.$id);
        return new ProductDetailCollection(Product::where('id', $id)->get());
    }

    public function admin()
    {
        return new ProductCollection(Product::where('added_by', 'admin')->latest()->paginate(10));
    }

    public function seller($id, Request $request)
    {
        $shop = Shop::findOrFail($id);
        $products = Product::where('added_by', 'seller')->where('user_id', $shop->user_id);
        if ($request->name != "" || $request->name != null) {
            $products = $products->where('name', 'like', '%' . $request->name . '%');
        }
        return new ProductMiniCollection($products->latest()->paginate(10));
    }

    public function category($id, Request $request)
    {
        
        $category_ids = CategoryUtility::children_ids($id);
        $category_ids[] = $id;
        
        $cat = Category::where('id',$id)->first();
        if(isset($request->cat_name))
        {
            
            if($request->cat_name == 'Toys below 20' )
            {
                
                $products = Product::where('published', 1)->where('category_id','4')->where('unit_price', '<=', '20');
                return new ProductMiniCollection(filter_products($products)->latest()->paginate(10));
            }
            if($request->cat_name == 'Toys below 40' )
            {
                
                $products = Product::where('published', 1)->where('category_id','4')->where('unit_price', '>', '20')->where('unit_price', '<=', '20');
                return new ProductMiniCollection(filter_products($products)->latest()->paginate(10));
            }
            
            if($request->cat_name != "" || $request->cat_name != null)
            {
                $cat = Category::where('slug',$request->cat_name)->first(); 
            }
        }
        
        $first_half_add = '';
        
        if($cat->parent_id != 0)
        {
            $sub_cat = SubCategory::where('slug',$cat->slug)->first();
            $conditions = ['published' => 1];
            if($sub_cat)
            {
                $conditions = array_merge($conditions, ['subcategory_id' => $sub_cat->id]);
                $products = Product::where('published', 1)->where('subcategory_id', 'like', '%"' . $sub_cat->id . '"%');
            }
            else 
            {
                $sub_sub_cat = SubSubCategory::where('slug',$cat->slug)->first();
                if($sub_sub_cat)
                {
                    $conditions = array_merge($conditions, ['subcategory_id' => $sub_sub_cat->id]);
                    $products = Product::where('published', 1)->where('subsubcategory_id', 'like', '%"' . $sub_sub_cat->id . '"%');
                }
                
            }
        }
        else
        {
            $products = Product::whereIn('category_id', $category_ids);
        }
        

        
        if ($request->name != "" || $request->name != null) {
            $products = $products->where('name', 'like', '%' . $request->name . '%');
        }
        return new ProductMiniCollection(filter_products($products)->latest()->paginate(10));
    }

    public function subCategory($id)
    {
        $category_ids = CategoryUtility::children_ids($id);
        $category_ids[] = $id;

        return new ProductMiniCollection(Product::whereIn('category_id', $category_ids)->latest()->paginate(10));
    }

    public function subSubCategory($id)
    {
        $category_ids = CategoryUtility::children_ids($id);
        $category_ids[] = $id;

        return new ProductMiniCollection(Product::whereIn('category_id', $category_ids)->latest()->paginate(10));
    }

    public function brand($id, Request $request)
    {
        $products = Product::where('brand_id', $id);
        if ($request->name != "" || $request->name != null) {
            $products = $products->where('name', 'like', '%' . $request->name . '%');
        }
        return new ProductMiniCollection($products->latest()->paginate(10));
    }

    public function todaysDeal()
    {
        return new ProductMiniCollection(Product::where('todays_deal', 1)->limit(20)->latest()->get());
    }

    public function flashDeal()
    {
        $flash_deals = FlashDeal::where('status', 1)->where('featured', 1)->where('start_date', '<=', strtotime(date('d-m-Y')))->where('end_date', '>=', strtotime(date('d-m-Y')))->get();
        return new FlashDealCollection($flash_deals);
    }

    public function featured()
    {
        return new ProductMiniCollection(Product::where('featured', 1)->limit(20)->latest()->get());
    }

    public function bestSeller()
    {
        return new ProductMiniCollection(Product::orderBy('num_of_sale', 'desc')->limit(20)->get());
    }

    // public function related($id)
    // {
    //     $product = Product::find($id);
    //     return new ProductMiniCollection(Product::where('category_id', $product->category_id)->where('id', '!=', $id)->limit(10)->get());
    // }

    public function related($id)
    {
        $product = Product::find($id);

        $code = ($product->subsubcategory_id);
                        
                            if($code != null && $code != '[]')
                            {
                                
                                $code = json_decode($product->subsubcategory_id);
                                if(is_array($code))
                                {
                                    if(count($code) > 0)
                                    {
                                        $result = filter_products(\App\Product::where(function ($q) use ($code) 
                                        {
                                            foreach($code as $cod)
                                            {
                                                $q->orWhere('subsubcategory_id','like', '%'.$cod.'%');
                                            }
                                        })->where('id', '!=', $product->id))->limit(10)->get();
                                    }
                                }
                                else
                                {
                                    $result = filter_products(\App\Product::Where('subsubcategory_id','like', '%'.$code.'%')->where('id', '!=', $product->id))->limit(10)->get(); 
                                }
                            }
                            
                            else
                            {
                                $code = ($product->subcategory_id);
                                if($code != null && $code != '[]')
                                {
                                    $code = json_decode($product->subcategory_id);
                                    
                                    if(is_array($code))
                                    {
                                        if(count($code) > 0)
                                        {
                                            $result = filter_products(\App\Product::where(function ($q) use ($code) 
                                            {
                                                foreach($code as $cod)
                                                {
                                                    $q->orWhere('subcategory_id','like', '%'.$cod.'%');
                                                }
                                            })->where('id', '!=', $product->id))->limit(10)->get();
                                        }
                                    }
                                    else
                                    {
                                        $result = filter_products(\App\Product::where('subcategory_id','like', '%'.$code.'%')->where('id', '!=', $product->id))->limit(10)->get();
                                    }
                                   
                                }
                                else
                                {
                                    $result = filter_products(\App\Product::where('subcategory_id', $product->subcategory_id)->where('id', '!=', $product->id))->limit(10)->get();
                                }
                               
                            }


        return new ProductMiniCollection($result);
    }

    public function similar($id)
    {
        $detailedProduct = Product::where('id',$id)->first();
        $arr = array();
        if($detailedProduct->similar_products_id != null && $detailedProduct->similar_products_id != 'null')
        {
            if(!empty(json_decode($detailedProduct->similar_products_id)))
            {
               return new ProductSimilarCollection(Product::whereIn('id',json_decode($detailedProduct->similar_products_id))->where('published',1)->limit(10)->get());
            }
            
            return new ProductSimilarCollection(Product::whereIn('id',$arr)->limit(10)->get());
        }
        return new ProductSimilarCollection(Product::whereIn('id',$arr)->limit(10)->get());
    }

    public function topFromSeller($id)
    {
        $product = Product::find($id);
        return new ProductMiniCollection(Product::where('user_id', $product->user_id)->orderBy('num_of_sale', 'desc')->limit(10)->get());
    }


    public function search(Request $request)
    {
        $category_ids = [];
        $brand_ids = [];

        if ($request->categories != null && $request->categories != "") {
            $category_ids = explode(',', $request->categories);
        }

        if ($request->brands != null && $request->brands != "") {
            $brand_ids = explode(',', $request->brands);
        }

        $sort_by = $request->sort_key;
        $name = $request->name;
        $min = $request->min;
        $max = $request->max;


        $products = Product::query();

        if (!empty($brand_ids)) {
            $products = $products->whereIn('brand_id', $brand_ids);
        }

        if (!empty($category_ids)) {
            $n_cid = [];
            foreach ($category_ids as $cid) {
                $n_cid = array_merge($n_cid, CategoryUtility::children_ids($cid));
            }

            if (!empty($n_cid)) {
                $category_ids = array_merge($category_ids, $n_cid);
            }

            $products = $products->whereIn('category_id', $category_ids);
        }

        if ($name != null && $name != "") {
            $products = $products->where('name', 'like', "%{$name}%");
        }

        if ($min != null && $min != "" && is_numeric($min)) {
            $products = $products->where('unit_price', '>=', $min);
        }

        if ($max != null && $max != "" && is_numeric($max)) {
            $products = $products->where('unit_price', '<=', $max);
        }

        switch ($sort_by) {
            case 'price_low_to_high':
                $products = $products->orderBy('unit_price', 'asc');
                break;

            case 'price_high_to_low':
                $products = $products->orderBy('unit_price', 'desc');
                break;

            case 'new_arrival':
                $products = $products->orderBy('created_at', 'desc');
                break;

            case 'popularity':
                $products = $products->orderBy('num_of_sale', 'desc');
                break;

            case 'top_rated':
                $products = $products->orderBy('rating', 'desc');
                break;

            default:
                $products = $products->orderBy('created_at', 'desc');
                break;
        }

        return new ProductMiniCollection($products->paginate(16));
    }

    public function searchfilter(Request $request)
    {

        Log::info('id --'.$request->id);
        Log::info('cat_name --'.$request->cat_name);
        Log::info('name --'.$request->name);
        Log::info('sort_key --'.$request->sort_key);
        Log::info('page --'.$request->page);
        Log::info('brands --'.$request->brands);
        Log::info('categories --'.$request->categories);
        Log::info('min --'.$request->min);
        Log::info('max --'.$request->max);
        Log::info('main_category --'.$request->main_category);
        
        $category_ids = [];
        $brand_ids = [];

        if ($request->categories != null && $request->categories != "") {
            $category_ids = explode(',', $request->categories);
        }

        if ($request->brands != null && $request->brands != "") {
            $brand_ids = explode(',', $request->brands);
        }

        $sort_by = $request->sort_key;
        $name = $request->name;
        $min = $request->min;
        $max = $request->max;
        $main_category = null;
        if ($request->main_category != null && $request->main_category != "") {
            $main_category_arr = explode(',', $request->main_category);
            $main_category = end($main_category_arr);
            if (!empty($category_ids)) {
                $check_cat = Category::where('id',$category_ids[0])->first();
                if($check_cat->parent_id == $main_category)
                {
                    
                    $main_category = null;
                }
            }
        }

        $products = Product::query();

        if (!empty($brand_ids)) {
            $products = $products->whereIn('brand_id', $brand_ids);
        }
        //dd($main_category);
        if(($request->main_category == '' || $request->main_category == null) && ($request->categories == '' || $request->categories == null))
        {
            $check_cat = $this->checkCategory($request->id);
                if($check_cat == 'main')
                {
                    $products = $products->where('category_id', $request->id);
                }
                else if($check_cat == 'subcat')
                {
                    $cat = Category::where('id',$request->id)->first();
                    $sub_cat = SubCategory::where('slug',$cat->slug)->first();
                    if($sub_cat)
                    {
                        $products = $products->where('subcategory_id', 'like', '%"' . $sub_cat->id . '"%');
                    }
                    
                }
                else if($check_cat == 'subsubcat'){
                    $cat = Category::where('id',$request->id)->first();
                    $sub_sub_cat = SubSubCategory::where('slug',$cat->slug)->first();
                    if($sub_sub_cat)
                    {
                        $products = $products->where('subsubcategory_id', 'like', '%"' . $sub_sub_cat->id . '"%');
                    }
                    
                }
                else{
                    
                }
        }
        
        if (!empty($category_ids)) {
            $n_cid = [];
            foreach ($category_ids as $cid) {
                $n_cid = array_merge($n_cid, CategoryUtility::children_ids($cid));
            }
            
            if (!empty($n_cid)) {
                $category_ids = array_merge($category_ids, $n_cid);
            }
            

            if($category_ids[0])
            {
                
                $check_cat = $this->checkCategory($category_ids[0]);
                
                if($check_cat == 'main')
                {
                    $products = $products->where('category_id', $category_ids);
                }
                else if($check_cat == 'subcat')
                {
                    $cat = Category::where('id',$category_ids[0])->first();
                    $sub_cat = SubCategory::where('slug',$cat->slug)->first();
                    if($sub_cat)
                    {
                        $products = $products->where('subcategory_id', 'like', '%"' . $sub_cat->id . '"%');
                    }
                    
                }
                else if($check_cat == 'subsubcat'){
                    $cat = Category::where('id',$category_ids[0])->first();
                    $sub_sub_cat = SubSubCategory::where('slug',$cat->slug)->first();
                   
                    if($sub_sub_cat)
                    {
                        $products = $products->where('subsubcategory_id', 'like', '%"' . $sub_sub_cat->id . '"%');
                    }
                    
                }
                else{

                }
                
            }
            
           
            if($main_category != null && $main_category != '')
            {
                
                $check_cat = $this->checkCategory($main_category);
                
                if($check_cat == 'main')
                {
                    $products = Product::where('category_id', $main_category);
                }
                else if($check_cat == 'subcat')
                {
                    $cat = Category::where('id',$main_category)->first();
                    $sub_cat = SubCategory::where('slug',$cat->slug)->first();
                    if($sub_cat)
                    {
                        $products = Product::where('subcategory_id', 'like', '%"' . $sub_cat->id . '"%');
                    }
                    
                    
                }
                else if($check_cat == 'subsubcat'){
                    $cat = Category::where('id',$main_category)->first();
                    $sub_sub_cat = SubSubCategory::where('slug',$cat->slug)->first();
                    
                    if($sub_sub_cat)
                    {
                        $products = Product::where('subsubcategory_id', 'like', '%"' . $sub_sub_cat->id . '"%');
                    }
                    
                }
                else{

                }

            }
                 
        }
        

        // category products start from here
        if($request->cat_name != 'Toys below 20' && $request->cat_name != 'Toys below 40' )
        {
            if(isset($request->id))
            {
                $id = $request->id;
                $category_ids_new = CategoryUtility::children_ids($id);
                $category_ids_new[] = $id;
                
                $cat = Category::where('id',$id)->first();
                if(isset($request->cat_name))
                {
                    
                    if($request->cat_name != "" || $request->cat_name != null)
                    {
                        $cat = Category::where('slug',$request->cat_name)->first(); 
                    }
                }
                
                $first_half_add = '';
                if (empty($category_ids)) {
                    if($main_category != null && $main_category != '')
                    {
                        if($main_category != null && $main_category != '')
                        {
                            $check_cat = $this->checkCategory($main_category);
                
                            if($check_cat == 'main')
                            {
                                $products = $products->where('category_id', $main_category);
                            }
                            else if($check_cat == 'subcat')
                            {
                                $cat_check_here = Category::where('id',$main_category)->first();
                                $sub_cat = SubCategory::where('slug',$cat_check_here->slug)->first();
                                if($sub_cat)
                                {
                                    $products = $products->where('subcategory_id', 'like', '%"' . $sub_cat->id . '"%');
                                }
                                
                                
                            }
                            else if($check_cat == 'subsubcat'){
                                $cat_check_here = Category::where('id',$main_category)->first();
                                $sub_sub_cat = SubSubCategory::where('slug',$cat_check_here->slug)->first();
                                if($sub_sub_cat)
                                {
                                    $products = $products->where('subsubcategory_id', 'like', '%"' . $sub_sub_cat->id . '"%');
                                }
                                
                            }
                            else{

                            }
                        }
                        else{
                            if($cat->parent_id != 0)
                            {
                                
                                Log::info('indside if cat parent');
                                Log::info($cat->id);
                                $sub_cat = SubCategory::where('slug',$cat->slug)->first();
                                $conditions = ['published' => 1];
                                if($sub_cat)
                                {
                                    
                                    $conditions = array_merge($conditions, ['subcategory_id' => $sub_cat->id]);
                                    $products = Product::where('published', 1)->where('subcategory_id', 'like', '%"' . $sub_cat->id . '"%');
                                }
                                else 
                                {
                                    $sub_sub_cat = SubSubCategory::where('slug',$cat->slug)->first();
                                    if($sub_sub_cat)
                                    {
                                        $conditions = array_merge($conditions, ['subcategory_id' => $sub_sub_cat->id]);
                                        $products = Product::where('published', 1)->where('subsubcategory_id', 'like', '%"' . $sub_sub_cat->id . '"%');
                                    }
                                    
                                }
                            }
                            else
                            {
                                $products = Product::whereIn('category_id', $category_ids_new);
                            }
                        }
                    }
                }
               
            }
        }
        else{
            if($request->cat_name == 'Toys below 20' )
            {
                $products = $products->where('published', 1)->where('category_id',4)->where('unit_price', '<=', '20');
                // return new ProductMiniCollection(filter_products($products)->latest()->paginate(10));
            }
            if($request->cat_name == 'Toys below 40' )
            {
                $products = $products->where('published', 1)->where('category_id',4)->where('unit_price', '<=', '40');
                // return new ProductMiniCollection(filter_products($products)->latest()->paginate(10));
            }
        }
        
        
        // end category products

        if ($name != null && $name != "") {
            $products = $products->where('name', 'like', "%{$name}%");
        }

        if ($min != null && $min != "" && is_numeric($min)) {
            $products = $products->where('unit_price', '>=', $min);
        }

        if ($max != null && $max != "" && is_numeric($max)) {
            $products = $products->where('unit_price', '<=', $max);
        }

        switch ($sort_by) {
            case 'price_low_to_high':
                $products = $products->orderBy('unit_price', 'asc');
                break;

            case 'price_high_to_low':
                $products = $products->orderBy('unit_price', 'desc');
                break;

            case 'new_arrival':
                $products = $products->orderBy('created_at', 'desc');
                break;

            case 'popularity':
                $products = $products->orderBy('num_of_sale', 'desc');
                break;

            case 'top_rated':
                $products = $products->orderBy('rating', 'desc');
                break;

            default:
                $products = $products->orderBy('created_at', 'desc');
                break;
        }

        if($request->id == '16' && $request->cat_name == null)
        {
            Log::info('inside here ----');
            $products = Product::where('published', 1)->where('category_id',4)->where('home_page_show', 'like', '%16%');
            //$products = $products->where('published', 1)->where('home_page_show', 'like', '%"' . $request->id . '"%');
        }

        return new ProductMiniCollection($products->paginate(16));
    }

    public function checkCategory($id)
    {
        $main_cat = Category::where('id',$id)->first();
        if($main_cat)
        {
            if($main_cat->parent_id == '0')
            {
                return 'main';
            }
            
            $sub_cat = Category::where('id',$main_cat->parent_id)->first();
            if($sub_cat->parent_id == '0')
            {
                return 'subcat';
            }

            $sub_sub_cat = Category::where('id',$sub_cat->parent_id)->first();
            if($sub_sub_cat->parent_id == '0')
            {
                return 'subsubcat';
            }
        }
        else{
            return 'nothing';
        }
        

    }

    public function variantPrice(Request $request)
    {
        $product = Product::findOrFail($request->id);
        $str = '';
        $tax = 0;

        if ($request->has('color') && $request->color != "") {
            $str = Color::where('code', '#' . $request->color)->first()->name;
        }

        // $var_str = str_replace(',', '-', $request->variants);
        // $var_str = str_replace(' ', '', $var_str);
        $var_str = $request->variants;
        if ($var_str != "") {
            $temp_str = $str == "" ? $var_str : '-'.$var_str;
            $str .= $temp_str;
        }

        // Log::info($request->variants);
        // Log::info($request->variants);
        $product_stock = $product->stocks->where('variant', $str)->first();
        $price = $product_stock->price;
        $stockQuantity = $product_stock->qty;


        //discount calculation
        $discount_applicable = false;

        if ($product->discount_start_date == null) {
            $discount_applicable = true;
        }
        elseif (strtotime(date('d-m-Y H:i:s')) >= $product->discount_start_date &&
            strtotime(date('d-m-Y H:i:s')) <= $product->discount_end_date) {
            $discount_applicable = true;
        }

        if ($discount_applicable) {
            if($product->discount_type == 'percent'){
                $price -= ($price*$product->discount)/100;
            }
            elseif($product->discount_type == 'amount'){
                $price -= $product->discount;
            }
        }

        if ($product->tax_type == 'percent') {
            $price += ($price * $product->tax) / 100;
        } elseif ($product->tax_type == 'amount') {
            $price += $product->tax;
        }

        ini_set('serialize_precision', -1);

        return response()->json([
            'product_id' => $product->id,
            'variant' => $str,
            'price' => (double)round(convert_price($price),2),
            'photos' => json_decode($product_stock->variant_image),
            'price_string' => format_price(convert_price(round($price,2))),
            'stock' => intval($stockQuantity)
        ]);
    }

    public function home()
    {
        return new ProductCollection(Product::inRandomOrder()->take(50)->get());
    }

    public function productExtra($id)
    {
        
        if($id)
        {
            $products = Product::where('id',$id)->first();
            $product_extra = ProductExtra::where('product_id',$id)->first();
            // dd($product_extra);
            if($product_extra)
            {
                if($product_extra->battery == 0){
                    $bat_text = 'Not required';
                }
                else{
                    $bat_text = 'Battery Required';
                }
                // return response()->json([
                //     'id' => $product_extra->product_id,
                //     'name' => $products->name,
                //     'material' => '<p>'.$product_extra->material.'</p>',
                //     'battery' => $bat_text,
                //     'battery_type' => $product_extra->battery_type,
                //     'package_dimention' => $product_extra->package_dimention,
                //     'product_dimention' => $product_extra->product_dimention,
                //     'age_for' => $product_extra->age_for,
                //     'country_of_origin' =>$product_extra->country_of_origin,
                //     'product_weight' => $product_extra->product_weight,
                //     'product_weight_unit' => $product_extra->product_weight_unit,
                //     'package_include' => $product_extra->package_include,
                //     'package_include_arabic' => $product_extra->package_include_arabic,
                //     'package_unit' => $product_extra->package_unit,
                //     'product_unit' => $product_extra->product_unit,
                //     'description' => $products->description,
                    
                // ]);
                return new ProductExtraCollection(ProductExtra::where('product_id',$id)->get());
            }
            
        }
    }
}
