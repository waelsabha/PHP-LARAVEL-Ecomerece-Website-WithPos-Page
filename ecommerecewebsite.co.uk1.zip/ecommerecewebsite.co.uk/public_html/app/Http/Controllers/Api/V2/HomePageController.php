<?php

namespace App\Http\Controllers\Api\V2;

use App\Http\Resources\V2\HomePageFirstCollection;
use App\Http\Resources\V2\ProductCollection;
use App\Http\Resources\V2\ProductMiniCollection;
use App\Http\Resources\V2\ShowHomeCategories;
use App\Models\FlashDeal;
use App\Models\Product;
use App\HomePageShow;
use App\HomePageViewCategoriesSection2;
use App\HomePageViewCategoriesSectionBanner;
use App\Http\Resources\V2\ProductMiniHomePageCollection;
use Illuminate\Support\Facades\Log;
class HomePageController extends Controller
{
    public function home_page_first()
    {
        $home_show = HomePageShow::where('id', '15')->get();
        // $flash_deals = FlashDeal::where('status', 1)->where('start_date', '<=', strtotime(date('d-m-Y')))->where('end_date', '>=', strtotime(date('d-m-Y')))->get();
        return new HomePageFirstCollection($home_show);
    }

    public function products($id){
        $home_show = HomePageShow::find($id);
        $check_home = HomePageShow::where('show_in_app_home_first',$id)->first();
        if($check_home)
        {
            $home_show = HomePageShow::find($check_home->id);
        }
        //Log::info('here in home page id'.$id);
        //Log::info('here in home page controller 1');
        $products = filter_products(\App\Product::where('published', 1)->where('home_page_show','like', '%' . $home_show->id . '%'))->latest()->get();
       
        // $products = collect();
        // foreach ($flash_deal->flashDealProducts as $key => $flash_deal_product) {
        //     if(Product::find($flash_deal_product->product_id) != null){
        //         $products->push(Product::find($flash_deal_product->product_id));
        //     }
        // }
        //Log::info('here in home page controller');
        return new ProductMiniCollection($products);
    }

    public function home_page_position_heading($id)
    {
        $home_show = HomePageShow::where('show_in_app_position',$id)->first();

        return $home_show->show_in_app_name;
    }

    public function home_page_position($id)
    {
        $home_show = HomePageShow::where('show_in_app_position',$id)->first();
        
        $products = filter_products(\App\Product::where('published', 1)->where('category_id',4)->whereRaw('FIND_IN_SET(?,home_page_show)', [$home_show->id]))->limit(12)->latest()->get();
        return new ProductMiniHomePageCollection($products);
    }

    public function home_page_view_categories($id)
    {
        $home_show = HomePageViewCategoriesSection2::where('status',1)->where('show_id',$id)->get();

        return new ShowHomeCategories($home_show);
    }

    public function home_page_view_categories_banner($id)
    {
        $home_show = HomePageViewCategoriesSectionBanner::where('status',1)->where('show_id',$id)->get();

        // return [
        //     'success' => json_encode($home_show),
        //     'status' => 200
        // ];
        return new HomePageFirstCollection($home_show);
        // return new ShowHomeCategories($home_show);
    }
}
