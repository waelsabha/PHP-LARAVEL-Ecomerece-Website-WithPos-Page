<?php


namespace App\Http\Controllers\Api\V2;
use Illuminate\Http\Request;

use App\Order;
use App\OrderDetail;
use App\Utility\NgeniusUtility;
use App\Http\Controllers\PostPayController;
use App\Http\Controllers\CheckoutController;

use PDF;
use Mail;
use App\Mail\InvoiceEmailManager;
use App\PickupPoint;

use Illuminate\Support\Facades\Log;
use App\Utility\verifyEmail;

class PaymentTypesController
{

    public function getList(Request $request)
    {
        $mode = "order";

        if($request->has('mode')){
            $mode = $request->mode; // wallet or other things , comes from query param ?mode=wallet
        }

        $payment_types = array();

        if($mode != 'wallet') {
            if ( get_setting('wallet_system') == 1) {
                // $payment_type = array();
                // $payment_type['payment_type'] = 'wallet_system';
                // $payment_type['payment_type_key'] = 'wallet';
                // $payment_type['image'] = static_asset('assets/img/cards/wallet.png');
                // $payment_type['name'] = "Wallet";
                // $payment_type['title'] = "Wallet Payment";

                // $payment_types[] = $payment_type;
            }

            if ( get_setting('cash_payment') == 1) {
                $payment_type = array();
                $payment_type['payment_type'] = 'cash_payment';
                $payment_type['payment_type_key'] = 'cash_on_delivery';
                $payment_type['image'] = static_asset('assets/img/cards/cod.png');
                $payment_type['name'] = "Cash Payment";
                $payment_type['title'] = "Cash on delivery";

                $payment_types[] = $payment_type;
            }
        }

        if ( get_setting('paypal_payment') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'paypal_payment';
            $payment_type['payment_type_key'] = 'paypal';
            $payment_type['image'] = static_asset('assets/img/cards/paypal.png');
            $payment_type['name'] = "Paypal";
            $payment_type['title'] = "Checkout with Paypal";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Paypal";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('stripe_payment') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'stripe_payment';
            $payment_type['payment_type_key'] = 'stripe';
            $payment_type['image'] = static_asset('assets/img/cards/stripe.png');
            $payment_type['name'] = "Stripe";
            $payment_type['title'] = "Checkout with Stripe";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Stripe";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('razorpay') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'razorpay';
            $payment_type['payment_type_key'] = 'razorpay';
            $payment_type['image'] = static_asset('assets/img/cards/rozarpay.png');
            $payment_type['name'] = "Razorpay";
            $payment_type['title'] = "Checkout with Razorpay";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Razorpay";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('paystack') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'paystack';
            $payment_type['payment_type_key'] = 'paystack';
            $payment_type['image'] = static_asset('assets/img/cards/paystack.png');
            $payment_type['name'] = "Paystack";
            $payment_type['title'] = "Checkout with Paystack";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Paystack";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('ngenius') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'ngenius';
            $payment_type['payment_type_key'] = 'ngenius';
            $payment_type['image'] = static_asset('assets/img/cards/ngenius.png');
            $payment_type['name'] = "Ngenius";
            $payment_type['title'] = "Checkout with Card";
            // if($mode == 'wallet') {
            //     $payment_type['title'] = "Recharge with Ngenius";
            // }

            $payment_types[] = $payment_type;
        }

        // if (get_setting('postpay') == 1) {
        //     $payment_type = array();
        //     $payment_type['payment_type'] = 'postpay';
        //     $payment_type['payment_type_key'] = 'postpay';
        //     $payment_type['image'] = static_asset('assets/img/cards/postpay.jpg');
        //     $payment_type['name'] = "Postpay";
        //     $payment_type['title'] = "Buy Now.Pay Later.";
        //     // if($mode == 'wallet') {
        //     //     $payment_type['title'] = "Recharge with Iyzico";
        //     // }

        //     $payment_types[] = $payment_type;
        // }

        

        if (get_setting('nagad') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'nagad';
            $payment_type['payment_type_key'] = 'bkash';
            $payment_type['image'] = static_asset('assets/img/cards/nagad.png');
            $payment_type['name'] = "Nagad";
            $payment_type['title'] = "Checkout with Nagad";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Nagad";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('sslcommerz_payment') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'sslcommerz_payment';
            $payment_type['payment_type_key'] = 'sslcommerz';
            $payment_type['image'] = static_asset('assets/img/cards/sslcommerz.png');
            $payment_type['name'] = "Sslcommerz";
            $payment_type['title'] = "Checkout with Sslcommerz";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Sslcommerz";
            }

            $payment_types[] = $payment_type;
        }

        // you cannot recharge wallet by wallet or cash payment
        


        return response()->json($payment_types);
    }

    public function getList2(Request $request)
    {
        $mode = "order";

        if($request->has('mode')){
            $mode = $request->mode; // wallet or other things , comes from query param ?mode=wallet
        }

        $payment_types = array();

        if($mode != 'wallet') {
            if ( get_setting('wallet_system') == 1) {
                // $payment_type = array();
                // $payment_type['payment_type'] = 'wallet_system';
                // $payment_type['payment_type_key'] = 'wallet';
                // $payment_type['image'] = static_asset('assets/img/cards/wallet.png');
                // $payment_type['name'] = "Wallet";
                // $payment_type['title'] = "Wallet Payment";

                // $payment_types[] = $payment_type;
            }

            if ( get_setting('cash_payment') == 1) {
                $payment_type = array();
                $payment_type['payment_type'] = 'cash_payment';
                $payment_type['payment_type_key'] = 'cash_on_delivery';
                $payment_type['image'] = static_asset('assets/img/cards/cod.png');
                $payment_type['name'] = "Cash Payment";
                $payment_type['title'] = "Cash on delivery";

                $payment_types[] = $payment_type;
            }
        }

        if ( get_setting('paypal_payment') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'paypal_payment';
            $payment_type['payment_type_key'] = 'paypal';
            $payment_type['image'] = static_asset('assets/img/cards/paypal.png');
            $payment_type['name'] = "Paypal";
            $payment_type['title'] = "Checkout with Paypal";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Paypal";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('stripe_payment') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'stripe_payment';
            $payment_type['payment_type_key'] = 'stripe';
            $payment_type['image'] = static_asset('assets/img/cards/stripe.png');
            $payment_type['name'] = "Stripe";
            $payment_type['title'] = "Checkout with Stripe";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Stripe";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('razorpay') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'razorpay';
            $payment_type['payment_type_key'] = 'razorpay';
            $payment_type['image'] = static_asset('assets/img/cards/rozarpay.png');
            $payment_type['name'] = "Razorpay";
            $payment_type['title'] = "Checkout with Razorpay";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Razorpay";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('paystack') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'paystack';
            $payment_type['payment_type_key'] = 'paystack';
            $payment_type['image'] = static_asset('assets/img/cards/paystack.png');
            $payment_type['name'] = "Paystack";
            $payment_type['title'] = "Checkout with Paystack";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Paystack";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('ngenius') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'ngenius';
            $payment_type['payment_type_key'] = 'ngenius';
            $payment_type['image'] = static_asset('assets/img/cards/ngenius.png');
            $payment_type['name'] = "Ngenius";
            $payment_type['title'] = "Checkout with Card";
            // if($mode == 'wallet') {
            //     $payment_type['title'] = "Recharge with Ngenius";
            // }

            $payment_types[] = $payment_type;
        }

        if (get_setting('postpay') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'postpay';
            $payment_type['payment_type_key'] = 'postpay';
            $payment_type['image'] = static_asset('assets/img/cards/postpay.jpg');
            $payment_type['name'] = "Postpay";
            $payment_type['title'] = "Buy Now.Pay Later.";
            // if($mode == 'wallet') {
            //     $payment_type['title'] = "Recharge with Iyzico";
            // }

            $payment_types[] = $payment_type;
        }

        

        if (get_setting('nagad') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'nagad';
            $payment_type['payment_type_key'] = 'bkash';
            $payment_type['image'] = static_asset('assets/img/cards/nagad.png');
            $payment_type['name'] = "Nagad";
            $payment_type['title'] = "Checkout with Nagad";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Nagad";
            }

            $payment_types[] = $payment_type;
        }

        if (get_setting('sslcommerz_payment') == 1) {
            $payment_type = array();
            $payment_type['payment_type'] = 'sslcommerz_payment';
            $payment_type['payment_type_key'] = 'sslcommerz';
            $payment_type['image'] = static_asset('assets/img/cards/sslcommerz.png');
            $payment_type['name'] = "Sslcommerz";
            $payment_type['title'] = "Checkout with Sslcommerz";
            if($mode == 'wallet') {
                $payment_type['title'] = "Recharge with Sslcommerz";
            }

            $payment_types[] = $payment_type;
        }

        // you cannot recharge wallet by wallet or cash payment
        


        return response()->json($payment_types);
    }



    public function paymentCheck($user_id,$token)
    {

        $header = ["accept: application/json"];
        // $data_pass = array_merge($data1);  
                // dd(array_merge($data1,$params));
            // dd(date('m/d/yy H:i'));
        $tok2 = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjFmNDQ1MzQ5ZDhhY2MxYjQyYTUzMWJlYzZmOTY4OGUzNDZkNjU5YTVjOTg3MTJjNWM2MTZlODZjMDk1YWQ5OTcyMGY5NGRkOTI1NDQ4YzEzIn0.eyJhdWQiOiIxIiwianRpIjoiMWY0NDUzNDlkOGFjYzFiNDJhNTMxYmVjNmY5Njg4ZTM0NmQ2NTlhNWM5ODcxMmM1YzYxNmU4NmMwOTVhZDk5NzIwZjk0ZGQ5MjU0NDhjMTMiLCJpYXQiOjE2Mjk1NDgyMzIsIm5iZiI6MTYyOTU0ODIzMiwiZXhwIjoxNjYxMDg0MjMyLCJzdWIiOiIzODIiLCJzY29wZXMiOltdfQ.Rxiu8X9ZqcrSMz9oNJGqF8sKp_P939IoFMWooN3iB9AMcFeq-4yC2dfHaQbUJ6jS5FQxrm_rkQBXoh8WhANbB1-k3fBP86eNlRKjTcdZSk8TtBfJtF1F3zztmLCdhypTB_yS64ixWvvwF5Lgv_GQCCCPMKMuIOjMlP_R3GvORdwqvDfHrWK6hrDmtrL2Svyycs8E-tiP1un8v1NMzTwqGyXgSboSDhmg5REm5c9eCKQsmo1k8JC6vsrwneT14cwXOdBl4JiiRxYs6nhn2BjUsJs2ccqwohFt-DlDkZ_uG0vBm80zeE9GOtWQwJIp9keSCXxhTD6hfs9vtepTDBoDxH19kKnhRKo8E6BlL7yNj2SF3jdeDHZuAxeq-I19te2Ip7xZS9g66N87XBmis6A9WSsZRTOfcF_ivfys5fm604gisnvZB1SYPm8TvAEqPOdP716WZoERHsFXxBY4BS0wtRZhdhJ39G-VmFDIfzdoYfgxMR5uDM2aTddj0pLEnhWeuiMXpBsVAPAIUNqf-6lCNjSZRcF7bSr81PqLOrvk1ovEE6I8l-mwbKLddldCzgGRGCiXpD_XGwruVeL024WLWlLCxrxoNhqIL4FtjwjAEdP-fi0LBi-EtnFl";
        
        $curl = curl_init();
        $url= "https://birigroup.co.uk/api/v2/payment/method/".$user_id;
        // dd($url);
        curl_setopt_array($curl, array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_TIMEOUT => 30000,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          
          CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/json"
          ),
        ));
        
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);

        if ($err) {
            //echo "cURL Error #:" . $err;
            dd($err);
            $res=$err;
        } else {
            
            if(isset(json_decode($response)->status))
            {
                $content = new Request();
                $content->user_id = $user_id;
                $content->payment_type = 'ngenius';
                $order = new OrderController;
                $save = $order->store($content);
                $saved_order = Order::where('id',$save)->first();
                $total_amount = $saved_order->grand_total;

                
            
                $amount = round($total_amount * 100);
                // $this->ngenius_make_payment(route('ngenius.app.cart_payment_callback'),"cart_payment",$amount,$save);
                NgeniusUtility::ngenius_make_payment(route('ngenius.app.cart_payment_callback'),"cart_payment",$amount,$save);
                
            }
            // dd(json_decode($response));
            $res= json_decode($response, true);
        } 
    }

    public function paymentCheckGuest($device_id)
    {
            // dd('here');
                $content = new Request();
                $content->device_id = $device_id;
                $content->payment_type = 'ngenius';
                $order = new OrderController;
                $save = $order->storeGuest($content);
                $saved_order = Order::where('id',$save)->first();
                $total_amount = $saved_order->grand_total;

                
            
                $amount = round($total_amount * 100);
                // $this->ngenius_make_payment(route('ngenius.app.cart_payment_callback'),"cart_payment",$amount,$save);
                NgeniusUtility::ngenius_make_payment(route('ngenius.app.cart_payment_callback'),"cart_payment",$amount,$save);
                
            
            // dd(json_decode($response));
            $res= json_decode($response, true);
        
    }

    public function paymentMethod($user_id)
    {
        return response()->json(['status' => 'true']);
    }

    public function paymentCheckPostpay($user_id,$token)
    {
        $header = ["accept: application/json"];
        // $data_pass = array_merge($data1);  
                // dd(array_merge($data1,$params));
            // dd(date('m/d/yy H:i'));
               
        $curl = curl_init();
        $url= "https://birigroup.co.uk/api/v2/payment/method/".$user_id;
        // dd($url);
        curl_setopt_array($curl, array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_TIMEOUT => 30000,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          
          CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/json"
          ),
        ));
        
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);

        if ($err) {
            //echo "cURL Error #:" . $err;
            dd($err);
            $res=$err;
        } else {
            
            if(isset(json_decode($response)->status))
            {
                $content = new Request();
                $content->user_id = $user_id;
                $content->payment_type = 'ngenius';
                $order = new OrderController;
                $save = $order->store($content);
                $saved_order = Order::where('id',$save)->first();
                $total_amount = $saved_order->grand_total;

                
            
                $amount = round($total_amount * 100);
                $postpay = new PostPayController;
                $res = $postpay->appPostPayCheckout($save);
                return redirect()->away($res);
                // $this->ngenius_make_payment(route('ngenius.app.cart_payment_callback'),"cart_payment",$amount,$save);
                // NgeniusUtility::ngenius_make_payment(route('ngenius.app.cart_payment_callback'),"cart_payment",$amount,$save);
                // dd('here');
            }
            // dd(json_decode($response));
            $res= json_decode($response, true);
        } 
            
    }

    public function paymentCheckPostpayGuest($device_id)
    {
        
                $content = new Request();
                $content->device_id = $device_id;
                $content->payment_type = 'ngenius';
                $order = new OrderController;
                $save = $order->storeGuest($content);
                $saved_order = Order::where('id',$save)->first();
                $total_amount = $saved_order->grand_total;

                
            
                $amount = round($total_amount * 100);
                $postpay = new PostPayController;
                $res = $postpay->appPostPayCheckout($save);
                return redirect()->away($res);
                // $this->ngenius_make_payment(route('ngenius.app.cart_payment_callback'),"cart_payment",$amount,$save);
                // NgeniusUtility::ngenius_make_payment(route('ngenius.app.cart_payment_callback'),"cart_payment",$amount,$save);
                // dd('here');
          
            
    }

    public function paymentCheckCod($user_id,$token)
    {
        $header = ["accept: application/json"];
        // $data_pass = array_merge($data1);  
                // dd(array_merge($data1,$params));
            // dd(date('m/d/yy H:i'));
               
        $curl = curl_init();
        $url= "https://birigroup.co.uk/api/v2/payment/method/".$user_id;
        // dd($url);
        curl_setopt_array($curl, array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_TIMEOUT => 30000,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          
          CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/json"
          ),
        ));
        
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);

        if ($err) {
            //echo "cURL Error #:" . $err;
            dd($err);
            $res=$err;
        } else {
            
            if(isset(json_decode($response)->status))
            {
                $content = new Request();
                $content->user_id = $user_id;
                $content->owner_id = 9;
                $content->payment_type = 'cash_on_delivery';
                $save_order = new OrderController;
                $save = $save_order->store($content);
                $order = Order::where('id',$save)->first();

                $order_details = OrderDetail::where('order_id',$order->id)->first();

                    $pdf = PDF::setOptions([
                        'isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true,
                        'logOutputFile' => storage_path('logs/log.htm'),
                        'tempDir' => storage_path('logs/')
                    ])->loadView('invoices.customer_invoice', compact('order'));
                        $output = $pdf->output();
                        file_put_contents('public/invoices/'.'Order#'.$order->code.'.pdf', $output);
        
                        
                        if($order_details->shipping_type == 'home_delivery')
                        {
                            $array['shipping_type'] = $order_details->shipping_type;
        
                        }
                        else{
                            $array['shipping_type'] = $order_details->shipping_type;
                            $pick_up_address = PickupPoint::where('id',$order_details->pickup_point_id)->first();
                            $array['pickup_address'] = $pick_up_address->address;
                            $array['phone']  = $pick_up_address->phone;
                        }
                        $array['code'] = $order->code;
                        $array['order'] = $order;
        
                        // dd($array['order']);
                        $array['order_details'] = $order_details;
                        $array['view'] = 'emails.invoice';
                        $array['subject'] = 'Order Placed - Berry Building Materials';
                        $array['from'] = env('MAIL_USERNAME');
                        $array['content'] = translate('A new order has been placed. Please check the attached invoice.');
                        $array['file'] = 'public/invoices/Order#'.$order->code.'.pdf';
                        $array['file_name'] = 'Order#'.$order->code.'.pdf';
        
                        
                            try {
                                //Log::info('try');
                                if(is_null($order->user_id)){

                                $email = json_decode($order->shipping_address)->email;
                                $email_info = env('EMAIL_INFO');
                                $email_it = env('EMAIL_IT');
                                $email_more = env('EMAIL_MORE');
                                $email_more = env('EMAIL_MORE');
                                $send_to = [$email];
                                $bcc = [$email_info,$email_it,$email_more];
                                

                                  
                                     Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                }
                                else{
                                    //Log::info(\App\User::find($order->user_id)->email);
                                    $email = \App\User::find($order->user_id)->email;
                                    $email_info = env('EMAIL_INFO');
                                    $email_it = env('EMAIL_IT');
                                    $email_more = env('EMAIL_MORE');
                                    $send_to = [$email];
                                    $bcc = [$email_info,$email_it,$email_more];
                                   

                                    Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                    //Log::info('send');
                                }
                                

                                $phone = json_decode($order->shipping_address)->phone;
                                $explode = explode(',',$phone);
                                $text = 'Dear Customer, your  order ('.$order->code.') has been successfully placed.We are preparing your order and we will inform you when it is shipped.';
                                if($order->country_id == '229')
                                {
                                    $checkout_controller = new CheckoutController;
                                    // $get = $checkout_controller->apiDataToPos($order->id,$payment);
                                    $checkout_controller->send_message($explode[0],$text);
                                }
                                

                            } catch (\Exception $e) {
                                Log::info($e);
                            }

                    try {
                        //Log::info('Sending to api fn');
                        $payment = 'not_paid';
                        $checkout_controller = new CheckoutController;
                        $get = $checkout_controller->apiDataToPos($order->id,$payment);
                        //Log::info('sale invoice updated in pos');
                    }
                    catch(\Exception $e)
                    {
                        //Log::info('Could not update in pos');
                    }
                     
                
                return view('frontend.app_confirm_order', compact('order'));
                // dd(json_decode($response));
                $res= json_decode($response, true);
            }
        } 
            
    }

    public function paymentCheckCodGuest($device_id)
    {
          
                
                $content = new Request();
                if($content->payment_type != '' || $content->payment_type != null)
                {
                    
                }
                $content->device_id = $device_id;
                $content->owner_id = 9;
                $content->payment_type = 'cash_on_delivery';
                $save_order = new OrderController;
                $save = $save_order->storeGuest($content);
                $order = Order::where('id',$save)->first();

                $order_details = OrderDetail::where('order_id',$order->id)->first();

                    $pdf = PDF::setOptions([
                        'isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true,
                        'logOutputFile' => storage_path('logs/log.htm'),
                        'tempDir' => storage_path('logs/')
                    ])->loadView('invoices.customer_invoice', compact('order'));
                        $output = $pdf->output();
                        file_put_contents('public/invoices/'.'Order#'.$order->code.'.pdf', $output);
        
                        
                        if($order_details->shipping_type == 'home_delivery')
                        {
                            $array['shipping_type'] = $order_details->shipping_type;
        
                        }
                        else{
                            $array['shipping_type'] = $order_details->shipping_type;
                            $pick_up_address = PickupPoint::where('id',$order_details->pickup_point_id)->first();
                            $array['pickup_address'] = $pick_up_address->address;
                            $array['phone']  = $pick_up_address->phone;
                        }
                        $array['code'] = $order->code;
                        $array['order'] = $order;
        
                        // dd($array['order']);
                        $array['order_details'] = $order_details;
                        $array['view'] = 'emails.invoice';
                        $array['subject'] = 'Order Placed - Berry Building Materials';
                        $array['from'] = env('MAIL_USERNAME');
                        $array['content'] = translate('A new order has been placed. Please check the attached invoice.');
                        $array['file'] = 'public/invoices/Order#'.$order->code.'.pdf';
                        $array['file_name'] = 'Order#'.$order->code.'.pdf';
        
                        
                            try {
                                //Log::info('try');
                                if(is_null($order->user_id)){

                                $email = json_decode($order->shipping_address)->email;
                                $email_info = env('EMAIL_INFO');
                                $email_it = env('EMAIL_IT');
                                $email_more = env('EMAIL_MORE');
                                $email_more = env('EMAIL_MORE');
                                $send_to = [$email];
                                $bcc = [$email_info,$email_it,$email_more];

                              
                                Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
 
                                }
                                else{
                                    //Log::info(\App\User::find($order->user_id)->email);
                                    $email = \App\User::find($order->user_id)->email;
                                    $email_info = env('EMAIL_INFO');
                                    $email_it = env('EMAIL_IT');
                                    $email_more = env('EMAIL_MORE');
                                    $send_to = [$email];
                                    $bcc = [$email_info,$email_it,$email_more];
                                    
                                 
                                    Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                }
                                

                                $phone = json_decode($order->shipping_address)->phone;
                                $explode = explode(',',$phone);
                                $text = 'Dear Customer, your  order ('.$order->code.') has been successfully placed.We are preparing your order and we will inform you when it is shipped.';
                                if($order->country_id == '229')
                                {
                                    $checkout_controller = new CheckoutController;
                                    // $get = $checkout_controller->apiDataToPos($order->id,$payment);
                                    $checkout_controller->send_message($explode[0],$text);
                                }
                                

                            } catch (\Exception $e) {
                                Log::info($e);
                            }

                    try {
                        //Log::info('Sending to api fn');
                        $payment = 'not_paid';
                        $checkout_controller = new CheckoutController;
                        $get = $checkout_controller->apiDataToPos($order->id,$payment);
                        //Log::info('sale invoice updated in pos');
                    }
                    catch(\Exception $e)
                    {
                        //Log::info('Could not update in pos');
                    }
                     
                
                return view('frontend.app_confirm_order', compact('order'));
                // dd(json_decode($response));
                $res= json_decode($response, true);
            
         
            
    }

    public function ngenius_check_callback($orderRef, $payment_type)
    {

    }

}
