<?php

namespace App\Http\Controllers;



use Illuminate\Http\Request;
use App\Http\Controllers\OTPVerificationController;
use App\Http\Controllers\ClubPointController;
use App\Http\Controllers\AffiliateController;
use App\Order;
use App\Product;
use App\Color;
use App\OrderDetail;
use App\CouponUsage;
use App\OtpConfiguration;
use App\User;
use App\BusinessSetting;
use App\CartDetail;
use App\CartList;
use App\Country;
use App\Currency;
use Auth;
use Session;
use DB;
use PDF;
use Mail;
use App\Mail\InvoiceEmailManager;
use App\PickupPoint;
use App\ShippingCharge;
use CoreComponentRepository;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use SimpleXMLElement;


use Symfony\Component\Console\Input\Input;
use App\GiftRecipient;
use App\FreeProduct;
use SMSGlobal\Credentials;
use SMSGlobal\Resource\Sms;
use App\Utility\verifyEmail;
class OrderController extends Controller
{
    /**
     * Display a listing of the resource to seller.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        //
        update_all_stock_from_pos();
        // update_cartDb_to_cartSession();
    }
    public function index(Request $request)
    {
        $payment_status = null;
        $delivery_status = null;
        $sort_search = null;
        $orders = DB::table('orders')
            ->orderBy('code', 'desc')
            ->join('order_details', 'orders.id', '=', 'order_details.order_id')
            ->where('order_details.seller_id', Auth::user()->id)
            ->select('orders.id')
            ->distinct();

        if ($request->payment_status != null) {
            $orders = $orders->where('order_details.payment_status', $request->payment_status);
            $payment_status = $request->payment_status;
        }
        if ($request->delivery_status != null) {
            $orders = $orders->where('order_details.delivery_status', $request->delivery_status);
            $delivery_status = $request->delivery_status;
        }
        if ($request->has('search')) {
            $sort_search = $request->search;
            $orders = $orders->where('code', 'like', '%' . $sort_search . '%');
        }

        $orders = $orders->paginate(15);

        foreach ($orders as $key => $value) {
            $order = \App\Order::find($value->id);
            $order->viewed = 1;
            $order->save();
        }

        return view('frontend.seller.orders', compact('orders', 'payment_status', 'delivery_status', 'sort_search'));
    }

    /**
     * Display a listing of the resource to admin.
     *
     * @return \Illuminate\Http\Response
     */
    public function admin_orders(Request $request)
    {
        CoreComponentRepository::instantiateShopRepository();

        $payment_status = null;
        $delivery_status = null;
        $sort_search = null;
        $admin_user_id = User::where('user_type', 'admin')->first()->id;
        $orders = DB::table('orders')

            ->join('order_details', 'orders.id', '=', 'order_details.order_id')
            ->where('order_details.seller_id', $admin_user_id)

            ->select('orders.id')

            ->distinct()
            ->groupBy('orders.id')->orderBy('code', 'desc');


        if ($request->payment_type != null) {
            $orders = $orders->where('order_details.payment_status', $request->payment_type);
            $payment_status = $request->payment_type;
        }
        if ($request->delivery_status != null) {
            $orders = $orders->where('order_details.delivery_status', $request->delivery_status);
            $delivery_status = $request->delivery_status;
        }
        if ($request->has('search')) {
            $sort_search = $request->search;
            $orders = $orders->where('code', 'like', '%' . $sort_search . '%');
        }
        // dd($orders);
        $orders = $orders->paginate(15);


        return view('orders.index', compact('orders', 'payment_status', 'delivery_status', 'sort_search', 'admin_user_id'));
    }

    /**
     * Display a listing of the sales to admin.
     *
     * @return \Illuminate\Http\Response
     */
    public function sales(Request $request)
    {
        CoreComponentRepository::instantiateShopRepository();

        $sort_search = null;
        $orders = Order::orderBy('code', 'desc');
        if ($request->has('search')) {
            $sort_search = $request->search;
            $orders = $orders->where('code', 'like', '%' . $sort_search . '%');
        }
        $orders = $orders->paginate(15);
        return view('sales.index', compact('orders', 'sort_search'));
    }


    public function order_index(Request $request)
    {
        if (Auth::user()->user_type == 'staff' && Auth::user()->staff->pick_up_point != null) {
            //$orders = Order::where('pickup_point_id', Auth::user()->staff->pick_up_point->id)->get();
            $orders = DB::table('orders')
                ->orderBy('code', 'desc')
                ->join('order_details', 'orders.id', '=', 'order_details.order_id')
                ->where('order_details.pickup_point_id', Auth::user()->staff->pick_up_point->id)
                ->select('orders.id')
                ->distinct()
                ->paginate(15);

            return view('pickup_point.orders.index', compact('orders'));
        } else {
            //$orders = Order::where('shipping_type', 'Pick-up Point')->get();
            $orders = DB::table('orders')
                ->orderBy('code', 'desc')
                ->join('order_details', 'orders.id', '=', 'order_details.order_id')
                ->where('order_details.shipping_type', 'pickup_point')
                ->select('orders.id')
                ->distinct()
                ->paginate(15);

            return view('pickup_point.orders.index', compact('orders'));
        }
    }

    public function pickup_point_order_sales_show($id)
    {
        if (Auth::user()->user_type == 'staff') {
            $order = Order::findOrFail(decrypt($id));
            return view('pickup_point.orders.show', compact('order'));
        } else {
            $order = Order::findOrFail(decrypt($id));
            return view('pickup_point.orders.show', compact('order'));
        }
    }

    /**
     * Display a single sale to admin.
     *
     * @return \Illuminate\Http\Response
     */
    public function sales_show($id)
    {
        $order = Order::findOrFail(decrypt($id));
        return view('sales.show', compact('order'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $order = new Order;
        if (Auth::check()) {
            $order->user_id = Auth::user()->id;
        } else {
            $order->guest_id = mt_rand(100000, 999999);
        }
        // dd(json_encode($request->session()->get('shipping_info')));


        $order->shipping_address = json_encode($request->session()->get('shipping_info'));

        $order->payment_type = $request->payment_option;
        $order->delivery_viewed = '0';
        $order->payment_status_viewed = '0';
        $order->code = date('Ymd-His') . rand(10, 99);

            

        $order->date = strtotime('now');

        if ($order->save()) {

            if (Auth::check()) {
                $ip = null;
                $user_id = Auth::user()->id;
                $cart_list = CartList::where('user_id', $user_id)->first();
                if ($cart_list) {
                    CartDetail::where('cart_list_id', $cart_list->id)->delete();
                    CartList::where('id', $cart_list->id)->delete();
                }
            } else {
                $user_id = null;
                $ip = $request->ip();
                $cart_list = CartList::where('ip_address', $ip)->first();
                if ($cart_list) {
                    CartDetail::where('cart_list_id', $cart_list->id)->delete();
                    CartList::where('id', $cart_list->id)->delete();
                }
            }

            $subtotal = 0;
            $tax = 0;
            $shipping = $request->session()->get('shipping');
            // dd(Session::get('shipping_info'));
            //calculate shipping is to get shipping costs of different types
            $admin_products = array();
            $seller_products = array();
            $gift_wrap = 0;
            $id_array = array();
            //Order Details Storing
            // dd(Session::get('cart'));
            foreach (Session::get('cart') as $key => $cartItem) {
                $id_array[] = $cartItem['id'];
                $product = Product::find($cartItem['id']);



                if ($product->added_by == 'admin') {
                    array_push($admin_products, $cartItem['id']);
                } else {
                    $product_ids = array();
                    if (array_key_exists($product->user_id, $seller_products)) {
                        $product_ids = $seller_products[$product->user_id];
                    }
                    array_push($product_ids, $cartItem['id']);
                    $seller_products[$product->user_id] = $product_ids;
                }

                $subtotal += calculatePricePercentageBaseCurrency($cartItem['price']) * $cartItem['quantity'];
                $tax += $cartItem['tax'] * $cartItem['quantity'];

                $product_variation = $cartItem['variant'];
                try {


                    if ($product_variation != null) {
                        $product_stock = $product->stocks->where('product_id', $product->id)->where('variant', $product_variation)->first();
                        $product_stock->qty -= $cartItem['quantity'];
                        $product_stock->save();
                    } else {
                        $product->current_stock -= $cartItem['quantity'];
                        $product->save();
                    }
                } catch (\Exception $e) {
                }
                if(!isset($cartItem['shipping_type']))
                {
                    $cartItem['shipping_type'] = 'home_delivery';
                }
                $order_detail = new OrderDetail;
                $order_detail->order_id  = $order->id;
                $order_detail->seller_id = $product->user_id;
                $order_detail->product_id = $product->id;
                $order_detail->variation = $product_variation;
                $order_detail->price = calculatePricePercentageBaseCurrency($cartItem['price']) * $cartItem['quantity'];
                $order_detail->tax = $cartItem['tax'] * $cartItem['quantity'];
                $order_detail->shipping_type = $cartItem['shipping_type'];
                $order_detail->product_referral_code = $cartItem['product_referral_code'];

                if (isset($cartItem['gift_wrapper'])) {
                    if ($cartItem['gift_wrapper'] == 1) {
                        $order_detail->gift_wrapper = $cartItem['gift_wrapper'];
                        $gift_wrap += env('GIFT_WRAPPER_AED') * $cartItem['quantity'];
                    }
                }

                if (isset($cartItem['free_gift']) && ($cartItem['free_gift'] != "" || $cartItem['free_gift'] != null)) {
                    if (Auth::check()) {
                        $user = Auth::user()->id;

                        $free_gift_user = GiftRecipient::where('user_id', $user)->where('offer_type', $cartItem['free_gift'])->where('status', 1)->first();
                        if ($free_gift_user) {
                            $free_gift_products = FreeProduct::where('product_id', $product->id)->where('offer_type', $cartItem['free_gift'])->where('status', 1)->first();
                            if ($free_gift_products) {
                                $free_gift_user->status = 0;
                                $free_gift_user->redeemed = 1;
                                $free_gift_user->save();
                            }
                        }
                    }
                }
                //Dividing Shipping Costs
                if(!isset($cartItem['shipping_type']))
                {
                    $cartItem['shipping_type'] = 'home_delivery';
                }
                if ($cartItem['shipping_type'] == 'home_delivery') {
                    // $order_detail->shipping_cost = getShippingCost($key);

                    $shipping_type_check =  'home_delivery';
                    $order_detail->shipping_cost = $shipping;
                    $order->shipping_cost = $shipping;
                } else {
                    $order_detail->shipping_cost = 0;
                    $shipping_info = Session::get('shipping_info');
                    $shipping_type_check =  'pick_up';
                    $order_detail->pickup_point_id = $shipping_info['pick_up_point_id'];
                    $order->shipping_cost = 0;
                }
                //End of storing shipping cost

                $order_detail->quantity = $cartItem['quantity'];
                // dd($order_detail);
                $order_detail->save();

                $product->num_of_sale++;
                $product->save();
            }
            $deduct = 0.00;
            if (Auth::check()) {
                if ($request->club_deduct_amount == 1) {
                    $user_det = User::where('id', Auth::user()->id)->first();
                    $user_bal_main = $user_det->balance;
                    $remaining = 0.00;
                    // tot deduct 40% of order value from club balance
                    $subtotal_ded_40_per = $subtotal*0.4;
                    if ($user_bal_main > $subtotal_ded_40_per) {
                        $remaining = $user_bal_main - $subtotal_ded_40_per;
                        $deduct = $subtotal_ded_40_per;
                    } else {
                        $deduct = $user_bal_main;
                    }
                    $user_det->balance = $remaining;
                    $user_det->save();
                    $order->club_point_discount = $deduct;
                    $request->session()->put('club_point_discount', $deduct);
                }
                if ($request->reg_bonus_deduct_amount == 1) {
                    $user_det = User::where('id', Auth::user()->id)->first();
                    $user_bal = $user_det->registration_bonus;
                    $remaining = 0.00;
                    if ($user_bal > 0) {
                        if ($subtotal > 100) {
                            if ($subtotal >= 100 && $subtotal < 200) {
                                $remaining = $user_bal - 10.00;
                                $deduct = 10.00;
                            }
                            if ($subtotal >= 200) {
                                if ($user_bal != 20) {
                                    $remaining = $user_bal - $user_bal;
                                    $deduct = $user_bal;
                                } else {
                                    $remaining = $user_bal - 20.00;
                                    $deduct = 20.00;
                                }
                            }
                            $user_det->registration_bonus = $remaining;
                            $user_det->save();
                            $order->registration_bonus_discount = $deduct;
                            $request->session()->put('registration_bonus_discount', $deduct);
                        }
                    }
                }
            }

            //double checking the shipping charge else update
            if(Session::has('currency_code')){
                $currency_code = Session::get('currency_code');
            }
            else{
                $currency_code = \App\Currency::findOrFail(\App\BusinessSetting::where('type', 'system_default_currency')->first()->value)->code;
            }
            $curr_db = Currency::where('code',$currency_code)->first();
                
            $country = Country::where('id',$curr_db->country_id)->first();
            if($country->code == 'AE')
            {
                if ($shipping_type_check == 'home_delivery') {
                    if ($subtotal < env('FREE_DELIVERY_ABOVE')) {
    
                        $area = ($request->session()->get('shipping_info'));
                        $shipping_charges_db = ShippingCharge::where('sc_town', $area['area'])->first();
                        $shipping = $shipping_charges_db->sc_rate_5kg;
                        $order->shipping_cost = $shipping;
                        OrderDetail::where('order_id', $order->id)->update(['shipping_cost' => $shipping]);
                        Order::where('id', $order->id)->update(['shipping_cost' => $shipping,'country_id'=>$country->id]);
                    }
                    if ($subtotal > env('FREE_DELIVERY_ABOVE')) {
                        $order->shipping_cost = '0.00';
                        OrderDetail::where('order_id', $order->id)->update(['shipping_cost' => '0.00']);
                        Order::where('id', $order->id)->update(['shipping_cost' => $shipping,'country_id'=>$country->id]);
                    }
                }
            }
            else
            {
                
                //$shipping = shippingPrice($id_array);
                // $shipping = toBasePrice($shipping,$country->id);
               // OrderDetail::where('order_id', $order->id)->update(['shipping_cost' => $shipping]);
               // Order::where('id', $order->id)->update(['shipping_cost' => $shipping,'country_id'=>$country->id]);
            }
            

            $subtotal = $subtotal - $deduct;
             $shipping_tax=($shipping*20)/100;
            $order->grand_total = $subtotal+$tax + $shipping+ $shipping_tax + $gift_wrap;

            if (Session::has('coupon_discount')) {
                $order->grand_total -= Session::get('coupon_discount');
                $order->coupon_discount = Session::get('coupon_discount');

                $coupon_usage = new CouponUsage;
                $coupon_usage->user_id = Auth::user()->id;
                $coupon_usage->coupon_id = Session::get('coupon_id');
                $coupon_usage->save();
            }
            
            $order->save();
            
            Log::info('SUbtotal---'.$subtotal.'--Shipping---'.$shipping.'---grand total--'.$order->grand_total);
            // dd('SUbtotal---'.$subtotal.'--Shipping---'.$shipping.'---grand total--'.$order->grand_total);
            //stores the pdf for invoice
            $pdf = PDF::setOptions([
                'isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true,
                'logOutputFile' => storage_path('logs/log.htm'),
                'tempDir' => storage_path('logs/')
            ])->loadView('invoices.customer_invoice', compact('order'));
            $output = $pdf->output();
            file_put_contents('public/invoices/' . 'Order#' . $order->code . '.pdf', $output);


            if ($shipping_type_check == 'home_delivery') {
                $array['shipping_type'] = $shipping_type_check;
            } else {
                $array['shipping_type'] = $shipping_type_check;
                $pick_up_address = PickupPoint::where('id', $shipping_info['pick_up_point_id'])->first();
                $array['pickup_address'] = $pick_up_address->address;
                $array['phone']  = $pick_up_address->phone;
            }

            $array['view'] = 'emails.invoice';
            $array['subject'] = 'Order Placed -Biri Trading UK LTD';
            $array['from'] = env('MAIL_USERNAME');
            $array['content'] = translate('Hi. A new order has been placed. Please check the attached invoice.');
            $array['file'] = 'public/invoices/Order#' . $order->code . '.pdf';
            $array['file_name'] = 'Order#' . $order->code . '.pdf';

            foreach ($seller_products as $key => $seller_product) {
                try {

                    $email = \App\User::find($key)->email;
                    $email_info = env('EMAIL_INFO');
                    $email_it = env('EMAIL_IT');
                    $email_more = env('EMAIL_MORE');
                    $send_to = [$email];
                    $bcc = [$email_info, $email_it, $email_more];
                                            Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));

                   
                } catch (\Exception $e) {
                }
            }

            if (\App\Addon::where('unique_identifier', 'otp_system')->first() != null && \App\Addon::where('unique_identifier', 'otp_system')->first()->activated && \App\OtpConfiguration::where('type', 'otp_for_order')->first()->value) {
                try {
                    $otpController = new OTPVerificationController;
                    $otpController->send_order_code($order);
                } catch (\Exception $e) {
                }
            }

            //sends email to customer with the invoice pdf attached
            if (env('MAIL_USERNAME') != null) {
                try {
                                            Mail::to($request->session()->get('shipping_info')['email'])->queue(new InvoiceEmailManager($array));

                  
                    
                    Mail::to(User::where('user_type', 'admin')->first()->email)->queue(new InvoiceEmailManager($array));
                } catch (\Exception $e) {
                }
            }
            unlink($array['file']);

            $request->session()->put('order_id', $order->id);



            $this->updatePosSell($request);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $order = Order::findOrFail(decrypt($id));
        $order->viewed = 1;
        $order->save();
        // dd(json_decode($order->shipping_address)->name);
        return view('orders.show', compact('order'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $order = Order::findOrFail($id);
        if ($order != null) {
            foreach ($order->orderDetails as $key => $orderDetail) {
                $orderDetail->delete();
            }
            $order->delete();
            flash(translate('Order has been deleted successfully'))->success();
        } else {
            flash(translate('Something went wrong'))->error();
        }
        return back();
    }

    public function order_details(Request $request)
    {
        $order = Order::findOrFail($request->order_id);
        //$order->viewed = 1;
        $order->save();
        return view('frontend.partials.order_details_seller', compact('order'));
    }

    public function update_tracking_status(Request $request)
    {
        $order = Order::findOrFail($request->order_id);

        if ($request->tracking_no) {
            $order->tracking_no = $request->tracking_no;
        }
        if ($request->start_date_rng) {

            $order->delivery_date1 = strtotime($request->start_date_rng);
        }
        if ($request->end_date_rng) {
            $order->delivery_date2 = strtotime($request->end_date_rng);
        }
        if ($request->delivery_by) {
            $order->delivery_by = $request->delivery_by;
        }
        $order->save();

        $this->update_delivery_status($request);
        return 1;
    }

    public function update_delivery_status($request)
    {
        $order = Order::findOrFail($request->order_id);

        $order->delivery_viewed = '0';

        $order->save();

        if (Auth::user()->user_type == 'admin' || Auth::user()->user_type == 'seller') {


            if (Auth::user()->user_type == 'admin') {
                if ($request->status == 'on_review') {
                    if($order->payment_type == "cash_on_delivery")
                    {
                       $this->apiDataToWeAreFulfillment($order->id);
                    }
                    
                }
                foreach ($order->orderDetails as $key => $orderDetail) {
                    $orderDetail->delivery_status = $request->status;
                    Log::info('status update: ' . $request->status);
                    $orderDetail->save();

                    if ($request->status == 'on_review') {
                        $status = 'Confirmed';
                        $content = ' ';
                    } elseif ($request->status == 'on_delivery') {
                        $status = 'Dispatched';
                        $content = '';
                    } elseif ($request->status == 'ready_to_collect') {
                        $status = 'Ready for collection';
                        $content = 'Please visit our warehouse.';
                    } elseif ($request->status == 'delivered') {
                        $status = 'Delivered';
                        $content = '';
                    } elseif ($request->status == 'shipment_reminder') {
                        $status = 'Reminder';
                        $array['reminder'] = 'Our courier service tried to contact your number, you were not responding. Our delivery company will contact you to arrange re-delivery, the order may get cancelled if you did not response.';
                    } elseif ($request->status == 'cancelled') {
                        $status = 'Cancelled';
                        $content = '';
                    } else {
                        $status = 'Pending';
                        $content = '';
                    }
                    $array['code'] = $order->code;

                    $array['order'] = $order;
                    $array['status'] = $status;
                    // dd($array['order']);
                    $array['order_details'] = $order->orderDetails;
                    $array['view'] = 'emails.invoice';
                    $array['subject'] = 'Order ' . $status . ' - ' . 'Berry Building Materials';
                    $array['from'] = env('MAIL_USERNAME');
                    if ($request->status == 'shipment_reminder') {
                        $array['content'] = '';
                    } else {

                        if ($request->status == 'ready_to_collect') {
                            $text = ' is ';
                        } else {
                            $text = ' has been ';
                        }
                        $array['content'] = translate('We wanted to let you know that your  order (' . $order->code . ') ' . $text . $status . ' ' . $content);
                    }
                }
            } else {

                foreach ($order->orderDetails->where('seller_id', Auth::user()->id) as $key => $orderDetail) {
                    $orderDetail->delivery_status = $request->status;
                    Log::info('status update: ' . $request->status);
                    $orderDetail->save();

                    if ($request->status == 'on_review') {
                        $status = 'Confirmed';
                        $content = ' ';
                    } elseif ($request->status == 'on_delivery') {
                        $status = 'Dispatched';
                        $content = '';
                    } elseif ($request->status == 'delivered') {
                        $status = 'Delivered';
                        $content = '';
                    } elseif ($request->status == 'shipment_reminder') {
                        $status = 'Reminder';
                        $array['reminder'] = 'Our courier service tried to contact your number, you were not responding. Our delivery company will contact you to arrange re-delivery, the order may get cancelled if you did not response.';
                    } else {
                        $status = 'Pending';
                        $content = '';
                    }
                    $array['code'] = $order->code;

                    $array['order'] = $order;
                    $array['status'] = $status;
                    // dd($array['order']);
                    $array['order_details'] = $order->orderDetails;
                    $array['view'] = 'emails.invoice';
                    $array['subject'] = 'Order ' . $status . ' - ' . 'Berry';
                    $array['from'] = env('MAIL_USERNAME');
                    if ($request->status == 'shipment_reminder') {
                        $array['content'] = '';
                    } else {
                        $array['content'] = translate('We wanted to let you know that your  order (' . $order->code . ') has been ' . $status . ' ' . $content);
                    }
                }
            }

            try {
                Log::info('trying');
                if (is_null($order->user_id)) {

                    $email = json_decode($order->shipping_address)->email;
                    $email_info = env('EMAIL_INFO');
                    $email_it = env('EMAIL_IT');
                    $email_more = env('EMAIL_MORE');
                    $emai_marktng = env('EMAIL_MARKETING');
                    $email_alternate = env('EMAIL_ALTERNATE');
                    $send_to = [$email];
                    $bcc = [$email_it, $email_more, $emai_marktng,$email_alternate];
                                    Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));

           
                    Log::info('mail send');
                } else {
                    $email = \App\User::find($order->user_id)->email;
                    $email_info = env('EMAIL_INFO');
                    $email_it = env('EMAIL_IT');
                    $email_more = env('EMAIL_MORE');
                    $emai_marktng = env('EMAIL_MARKETING');
                     $email_alternate = env('EMAIL_ALTERNATE');
                    $send_to = [$email];
                    $bcc = [$email_it, $email_more, $emai_marktng,$email_alternate];
                                    Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));

                  

                    Log::info('mail send');
                }

                if ($request->status == 'on_delivery') {
                    $message_to = 'Dear Customer, your  order (' . $order->code . ') has been Shipped.You will receive your order between ' . date('D j, M Y', $order->delivery_date1) . ' to ' . date('D j, M Y', $order->delivery_date2) . '.';
                    $phone = json_decode($order->shipping_address)->phone;
                    $explode = explode(',', $phone);
                    if($order->country_id == '230')
                                {
                                    try{
                                        $this->send_message($explode[0],$message_to);
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                    }
                                    
                                }
                    // $this->send_message($explode[0], $message_to);
                }
                if ($request->status == 'delivered') {
                    if (!empty($order->user_id)) {
                        $message_to = 'Dear Customer, your order (' . $order->code . ') has been Delivered. Thank you for choosing us:) ';
                    } else {
                        $message_to = 'Dear Customer, your order (' . $order->code . ') has been Delivered. Thank you for choosing us:) ';
                    }
                    $phone = json_decode($order->shipping_address)->phone;
                    $explode = explode(',', $phone);
                    if($order->country_id == '230')
                                {
                                    try{
                                        $this->send_message($explode[0],$message_to);
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                    }
                                    
                                }
                    // $this->send_message($explode[0], $message_to);
                    $satisfaction = 'Your satisfaction is highly important for us. Please spare 1 minute of your time to complete a survey to improve our service. https://tinyurl.com/7yryn7ys';
                        if($order->country_id == '230')
                        {
                            try{
                                        $this->send_message($explode[0],$satisfaction);
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                    }
                            
                        }
                        // $this->send_message($explode[0], $satisfaction);
                }
                if ($request->status == 'cancelled') {
                    $message_to = 'Dear Customer, your  order (' . $order->code . ') was cancelled. For assistance, call at 043556665 or send us e-mail on Sales@Birigroup.co.uk';
                    $phone = json_decode($order->shipping_address)->phone;
                    $explode = explode(',', $phone);
                    if($order->country_id == '230')
                                {
                                    try{
                                        $this->send_message($explode[0],$message_to);
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                    }
                                    
                                }
                    // $this->send_message($explode[0], $message_to);
                }
            } catch (\Exception $e) {
                Log::info('exception');
                Log::info($e);
            }
        } else {

            foreach ($order->orderDetails->where('seller_id', \App\User::where('user_type', 'admin')->first()->id) as $key => $orderDetail) {
                $orderDetail->delivery_status = $request->status;
                $orderDetail->save();
            }
        }

        if (\App\Addon::where('unique_identifier', 'otp_system')->first() != null && \App\Addon::where('unique_identifier', 'otp_system')->first()->activated && \App\OtpConfiguration::where('type', 'otp_for_delivery_status')->first()->value) {
            try {
                $otpController = new OTPVerificationController;
                $otpController->send_delivery_status($order);
            } catch (\Exception $e) {
            }
        }

        return 1;
    }

    public function update_payment_status(Request $request)
    {
        $order = Order::findOrFail($request->order_id);
        $order->payment_status_viewed = '0';
        $order->save();

        if (Auth::user()->user_type == 'admin' || Auth::user()->user_type == 'seller') {
            if (Auth::user()->user_type == 'admin') {
                foreach ($order->orderDetails as $key => $orderDetail) {
                    $orderDetail->payment_status = $request->status;
                    $orderDetail->save();
                }
            } else {
                foreach ($order->orderDetails->where('seller_id', Auth::user()->id) as $key => $orderDetail) {
                    $orderDetail->payment_status = $request->status;
                    $orderDetail->save();
                }
            }
        } else {
            foreach ($order->orderDetails->where('seller_id', \App\User::where('user_type', 'admin')->first()->id) as $key => $orderDetail) {
                $orderDetail->payment_status = $request->status;
                $orderDetail->save();
            }
        }

        $status = 'paid';
        foreach ($order->orderDetails as $key => $orderDetail) {
            if ($orderDetail->payment_status != 'paid') {
                $status = 'unpaid';
            }
        }
        $order->payment_status = $status;
        $order->save();

        if($order->payment_status == 'paid')
        {

        }

        if ($order->payment_status == 'paid' && $order->commission_calculated == 0) {
            if (\App\Addon::where('unique_identifier', 'seller_subscription')->first() == null || !\App\Addon::where('unique_identifier', 'seller_subscription')->first()->activated) {
                if ($order->payment_type == 'cash_on_delivery') {
                    if (BusinessSetting::where('type', 'category_wise_commission')->first()->value != 1) {
                        $commission_percentage = BusinessSetting::where('type', 'vendor_commission')->first()->value;
                        foreach ($order->orderDetails as $key => $orderDetail) {
                            $orderDetail->payment_status = 'paid';
                            $orderDetail->save();
                            if ($orderDetail->product->user->user_type == 'seller') {
                                $seller = $orderDetail->product->user->seller;
                                $seller->admin_to_pay = $seller->admin_to_pay - ($orderDetail->price * $commission_percentage) / 100;
                                $seller->save();
                            }
                        }
                    } else {
                        foreach ($order->orderDetails as $key => $orderDetail) {
                            $orderDetail->payment_status = 'paid';
                            $orderDetail->save();
                            if ($orderDetail->product->user->user_type == 'seller') {
                                $commission_percentage = $orderDetail->product->category->commision_rate;
                                $seller = $orderDetail->product->user->seller;
                                $seller->admin_to_pay = $seller->admin_to_pay - ($orderDetail->price * $commission_percentage) / 100;
                                $seller->save();
                            }
                        }
                    }
                } elseif ($order->manual_payment) {
                    if (BusinessSetting::where('type', 'category_wise_commission')->first()->value != 1) {
                        $commission_percentage = BusinessSetting::where('type', 'vendor_commission')->first()->value;
                        foreach ($order->orderDetails as $key => $orderDetail) {
                            $orderDetail->payment_status = 'paid';
                            $orderDetail->save();
                            if ($orderDetail->product->user->user_type == 'seller') {
                                $seller = $orderDetail->product->user->seller;
                                $seller->admin_to_pay = $seller->admin_to_pay + ($orderDetail->price * (100 - $commission_percentage)) / 100;
                                $seller->save();
                            }
                        }
                    } else {
                        foreach ($order->orderDetails as $key => $orderDetail) {
                            $orderDetail->payment_status = 'paid';
                            $orderDetail->save();
                            if ($orderDetail->product->user->user_type == 'seller') {
                                $commission_percentage = $orderDetail->product->category->commision_rate;
                                $seller = $orderDetail->product->user->seller;
                                $seller->admin_to_pay = $seller->admin_to_pay + ($orderDetail->price * (100 - $commission_percentage)) / 100;
                                $seller->save();
                            }
                        }
                    }
                }
            }

            if (\App\Addon::where('unique_identifier', 'affiliate_system')->first() != null && \App\Addon::where('unique_identifier', 'affiliate_system')->first()->activated) {
                $affiliateController = new AffiliateController;
                $affiliateController->processAffiliatePoints($order);
            }

            if (\App\Addon::where('unique_identifier', 'club_point')->first() != null && \App\Addon::where('unique_identifier', 'club_point')->first()->activated) {
                $clubpointController = new ClubPointController;
                $clubpointController->processClubPoints($order);
            }

            $order->commission_calculated = 1;
            $order->save();
        }

        if (\App\Addon::where('unique_identifier', 'otp_system')->first() != null && \App\Addon::where('unique_identifier', 'otp_system')->first()->activated && \App\OtpConfiguration::where('type', 'otp_for_paid_status')->first()->value) {
            try {
                $otpController = new OTPVerificationController;
                $otpController->send_payment_status($order);
            } catch (\Exception $e) {
            }
        }
        return 1;
    }


    public function updatePosSell($request)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "http://127.0.0.1:8000/sales-update-website",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "Content-type: application/json",

            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            //echo "cURL Error #:" . $err;

            // return $err;
        } else {
            //pre_list($response);
            return $response;
        }
    }

    public function send_message($to, $text)
    {
        try {
            $to = trim($to);
            $to = str_replace(" ", "", $to);
            $check = substr($to, 0, 4);
            if ($check == '+971') {
                $to = substr_replace($to, "", 0, 4);
            }
            $check = substr($to, 0, 3);
            if ($check == '971') {
                $to = substr_replace($to, "", 0, 3);
            }
            $check = substr($to, 0, 1);
            if ($check == '0') {
                $to = substr_replace($to, "", 0, 1);
            }
            $to = '971' . $to;

            $start_msg = 'Dear Customer, This is a test';

            $foot = ',from Berry Building Materials localhost.';
            Log::info('Send Number--: '.$to);
            Credentials::set('24baa0b710c713e63af5edab75f5c739', '18f761b425b750ba1831bdeb4a2183ac');
            $send_message = new Sms();
            try{
                                      
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                        return 'false';
                                    }
            
            return 'true';
        } catch (\Exception $e) {
            return 'false';
        }
    }

    public function apiDataToWeAreFulfillment($order_id){

        $order = Order::where('id',$order_id)->first();
        $orderDetails = OrderDetail::where('order_id',$order->id)->get();
       
        // $product_det = array();
        $item = collect();
        $total = 0;
        $total_gift_wrapper = 0;
        $total_discount = 0;
        $arr = array();
        foreach($orderDetails as $key => $orderDetail)
        {
            $product = \App\Product::where('id',$orderDetail->product_id)->first();
            if($orderDetail->price != 0)
            {
               
                $discount =  ($product->unit_price - ($orderDetail->price/$orderDetail->quantity));
                $unit_price = (($orderDetail->price/$orderDetail->quantity) );
            }
            else{
             
                $discount =  0;
                $unit_price = '0';
            }
        
            $product_det_main = [
                            'SKU' => $product->sku,
                            'Quantity' => $orderDetail->quantity,
                            'name' => $product->name,
                            'UnitPrice' => $unit_price,
                            
                            ];

            // $arr = $arr,$product_det_main;  
            array_push($arr,$product_det_main);               
            // $item->put($key+1 , $product_det_main);
        }
        // dd($arr);
        $name = json_decode($order->shipping_address)->name;
        $email = json_decode($order->shipping_address)->email;
        $abc = [
            'OrderItems' => $arr,
            "OrderNumber"=> $order->code,
            "FirstName"=> json_decode($order->shipping_address)->name,            
            "Address1"=> json_decode($order->shipping_address)->address,
            "PostCode"=> json_decode($order->shipping_address)->postcode,
            "Country"=> json_decode($order->shipping_address)->country,
            "Email"=>json_decode($order->shipping_address)->email,
            "Mobile"=> json_decode($order->shipping_address)->phone,
            "WarehouseId" => 8,
            "CourierServiceId" => 664,

        ];

        // dd(json_encode($abc));
        $api_key = '2a526c5a-ca87-4873-9915-d4752c06779e';
        $curl = curl_init();
        $url="https://api.mintsoft.co.uk/api/Order?APIKey=2a526c5a-ca87-4873-9915-d4752c06779e";
        // dd($url);
        curl_setopt_array($curl, array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_TIMEOUT => 30000,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'PUT',
          CURLOPT_POSTFIELDS => json_encode($abc),
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "Accept: application/json",
            
           
          ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        
        curl_close($curl);
        
        if ($err) {
          //echo "cURL Error #:" . $err;
            $res=$err;
        } else {
          $res= json_decode($response, true);
          Log::info(json_encode($res));
        } 

    }




    public function cleanData(&$str)
    {
        $str = preg_replace("/\t/", "\\t", $str);
        $str = preg_replace("/\r?\n/", "\\n", $str);
        if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
    }

    

    public function export_unpaidorders(Request $request)
    {
       

        // filename for download
        $filename = "Unpaid_order_" . date('Ymd') . ".xls";
        
       header("Content-Disposition: attachment; filename=\"$filename\"");
         header("Content-Type: application/vnd.ms-xls");
        
        
     
       
        
     $orderss = order::where('payment_status','unpaid')->latest()->get();
      
      
         $details = array();
        foreach($orderss as $key => $order)
       {
       $shipping_cost=$order->shipping_cost;
       $shipping_Vat=$order->shipping_cost*0.20;
       $total_vat= (($order->grand_total)-($shipping_cost+$shipping_Vat))*0.20;
       $net_total= ($total_vat/0.24);
       $net_total_vat=(($order->grand_total)-($shipping_cost+$shipping_Vat))- $net_total;
       $all_adress= $order->shipping_address;
      


       $all_adress1 = explode(',',$all_adress);
        
       $Name = explode(':',$all_adress1[0]);
       $Name1=$Name[1];
       $Email = explode(':',$all_adress1[1]);
       $Email1=$Email[1];



          $details[$key]['OrderCode'] = $order->code;
          $details[$key]['payment type'] = $order->payment_type;
          $details[$key]['Order Statue Date'] = date($order->updated_at);
          $details[$key]['Customer name'] =$Name1;
          $details[$key]['Cutomer Email'] =$Email1;
          $details[$key]['total net'] =$net_total;
          $details[$key]['total vat'] =$net_total_vat;
          $details[$key]['shipping cost'] = $order->shipping_cost;
          $details[$key]['shipping Vat'] = $shipping_Vat;
          $details[$key]['grand_total'] = $order->grand_total;
        //   $details[$key]['OrderCode'] = $order->code;
        //   $details[$key]['OrderCode'] = $order->code;
        //   $details[$key]['OrderCode'] = $order->code;
          
          
   } 
     
     
        $flag = false;
        foreach($details as $row) {
            if(!$flag) {
              // display field/column names as first row
              echo implode("\t", array_keys($row)) . "\r\n";
              $flag = true;
            }
            array_walk($row, 'self::cleanData');
            echo implode("\t", array_values($row)) . "\r\n";
          }
          


         
          exit;
    }






  
    public function export_orders(Request $request)
    {
       

        // filename for download
        $filename = "order_sales_data_" . date('Ymd') . ".xls";
        
       header("Content-Disposition: attachment; filename=\"$filename\"");
         header("Content-Type: application/vnd.ms-xls");
        
        
     
       
        
     $orderss = order::where('payment_status','paid')->latest()->get();
      
      
         $details = array();
        foreach($orderss as $key => $order)
       {
      
        
           $order_id=$order->id;
             



            $pro_skus ='';
              $pro_qtys='';
                foreach ($order->orderDetails->where('order_id', $order_id) as $key2 => $orderDetail)
            {
                            if($key2==0)
                            {
                                $product_SKU = $orderDetail->product->sku;
                                $pro_skus .= $product_SKU ;
            
                                
                             
                                $product_QTY = $orderDetail->quantity;
                                $pro_qtys.= $product_QTY;

                            }else{
                                $product_SKU = $orderDetail->product->sku;
                                $pro_skus .=', '. $product_SKU;
            
                                
                             
                                $product_QTY = $orderDetail->quantity;
                                $pro_qtys.=', '. $product_QTY ;
                            }
            

            }
          
                       






                    $shipping_cost=$order->shipping_cost;
                    $shipping_Vat=$order->shipping_cost*0.20;
                    $total_vat= (($order->grand_total)-($shipping_cost+$shipping_Vat))*0.20;
                    $net_total= ($total_vat/0.24);
                    $net_total_vat=(($order->grand_total)-($shipping_cost+$shipping_Vat))- $net_total;
                   // $all_adress= $order->shipping_address;
                    $DEPATURE_CITY= 'London';
                    $DEPARTURE_COUNTRY='GB';
                    $DEPARTURE_POST_CODE='NG17 7RB';
                    $TRANSACTION_CURRENCY_CODE='GB';
                    $ARRIVAL_COUNTRY='GB';
                    $SALE_DEPART_COUNTRY='GB';
                    $SALE_ARRIVAL_COUNTRY='GB';
                   // $all_adress1 = explode(',',$all_adress);
                        
                    $Name1= json_decode($order->shipping_address)->name;
                    
                    $Email1 =json_decode($order->shipping_address)->email;
                     $ARRIVAL_POST_CODE2 =json_decode($order->shipping_address)->postcode;
                    
                     $ARRIVAL_CITY1= json_decode($order->shipping_address)->address;
                     
                    
                    
                    $payment_type_cond=$order->payment_type;
                    if($payment_type_cond=='cash_on_delivery')
                    {
                        $payment_type='Bank_Transfer';
                    }else{
                        $payment_type='Stripe';
                    }


                        $details[$key]['TRANSACTION_EVENT_ID'] = $order->code;
                        $details[$key]['MARKETPLACE'] = 'https://birigroup.co.uk/';
                        $details[$key]['PAYMENT_TYPE'] = $payment_type;
                        $details[$key]['ORDER_STATUE_DATE'] = date($order->updated_at);
                        $details[$key]['CUSTOMER_NAME'] =$Name1;
                        $details[$key]['CUSTOMER_EMAIL'] =$Email1;
                        $details[$key]['SELLER_SKU'] =  $pro_skus;
                         $details[$key]['QTY'] =$pro_qtys;
                        
                        $details[$key]['TOTAL_NET'] =$net_total;
                        $details[$key]['TOTAL_VAT'] =$net_total_vat;
                        $details[$key]['Shopping_Cost'] = $order->shipping_cost;
                        $details[$key]['SHIPPING_VAT'] = $shipping_Vat;
                        $details[$key]['GRAND_TOTAL'] = $order->grand_total;

                        $details[$key]['TRANSACTION_CURRENCY_CODE'] = $TRANSACTION_CURRENCY_CODE;
                        $details[$key]['DEPATURE_CITY'] = $DEPATURE_CITY;
                        $details[$key]['DEPARTURE_COUNTRY'] = $DEPARTURE_COUNTRY;
                        $details[$key]['DEPARTURE_POST_CODE'] = $DEPARTURE_POST_CODE;
                        $details[$key]['ARRIVAL_CITY'] = $ARRIVAL_CITY1;
                        $details[$key]['ARRIVAL_COUNTRY'] = $ARRIVAL_COUNTRY;
                        $details[$key]['ARRIVAL_POST_CODE'] = $ARRIVAL_POST_CODE2;
                        $details[$key]['SALE_DEPART_COUNTRY'] = $SALE_DEPART_COUNTRY;
                        $details[$key]['SALE_ARRIVAL_COUNTRY'] = $SALE_ARRIVAL_COUNTRY;
                        
                        
                        //   $details[$key]['OrderCode'] = $order->code;
                        //   $details[$key]['OrderCode'] = $order->code;
                        //   $details[$key]['OrderCode'] = $order->code;
       
     } 
    //  dd($details);
     
        $flag = false;
        foreach($details as $row) {
            if(!$flag) {
              // display field/column names as first row
              echo implode("\t", array_keys($row)) . "\r\n";
              $flag = true;
            }
            array_walk($row, 'self::cleanData');
            echo implode("\t", array_values($row)) . "\r\n";
          }
          


         
          exit;
}





}
