<?php

namespace App\Http\Controllers;

use App\Redirection;
use Illuminate\Http\Request;
use App\SeoSetting;
use Illuminate\Support\Facades\Log;

class SEOController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $seosetting = SeoSetting::first();
        return view('seo_settings.index', compact("seosetting"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

        return view('seo_settings.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $seosetting_check = SeoSetting::where('page_name',$request->page_name)->first();
        if($seosetting_check)
        {
            flash(translate('Page name exist'))->error();
            return back();
        }
        $seosetting = new SeoSetting;
        $seosetting->keyword = implode('|',$request->tags);
        $seosetting->page_name = $request->page_name;
        $seosetting->title = $request->title;
        $seosetting->author = $request->author;
        $seosetting->revisit = $request->revisit;
        $seosetting->sitemap_link = $request->sitemap;
        $seosetting->description = $request->description;
        $seosetting->g_name = $request->g_name;
        $seosetting->g_description = $request->g_description;
        $seosetting->t_card = $request->t_card;
        $seosetting->t_title = $request->t_title;
        $seosetting->t_description = $request->t_description;
        $seosetting->og_title = $request->og_title;
        $seosetting->og_description = $request->og_description;
        $seosetting->og_type = $request->og_type;
        $seosetting->og_url = $request->og_url;
        $seosetting->og_site_name = $request->og_site_name;
        $seosetting->dc_title = $request->dc_title;
        $seosetting->dc_description = $request->dc_description;
        $seosetting->dc_subject = $request->dc_subject;
        $seosetting->dc_creator = $request->dc_creator;
        $seosetting->dc_type = $request->dc_type;
        $seosetting->dc_type_image = $request->dc_type_image;
        $seosetting->dc_language = $request->dc_language;
        $seosetting->dc_format = $request->dc_format;

        if($seosetting->save()){
            flash(translate('SEO Setting has been updated successfully'))->success();
            return redirect()->route('seosetting.index');
        }
        else{
            flash(translate('Something went wrong'))->error();
            return back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        
        $seosetting = SeoSetting::where('id',decrypt($id))->first();
        return view('seo_settings.index', compact("seosetting"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

		$new_page_name=$request->page_name_edit;

		
       $seosetting = SeoSetting::where('page_name',$request->page_name)->first();
        $seosetting->keyword = implode('|',$request->tags);
        $seosetting->page_name =$new_page_name;
        $seosetting->title = $request->title;
        $seosetting->author = $request->author;
        $seosetting->revisit = $request->revisit;
        $seosetting->sitemap_link = $request->sitemap;
        $seosetting->description = $request->description;
        $seosetting->g_name = $request->g_name;
        $seosetting->g_description = $request->g_description;
        $seosetting->t_card = $request->t_card;
        $seosetting->t_title = $request->t_title;
        $seosetting->t_description = $request->t_description;
        $seosetting->og_title = $request->og_title;
        $seosetting->og_description = $request->og_description;
        $seosetting->og_type = $request->og_type;
        $seosetting->og_url = $request->og_url;
        $seosetting->og_site_name = $request->og_site_name;
        $seosetting->dc_title = $request->dc_title;
        $seosetting->dc_description = $request->dc_description;
        $seosetting->dc_subject = $request->dc_subject;
        $seosetting->dc_creator = $request->dc_creator;
        $seosetting->dc_type = $request->dc_type;
        $seosetting->dc_type_image = $request->dc_type_image;
        $seosetting->dc_language = $request->dc_language;
        $seosetting->dc_format = $request->dc_format;

        if($seosetting->save()){
            flash(translate('SEO Setting has been updated successfully'))->success();
            return redirect()->route('seosetting.index');
        }
        else{
            flash(translate('Something went wrong'))->error();
            return back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function rediretionView()
    {

        $redirections = Redirection::all();
        return view('seo_settings.redirection.index',compact('redirections'));
    }

    public function rediretionUpdate(Request $request)
    {


        
        if($request->has('old_url'))
        {
            
            foreach($request->old_url as $key => $old_url)
            {
                
               
                    Log::info($key);
                    $redirection = Redirection::where('id',$key)->first();
                    
                    if($redirection)
                    {
                        
                        
                        $redirection->old_url = $old_url;
                        $redirection->save();

                        
                    }
                
            }
            flash(translate('301 Redirection has been updated successfully'))->success();
            return redirect()->back();
        }
        
    }

    public function rediretionCreate()
    {
        return view('seo_settings.redirection.create');
    }

    public function rediretionStore(Request $request)
    {
       

        $redirection_name = Redirection::where('page_name',$request->name)->first();
        $redirection_old_url = Redirection::where('old_url',$request->old_url)->first();
        if($redirection_name)
        {
            flash(translate('Page name already exist'))->error();
            return redirect()->back();
        }
        if($redirection_old_url)
        {
            flash(translate('Old Url already exist'))->error();
            return redirect()->back();
        }

        $redirection = new Redirection;
        $redirection->page_name = $request->name;
        $redirection->old_url = $request->old_url;
        $redirection->new_url = $request->new_url;
        $redirection->save();
        flash(translate('Page added Succesfully'))->success();
        return redirect()->back();


    }

    public function rediretionDelete($id)
    {
       
        Redirection::where('id', $id)->delete();
        flash(translate('Deleted Succesfully'))->success();
        return redirect()->back();
    }

}
