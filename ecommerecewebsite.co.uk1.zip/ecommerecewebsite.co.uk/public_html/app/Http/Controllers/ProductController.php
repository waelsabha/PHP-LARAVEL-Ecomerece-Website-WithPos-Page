<?php

namespace App\Http\Controllers;

use App\CartList;
use App\CartDetail;
use Illuminate\Http\Request;
use App\Product;
use App\ProductStock;
use App\ProductExtra;

use App\Category;
use App\Language;
use App\ProductMetadata;
use Auth;
use App\SubCategory;
use App\SubSubCategory;
use App\FreeProduct;
use App\HomePageShow;
use App\StockNotification;
use App\User;
use Session;
use ImageOptimizer;
use DB;
use CoreComponentRepository;

use Mail;
use App\Mail\InvoiceEmailManager;
use App\Models\SeoSetting;
use App\Post;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use SimpleXMLElement;

use SMSGlobal\Credentials;
use SMSGlobal\Resource\Sms;
use Symfony\Component\Console\Input\Input;
use App\Utility\verifyEmail;

use App\Utility\SMTP_validateEmail;

class ProductController extends Controller
{

    public function __construct()
    {
        //
        update_all_stock_from_pos();
        // update_cartDb_to_cartSession();
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function admin_products(Request $request)
    {
        //CoreComponentRepository::instantiateShopRepository();
        
        $type = 'In House';
        $col_name = null;
        $query = null;
        $sort_search = null;
        $cat_id = null;

        $paginate = 'paginate';
        $pagination_no = 50;
        

        $products = Product::where('added_by', 'admin');
        // dd($request);
        // if()
        if($request->paginate)
        {
            // $type = 'In House';
            $var = explode(",", $request->paginate);
            
            $pagination_no = $var[1];
           
            
        }


        if ($request->type != null){
            $var = explode(",", $request->type);
            $col_name = $var[0];
            $query = $var[1];
            if($col_name == 'category')
            {
                $products = $products->where($col_name.'_id', $query);
            }
            else if($col_name == 'published')
            {
                $products = $products->where($col_name, $query);
            }
            else if($col_name == 'home_page_show')
            {
                
                if(isset($var[2]) && $query != 7)
                {
                   
                    $cat_id = $var[2];
                    $products = $products->where($col_name, 'like', '%'.$query.'%')->where('category_id',$var[2]);
                   
                }
                else
                {
                    if($query != 7)
                    {
                        $products = $products->where($col_name, 'like', '%'.$query.'%');
                    }
                    
                }

                if($query == 7)
                {
                    $cat_id = $var[2];
                    
                    $products = $products->where($col_name, 'like', '%'.$var[2].'%');
                    // dd($products);
                }
                
            }
            else if($col_name == 'subsubcategory_id')
            {
                
                if($query == 8)
                {
                    $cat_id = $var[2];
                    $products = $products->where($col_name, 'like', '%'.$var[2].'%');
                }
            }
            else if($col_name == 'featured')
            {
                $products = $products->where($col_name, 1);
            }
            else
            {   
                
                $products = $products->orderBy($col_name, $query);
            }
            
            $sort_type = $request->type;
        }
        
        if ($request->search != null){
            $products = $products
                        ->where('name', 'like', '%'.$request->search.'%')->orWhere('sku', 'LIKE', '%' .$request->search. '%');
            $sort_search = $request->search;
        }
       
        $products = $products->where('digital', 0)->orderBy('created_at', 'desc')->paginate($pagination_no);
        
        return view('products.index', compact('products','type', 'col_name', 'query', 'sort_search','cat_id'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function seller_products(Request $request)
    {
        $col_name = null;
        $query = null;
        $seller_id = null;
        $sort_search = null;
        $products = Product::where('added_by', 'seller');
        if ($request->has('user_id') && $request->user_id != null) {
            $products = $products->where('user_id', $request->user_id);
            $seller_id = $request->user_id;
        }
        if ($request->search != null){
            $products = $products
                        ->where('name', 'like', '%'.$request->search.'%');
            $sort_search = $request->search;
        }
        if ($request->type != null){
            $var = explode(",", $request->type);
            $col_name = $var[0];
            $query = $var[1];
            $products = $products->orderBy($col_name, $query);
            $sort_type = $request->type;
        }

        $products = $products->orderBy('created_at', 'desc')->paginate(15);
        $type = 'Seller';

        return view('products.index', compact('products','type', 'col_name', 'query', 'seller_id', 'sort_search'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        return view('products.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        
        $refund_request_addon = \App\Addon::where('unique_identifier', 'refund_request')->first();

        $product = new Product;
        $product->name = $request->name;
        $product->added_by = $request->added_by;
        if(Auth::user()->user_type == 'seller'){
            $product->user_id = Auth::user()->id;
        }
        else{
            $product->user_id = \App\User::where('user_type', 'admin')->first()->id;
        }
        $product->category_id = $request->category_id;

       
        $options_sub_cat = array();
        if($request->has('subcategory_id')){
            if(is_array($request->subcategory_id))
            {
                foreach ($request->subcategory_id as $key => $sub_cat) {
            
                    array_push($options_sub_cat, $sub_cat);
                    //ImageOptimizer::optimize(base_path('public/').$path);
                    }
            }
            
            // count($request->subcategory_id) > 0
            $product->subcategory_id = json_encode($request->subcategory_id);
        }
        
       
        // $product->subcategory_id = $request->subcategory_id;

        $options_sub_sub_cat = array();
        // dd($request->subsubcategory_id);
        if($request->has('subsubcategory_id') ){
            if(is_array($request->subsubcategory_id))
            {
                foreach ($request->subsubcategory_id as $key => $sub_sub_cat) {
                
                array_push($options_sub_sub_cat, $sub_sub_cat);
                //ImageOptimizer::optimize(base_path('public/').$path);
                }
            }
            $product->subsubcategory_id = json_encode($request->subsubcategory_id);
        }

        // $product->subsubcategory_id = $request->subsubcategory_id;
        $product->brand_id = $request->brand_id;
        $product->current_stock = $request->current_stock;
        $product->barcode = $request->barcode;

        // dd($request->subcategory_id);

        if ($refund_request_addon != null && $refund_request_addon->activated == 1) {
            if ($request->refundable != null) {
                $product->refundable = 1;
            }
            else {
                $product->refundable = 0;
            }
        }

        $photos = array();

        if($request->hasFile('photos')){
            foreach ($request->photos as $key => $photo) {
                $path = $photo->store('uploads/products/photos');
                array_push($photos, $path);
                compressImage($path);
                //ImageOptimizer::optimize(base_path('public/').$path);
            }
            $product->photos = json_encode($photos);
        }

        if($request->hasFile('thumbnail_img')){

            $product->thumbnail_img = $request->thumbnail_img->store('uploads/products/thumbnail');
            compressImage($product->thumbnail_img);
            // dd($product->thumbnail_img);
            //ImageOptimizer::optimize(base_path('public/').$product->thumbnail_img);
        }

        

        if($request->has('home_show_id')){
                   
            $product->home_page_show = implode(',',$request->home_show_id);
        }

        $product->unit = $request->unit;
        $product->min_qty = $request->min_qty;
        $product->tags = implode('|',$request->tags);
        $product->description = $request->description;
        $product->arabic_description = $request->arabic_description;
        $product->short_description = $request->short_description;
        $product->video_provider = $request->video_provider;
        $product->video_link = $request->video_link;
        $product->unit_price = $request->unit_price;
        $product->purchase_price = $request->purchase_price;
        $product->tax = $request->tax;
        $product->tax_type = $request->tax_type;
        $product->discount = $request->discount;
        $product->discount_type = $request->discount_type;
        $product->shipping_type = $request->shipping_type;

        if ($request->has('shipping_type')) {
            if($request->shipping_type == 'free'){
                $product->shipping_cost = 0;
            }
            elseif ($request->shipping_type == 'flat_rate') {
                $product->shipping_cost = $request->flat_shipping_cost;
            }
        }
        $product->meta_title = $request->meta_title;
        $product->meta_description = $request->meta_description;

        if($request->hasFile('meta_img')){
            $product->meta_img = $request->meta_img->store('uploads/products/meta');
            compressImage($product->meta_img);
            //ImageOptimizer::optimize(base_path('public/').$product->meta_img);
        } else {
            $product->meta_img = $product->thumbnail_img;
            compressImage($product->meta_img);
        }

        $product->alt_img = $request->alt_img;

        if($product->meta_title == null) {
            $product->meta_title = $product->name;
        }

        if($product->meta_description == null) {
            $product->meta_description = $product->description;
        }

        if($request->hasFile('pdf')){
            $product->pdf = $request->pdf->store('uploads/products/pdf');
        }

        if($request->has('slug'))
        {
            $slug_check = Product::where('slug',$request->slug)->first();
            if($slug_check)
            {
                flash(translate('URL already exist'))->error();
                return redirect()->back();
            }
            

            $product->slug = $request->slug;
        }
        else
        {
            $product->slug = preg_replace('/[^A-Za-z0-9\-]/', '', str_replace(' ', '-', $request->name)).'-'.Str::random(5);

        }


        if($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
            $product->colors = json_encode($request->colors);
        }
        else {
            $colors = array();
            $product->colors = json_encode($colors);
        }

        $choice_options = array();
        
        if($request->has('choice_no')){
            foreach ($request->choice_no as $key => $no) {
                $str = 'choice_options_'.$no;

                $item['attribute_id'] = $no;
                $item['values'] = explode(',', implode('|', $request[$str]));

                array_push($choice_options, $item);
                
            }
        }

        if (!empty($request->choice_no)) {
            $product->attributes = json_encode($request->choice_no);
        }
        else {
            $product->attributes = json_encode(array());
        }

        $product->choice_options = json_encode($choice_options);
        // dd( $product->choice_options);
        //$variations = array();

        // dd($request);
        
        $product->save();

        $product_extra = new ProductExtra;
        if($request->package_length != null && $request->package_width != null && $request->package_hight != null)
        {
            $package_dimen = $request->package_length . ',' . $request->package_width . ',' . $request->package_hight;

        }else{
            $package_dimen = null;
        }
        if($request->product_length != null && $request->product_width != null && $request->product_hight != null)
        {
            $product_dimen = $request->product_length . ',' . $request->product_width . ',' .$request->product_hight;

        }else{
            $product_dimen = null;
        }
        if($request->has('battery'))
        {
            if($request->battery == 1)
            {
                $battery = 1;
                $battery_qty = $request->battery_quantity;
                $battery_type = $request->battery_type;
            }
            
        }
        else{
            $battery = 0;
            $battery_qty = null;
            $battery_type = null;  
        }

        $product_extra->product_id          = $product->id;
        $product_extra->material            = $request->product_material;
        $product_extra->battery             = $battery;
        $product_extra->battery_type        = $battery_type;
        $product_extra->battery_qty         = $battery_qty;
        $product_extra->product_dimention   = $product_dimen;
        $product_extra->package_dimention   = $package_dimen;
        $product_extra->age_for             = $request->min_age;
        $product_extra->country_of_origin   = $request->product_country;
        // $product_extra->product_warning     = $request->id;
        $product_extra->product_usage       = $request->product_usage;
        $product_extra->product_weight      = $request->weight;
        $product_extra->product_weight_unit = $request->weight_unit;
        $product_extra->package_include     = $request->package_includes;
        $product_extra->package_unit        = $request->package_unit;
        $product_extra->product_unit        = $request->product_unit;

        $product_extra->save();

        $meta_data = new ProductMetadata;

        $meta_data->product_id = $product->id;
        // dd($request->meta_title);
        $meta_data->m_title = $request->meta_title;
        $meta_data->m_mdesc = $request->meta_description;

        if($meta_data->m_title == null) {
            $meta_data->m_title = $product->name;
        }

        if($meta_data->m_mdesc == null) {
            $meta_data->m_mdesc = $product->description;
        }

        $meta_data->m_mkeywrd = $request->m_mkeywrd;
        $meta_data->m_robot = $request->m_robot;
        $meta_data->m_cpyrgt = $request->m_cpyrgt;
        $meta_data->m_dc_title = $request->m_dc_title;
        $meta_data->m_dc_desc = $request->m_dc_desc;
        $meta_data->m_dc_sub = $request->m_dc_sub;
        $meta_data->m_dc_crtor = $request->m_dc_crtor;
        $meta_data->m_dc_type = $request->m_dc_type;
        $meta_data->m_dc_type_img = $request->m_dc_type_img;
        $meta_data->m_dc_lang = $request->m_dc_lang;
        $meta_data->m_dc_format = $request->m_dc_format;
        $meta_data->save();

        
        $abc = view('invoices.rdf', compact('meta_data'))->render();
            
        Storage::disk('local')->put('rdf/prd_'. $product->id .'.rdf', $abc);

        //combinations start
        $options = array();
        if($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
            $colors_active = 1;
            array_push($options, $request->colors);
        }

        if($request->has('choice_no')){
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_'.$no;
                $my_str = implode('|',$request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }

        //Generates the combinations of customer choice options
        $combinations = combinations($options);
        if(count($combinations[0]) > 0){
            $product->variant_product = 1;
            foreach ($combinations as $key => $combination){
                $str = '';
                foreach ($combination as $key => $item){
                    if($key > 0 ){
                        $str .= '-'.str_replace(' ', '', $item);
                    }
                    else{
                        if($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
                            $color_name = \App\Color::where('code', $item)->first()->name;
                            $str .= $color_name;
                        }
                        else{
                            $str .= str_replace(' ', '', $item);
                        }
                    }
                }
                // $item = array();
                // $item['price'] = $request['price_'.str_replace('.', '_', $str)];
                // $item['sku'] = $request['sku_'.str_replace('.', '_', $str)];
                // $item['qty'] = $request['qty_'.str_replace('.', '_', $str)];
                // $variations[$str] = $item;

                $product_stock = ProductStock::where('product_id', $product->id)->where('variant', $str)->first();
                if($product_stock == null){
                    $product_stock = new ProductStock;
                    $product_stock->product_id = $product->id;
                }

                

                if($request->hasFile('variant_image-'.$str)){
                    
                        
                        // $product_stock->variant_image = $request['variant_image-'.str_replace('.', '-', $str)]->store('uploads/products/variations');
                        // Log::info($product_stock->variant_image);
                    
                        //ImageOptimizer::optimize(base_path('public/').$product->thumbnail_img);
                }


                $variant_photos = array();

                if($request->hasFile('variant_image-'.$str)){
                    
                    // dd($request->file('variant_image-'.$str));
                    foreach ($request->file('variant_image-'.$str) as $key => $var_photo) {
                        $path = $var_photo->store('uploads/products/variations');
                        array_push($variant_photos, $path);
                        //ImageOptimizer::optimize(base_path('public/').$path);
                    }
                    $product_stock->variant_image = json_encode($variant_photos);
                }

                // dd($product_stock->variant_image);

                 $product_stock->variant = $str;

                
               $product_stock->price = $request['price_'.str_replace('.', '_', $str)];
               $product_stock->sku = $request['sku_'.str_replace('.', '_', $str)];
               $product_stock->qty = $request['qty_'.str_replace('.', '_', $str)];
               $product_stock->alt_img = $request['alt_img_'.str_replace('.', '_', $str)];
               $product_stock->variant_description = $request['variant_description-'.str_replace('.', '-', $str)];
                // dd($product_stock->variant_description);
              $product_stock->save();

                
            }
        }
        //combinations end

        foreach (Language::all() as $key => $language) {
            $data = openJSONFile($language->code);
            $data[$product->name] = $product->name;
            saveJSONFile($language->code, $data);
        }

	    $product->save();

        flash(translate('Product has been inserted successfully'))->success();
        if(Auth::user()->user_type == 'admin' || Auth::user()->user_type == 'staff'){
            return redirect()->route('products.admin');
        }
        else{
            if(\App\Addon::where('unique_identifier', 'seller_subscription')->first() != null && \App\Addon::where('unique_identifier', 'seller_subscription')->first()->activated){
                $seller = Auth::user()->seller;
                $seller->remaining_uploads -= 1;
                $seller->save();
            }
            return redirect()->route('seller.products');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function admin_product_edit($id)
    {
        $product = Product::findOrFail(decrypt($id));
        $tags = json_decode($product->tags);
        $categories = Category::where('parent_id',0)->get();
        $sub_categories = SubCategory::all();
        $exp = explode(',', $product->subcategory_id);
        preg_match_all('!\d+!', $product->subcategory_id, $matches);
        $subcategory_ids = $matches;
        
        $product_lists = Product::where('category_id',$product->category_id)->get();
        $product_extra = ProductExtra::where('product_id',decrypt($id))->first();

        $meta_details = ProductMetadata::where('product_id',decrypt($id))->first();
        
        return view('products.edit', compact('product', 'categories','sub_categories','subcategory_ids', 'tags','product_extra','meta_details','product_lists'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function seller_product_edit($id)
    {
        $product = Product::findOrFail(decrypt($id));
        $tags = json_decode($product->tags);
        $categories = Category::where('parent_id',0)->get();

        $sub_categories = SubCategory::all();
        $sub_categories = SubCategory::all();
        $exp = explode(',', $product->subcategory_id);
        preg_match_all('!\d+!', $product->subcategory_id, $matches);
        $subcategory_ids = $matches;

        $product_extra = ProductExtra::where('product_id',decrypt($id))->first();

        $meta_details = ProductMetadata::where('product_id',decrypt($id))->first();

        return view('products.edit', compact('product', 'categories','sub_categories','subcategory_ids', 'tags','product_extra','meta_details'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        // dd($request);
        $refund_request_addon = \App\Addon::where('unique_identifier', 'refund_request')->first();

        $slug_check = Product::where('slug',$request->slug)->first();
        if($slug_check)
        {        
            if($slug_check->id != $id)
            {
                flash(translate('URL already exist'))->error();
                return redirect()->back();
            }
        }

        $product = Product::findOrFail($id);
        $product->name = $request->name;
        $product->category_id = $request->category_id;
        // dd($request);

        $options_sub_cat = array();
        if($request->has('subcategory_id') && count($request->subcategory_id) > 0){
            foreach ($request->subcategory_id as $key => $sub_cat) {
            
            array_push($options_sub_cat, $sub_cat);
            //ImageOptimizer::optimize(base_path('public/').$path);
            }
            
            $product->subcategory_id = json_encode($request->subcategory_id);
        }
        else{
            $product->subcategory_id = json_encode(array());
        }

        // $product->subcategory_id = $request->subcategory_id;
        
        $options_sub_sub_cat = array();
        if($request->has('subsubcategory_id') && count($request->subsubcategory_id) > 0){
            foreach ($request->subsubcategory_id as $key => $sub_sub_cat) {
            
            array_push($options_sub_sub_cat, $sub_sub_cat);
            //ImageOptimizer::optimize(base_path('public/').$path);
            }
            
            $product->subsubcategory_id = json_encode($request->subsubcategory_id);
        }
        else{
            $product->subsubcategory_id = json_encode(array());
        }
        // $product->subsubcategory_id = $request->subsubcategory_id;
        $product->brand_id = $request->brand_id;
        $product->current_stock = $request->current_stock;
        $product->barcode = $request->barcode;
        $product->similar_products_id = json_encode($request->similar_products_id);

        $similar_products_array = array();

        array_push($similar_products_array, strval($product->id));  
        // dd($request->similar_products_id);
        $new_array = array();
        if(!empty($request->similar_products_id)){
            foreach($request->similar_products_id as $sim_key => $similar_products){

                $get_this_product = Product::where('id',$similar_products)->first();
                if($get_this_product->similar_products_id != null && $get_this_product->similar_products_id != 'null')
                {
                    if(!empty(json_decode($get_this_product->similar_products_id)))
                    {
                        
                        $new_array = json_decode($get_this_product->similar_products_id);
                        if(in_array($product->id,$new_array))
                        {
                            $similar_products_array = array();
                        }
                    }
                }
                
                
                $res = array_merge( $new_array,$similar_products_array);   
                
                
                Product::where('id',$similar_products)->update(['similar_products_id'=>json_encode($res)]);            
                $similar_products_array =array();
                $new_array = array();
                array_push($similar_products_array, strval($product->id));
            }
        }

        if ($refund_request_addon != null && $refund_request_addon->activated == 1) {
            if ($request->refundable != null) {
                $product->refundable = 1;
            }
            else {
                $product->refundable = 0;
            }
        }
        $photos_main = array();
        if($request->has('previous_photos')){
           
            $photos = $request->previous_photos;
            foreach($photos as $keyph => $pht)
            {
                if($request->has('groupOfMaterialRadios'))
                {
                    if($request->groupOfMaterialRadios == $pht)
                    {
                        
                        $varible_unset = $keyph;
                        if($varible_unset != 0)
                        {
                            unset($photos[$varible_unset]);
                            $photos_main[0] = $pht;
                        }
                    }
                }
            }

            
        }
        else{
            $photos = array();
        }
        $photos = array_merge($photos_main,$photos);
        
        if($request->hasFile('photos')){
            foreach ($request->photos as $key => $photo) {
               
                $path = $photo->store('uploads/products/photos');
                array_push($photos, $path);
                compressImage($path);
                //ImageOptimizer::optimize(base_path('public/').$path);
            }
        }
        $product->photos = json_encode($photos);

        $product->thumbnail_img = $request->previous_thumbnail_img;
        if($request->hasFile('thumbnail_img')){
            $product->thumbnail_img = $request->thumbnail_img->store('uploads/products/thumbnail');
            compressImage($product->thumbnail_img);
            //ImageOptimizer::optimize(base_path('public/').$product->thumbnail_img);
        }
        
        if($request->has('home_show_id')){
                   
            $product->home_page_show = implode(',',$request->home_show_id);
        }
        // dd($request->discount);
        $product->unit = $request->unit;
        $product->min_qty = $request->min_qty;
        $product->tags = implode('|',$request->tags);
        $product->description = $request->description;
        $product->arabic_description = $request->arabic_description;
        $product->short_description = $request->short_description;
        $product->video_provider = $request->video_provider;
        $product->video_link = $request->video_link;
        $product->unit_price = $request->unit_price;
        $product->purchase_price = $request->purchase_price;
        $product->tax = $request->tax;
        $product->tax_type = $request->tax_type;
        $product->discount = $request->discount;
        $product->shipping_type = $request->shipping_type;
        if ($request->has('shipping_type')) {
            if($request->shipping_type == 'free'){
                $product->shipping_cost = 0;
            }
            elseif ($request->shipping_type == 'flat_rate') {
                $product->shipping_cost = $request->flat_shipping_cost;
            }
        }
        $product->discount_type = $request->discount_type;
        $product->meta_title = $request->meta_title;
        $product->meta_description = $request->meta_description;

        $product->meta_img = $request->previous_meta_img;
        if($request->hasFile('meta_img')){
            $product->meta_img = $request->meta_img->store('uploads/products/meta');
            compressImage($product->meta_img);
            //ImageOptimizer::optimize(base_path('public/').$product->meta_img);
        }

        $product->alt_img = $request->alt_img;

        if($product->meta_title == null) {
            $product->meta_title = $product->name;
        }

        if($product->meta_description == null) {
            $product->meta_description = $product->description;
        }

        if($request->hasFile('pdf')){
            $product->pdf = $request->pdf->store('uploads/products/pdf');
        }
        if($request->has('slug'))
        {
                      

            $product->slug = $request->slug;
        }

        // $product->slug = preg_replace('/[^A-Za-z0-9\-]/', '', str_replace(' ', '-', $request->name)).'-'.substr($product->slug, -5);

        if($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
            $product->colors = json_encode($request->colors);
            

        }
        else {
            $colors = array();
            $product->colors = json_encode($colors);
        }

        $choice_options = array();

        if($request->has('choice_no')){
            foreach ($request->choice_no as $key => $no) {
                $str = 'choice_options_'.$no;

                $item['attribute_id'] = $no;
                $item['values'] = explode(',', implode('|', $request[$str]));

                array_push($choice_options, $item);
            }
        }

        if($product->attributes != json_encode($request->choice_attributes)){
            foreach ($product->stocks as $key => $stock) {
                $stock->delete();
            }
        }
        
        if (!empty($request->choice_no)) {
            $product->attributes = json_encode($request->choice_no);
        }
        else {
            $product->attributes = json_encode(array());
        }

        $product->choice_options = json_encode($choice_options);

        foreach (Language::all() as $key => $language) {
            $data = openJSONFile($language->code);
            unset($data[$product->name]);
            $data[$request->name] = "";
            saveJSONFile($language->code, $data);
        }

        //combinations start
        $options = array();
        if($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
            $colors_active = 1;
            array_push($options, $request->colors);
        }

        if($request->has('choice_no')){
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_'.$no;
                $my_str = implode('|',$request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }
        $meta_data = ProductMetadata::where('product_id', $product->id)->first();
        // dd($meta_data);
        if($meta_data == null){
            $meta_data = new ProductMetadata;
            $meta_data->product_id = $product->id;
        }
       
        $meta_data->m_title = $request->meta_title;
        $meta_data->m_mdesc = $request->meta_description;

        if($meta_data->m_title == null) {
            $meta_data->m_title = $product->name;
        }

        if($meta_data->m_mdesc == null) {
            $meta_data->m_mdesc = $product->description;
        }

        $meta_data->m_mkeywrd = $request->m_mkeywrd;
        $meta_data->m_robot = $request->m_robot;
        $meta_data->m_cpyrgt = $request->m_cpyrgt;
        $meta_data->m_dc_title = $request->m_dc_title;
        $meta_data->m_dc_desc = $request->m_dc_desc;
        $meta_data->m_dc_sub = $request->m_dc_sub;
        $meta_data->m_dc_crtor = $request->m_dc_crtor;
        $meta_data->m_dc_type = $request->m_dc_type;
        $meta_data->m_dc_type_img = $request->m_dc_type_img;
        $meta_data->m_dc_lang = $request->m_dc_lang;
        $meta_data->m_dc_format = $request->m_dc_format;
        

        $abc = view('invoices.rdf', compact('meta_data'))->render();
            
        Storage::disk('local')->put('rdf/prd_'. $product->id .'.rdf', $abc);
        
        $combinations = combinations($options);
        if(count($combinations[0]) > 0){
            $product->variant_product = 1;
            foreach ($combinations as $key => $combination){
                $str = '';
                foreach ($combination as $key => $item){
                    if($key > 0 ){
                        $str .= str_replace(' ', '', $item);
                    }
                    else{
                        if($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
                            $color_name = \App\Color::where('code', $item)->first()->name;
                            $str .= $color_name;
                        }
                        else{
                            $str .=  str_replace(' ', '', $item);
                        }
                    }
                }
                //dd( $item);
                $product_stock = ProductStock::where('product_id', $product->id)->where('variant', $item)->first();
                // dd("product id: ".$product->id . "varient : " .$str );
                if($product_stock == null){
                    $product_stock = new ProductStock;
                    $product_stock->product_id = $product->id;
                }

                $product_stock->variant = $item;
               

                $abc = 'previous_variant_image-'.$str;
                
                $main_var_img = 'groupOfVariantRadios_'.$str;
                $var_photos_main =  array();
                // dd( $request->groupOfVariantRadios_girl);
               
                if($request->has('previous_variant_image-'.$str)){
                    $variant_photos = $request->$abc;

                    foreach($variant_photos as $keyph => $pht_var)
                    {
                        
                        if($request->has('groupOfVariantRadios_'.$str))
                        {
                            
                            if($request->$main_var_img == $pht_var)
                            {
                                // dd($pht_var);
                                $varible_unset = $keyph;
                                if($varible_unset != 0)
                                {
                                    unset($variant_photos[$varible_unset]);
                                    $var_photos_main[0] = $pht_var;
                                }
                            }
                        }
                    }
                }
                else{
                    $variant_photos = array();
                }
                
                $variant_photos = array_merge($var_photos_main,$variant_photos);
                // dd($variant_photos);
                if($request->hasFile('variant_image-'.$str)){
                   
                    $photo_varrr = 'variant_image-'.$str;
                    $ddd = $request->file($photo_varrr);
                    
                    foreach ($ddd as $key => $var_photo) {
                        // dd($var_photo);
                        $path = $var_photo->store('uploads/products/photos');
                        array_push($variant_photos, $path);
                        ImageOptimizer::optimize(base_path('public/').$path);
                        if($product->thumbnail_img == null){
                            $product->thumbnail_img = $path;
                        }
                    }
                }
                $product_stock->variant_image = json_encode($variant_photos);


         // dd($request);
         $product_stock->price = $request['price_'.str_replace('.', '_', $str)];
         $product_stock->sku = $request['sku_'.str_replace('.', '_', $str)];
         $product_stock->qty = $request['qty_'.str_replace('.', '_', $str)];
         $product_stock->alt_img = $request['alt_img_'.str_replace('.', '_', $str)];
         $product_stock->variant_description = $request['variant_description-'.str_replace('.', '-', $str)];
         // dd($product_stock->variant_description);
         $product_stock->save();
            }
        }

        $product->save();
        $meta_data->save();
        
        $product_extra = ProductExtra::where('product_id', $product->id)->first();
                //  dd($product->id);
                if($product_extra == null){
                    $product_extra = new ProductExtra;
                    $product_extra->product_id = $product->id;
                }
        if($request->package_length != null && $request->package_width != null && $request->package_hight != null)
        {
            $package_dimen = $request->package_length . ',' . $request->package_width . ',' . $request->package_hight;

        }else{
            $package_dimen = null;
        }

        
        if($request->product_length != null && $request->product_width != null && $request->product_hight != null)
        {
            $product_dimen = $request->product_length . ',' . $request->product_width . ',' .$request->product_hight;

        }else{
            $product_dimen = null;
        }
        // dd($product_dimen);
        if($request->has('battery'))
        {
            if($request->battery == 1)
            {
                $battery = 1;
                $battery_qty = $request->battery_quantity;
                $battery_type = $request->battery_type;
            }
            
        }
        else{
            $battery = 0;
            $battery_qty = null;
            $battery_type = null;  
        }

        
        $product_extra->material            = $request->product_material;
        $product_extra->battery             = $battery;
        $product_extra->battery_type        = $battery_type;
        $product_extra->battery_qty         = $battery_qty;
        $product_extra->product_dimention   = $product_dimen;
        $product_extra->package_dimention   = $package_dimen;
        $product_extra->age_for             = $request->min_age;
        $product_extra->country_of_origin   = $request->product_country;
        // $product_extra->product_warning     = $request->id;
        $product_extra->product_usage       = $request->product_usage;
        $product_extra->product_weight      = $request->weight;
        $product_extra->product_weight_unit = $request->weight_unit;
        $product_extra->package_include     = $request->package_includes;
        $product_extra->package_unit        = $request->package_unit;
        $product_extra->product_unit        = $request->product_unit;

        $product_extra->save();

        flash(translate('Product has been updated successfully'))->success();
        if(Auth::user()->user_type == 'admin' || Auth::user()->user_type == 'staff'){
            return redirect()->route('products.admin');
        }
        else{
            return redirect()->route('seller.products');
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        if(Product::destroy($id)){
            foreach (Language::all() as $key => $language) {
                $data = openJSONFile($language->code);
                unset($data[$product->name]);
                saveJSONFile($language->code, $data);
            }
            flash(translate('Product has been deleted successfully'))->success();
            if(Auth::user()->user_type == 'admin'){
                return redirect()->route('products.admin');
            }
            else{
                return redirect()->route('seller.products');
            }
        }
        else{
            flash(translate('Something went wrong'))->error();
            return back();
        }
    }

    /**
     * Duplicates the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function duplicate($id)
    {
        $product = Product::find($id);
        $product_new = $product->replicate();
        $product_new->slug = substr($product_new->slug, 0, -5).Str::random(5);

        if($product_new->save()){
            flash(translate('Product has been duplicated successfully'))->success();
            if(Auth::user()->user_type == 'admin' || Auth::user()->user_type == 'staff'){
                return redirect()->route('products.admin');
            }
            else{
                return redirect()->route('seller.products');
            }
        }
        else{
            flash(translate('Something went wrong'))->error();
            return back();
        }
    }

    public function get_products_by_subsubcategory(Request $request)
    {
        $products = Product::where('subsubcategory_id', $request->subsubcategory_id)->get();
        return $products;
    }

    public function get_products_by_brand(Request $request)
    {
        $products = Product::where('brand_id', $request->brand_id)->get();
        return view('partials.product_select', compact('products'));
    }

    public function updateTodaysDeal(Request $request)
    {
        $product = Product::findOrFail($request->id);
        $product->todays_deal = $request->status;
        if($product->save()){
            return 1;
        }
        return 0;
    }

    public function updatePublished(Request $request)
    {
        $product = Product::findOrFail($request->id);
        $product->published = $request->status;

        if($product->added_by == 'seller' && \App\Addon::where('unique_identifier', 'seller_subscription')->first() != null && \App\Addon::where('unique_identifier', 'seller_subscription')->first()->activated){
            $seller = $product->user->seller;
            if($seller->invalid_at != null && Carbon::now()->diffInDays(Carbon::parse($seller->invalid_at), false) <= 0){
                return 0;
            }
        }

        $product->save();
        return 1;
    }

    public function updateFeatured(Request $request)
    {
        $product = Product::findOrFail($request->id);
        $product->featured = $request->status;
        // $home_page_show = HomePageShow::where('page_in_home','featured_products')->first();
        // if($product->home_page_show == null)
        // {
        //     $product->home_page_show .= $home_page_show->id;
        // }
        // else
        // {
        //     if($request->status == 1)
        //     {
                
        //         $product->home_page_show .= ','.$home_page_show->id;
        //     }
            
        // }
        

        if($product->save()){
            return 1;
        }
        return 0;
    }

    public function sku_combination(Request $request)
    {
        $options = array();
        if($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
            $colors_active = 1;
            array_push($options, $request->colors);
        }
        else {
            $colors_active = 0;
        }

        $unit_price = $request->unit_price;
        $product_name = $request->name;

        if($request->has('choice_no')){
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_'.$no;
                $my_str = implode('', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }

        $combinations = combinations($options);
        return view('partials.sku_combinations', compact('combinations', 'unit_price', 'colors_active', 'product_name'));
    }

    public function sku_combination_edit(Request $request)
    {
        $product = Product::findOrFail($request->id);

        $options = array();
        if($request->has('colors_active') && $request->has('colors') && count($request->colors) > 0){
            $colors_active = 1;
            array_push($options, $request->colors);
        }
        else {
            $colors_active = 0;
        }

        $product_name = $request->name;
        $unit_price = $request->unit_price;

        if($request->has('choice_no')){
            foreach ($request->choice_no as $key => $no) {
                $name = 'choice_options_'.$no;
                $my_str = implode('|', $request[$name]);
                array_push($options, explode(',', $my_str));
            }
        }

        $combinations = combinations($options);
        return view('partials.sku_combinations_edit', compact('combinations', 'unit_price', 'colors_active', 'product_name', 'product'));
    }


    public function productUpdateFromPos()
    {
        
    
        $products = DB::connection('mysql2')->select(DB::raw('SELECT * FROM products'));
        //dd($products);

    
    }

    public function cleanData(&$str)
    {
        $str = preg_replace("/\t/", "\\t", $str);
        $str = preg_replace("/\r?\n/", "\\n", $str);
        if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
    }

    public function export_products(Request $request)
    {
       

        // filename for download
        $filename = "website_data_" . date('Ymd') . ".xls";

        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Type: application/vnd.ms-excel");
        
       
        // $products = DB::connection('mysql')->table('products')->with('extra')->latest()->get();

        $products = Product::with('extra')->latest()->get();
        $details = array();
        foreach($products as $key => $product)
        {
           
            $details[$key]['name'] = $product->name;
            $details[$key]['sku'] = $product->sku;
            if($product->category_id)
            {
                $cat = Category::where('id',$product->category_id)->first()->name;
                $details[$key]['category'] = $cat;
            }
            else
            {
                $details[$key]['category'] = '';
            }
            if($product->subcategory_id != null && $product->subcategory_id != '[]' )
            {
                
                $sub_cat = json_decode($product->subcategory_id);
                
                $sub_cat_name = '';
                if(is_array($sub_cat))
                {
                    foreach($sub_cat as $key1 => $sub )
                    {
                        $sub_name = SubCategory::where('id',$sub)->first();
                        if($sub_name)
                        {
                            $sub_cat_name .=  $sub_name->name.',';
                        }
                    }
                }
                else
                {
                    $sub_name = SubCategory::where('id',$sub_cat)->first();
                        if($sub_name)
                        {
                            $sub_cat_name .=  $sub_name->name.',';
                        }
                }
                
                $details[$key]['sub category'] = $sub_cat_name;
            }
            else
            {
                $details[$key]['sub category'] = '';
            }

            if($product->subsubcategory_id != null && $product->subsubcategory_id != '[]' )
            {
                $sub_cat = json_decode($product->subsubcategory_id);
                $sub_cat_name = '';
                if(is_array($sub_cat))
                {
                    foreach($sub_cat as $key1 => $sub )
                    {
                        $sub_name = SubSubCategory::where('id',$sub)->first();
                        if($sub_name)
                        {
                            $sub_cat_name .=  $sub_name->name.',';
                        }
                        
                    }
                }
                else
                {
                    $sub_name = SubCategory::where('id',$sub_cat)->first();
                        if($sub_name)
                        {
                            $sub_cat_name .=  $sub_name->name.',';
                        }
                }
                $details[$key]['sub sub category'] = $sub_cat_name;
            }
            else
            {
                $details[$key]['sub sub category'] = '';
            }
            if($product->published == 1)
            {
                $details[$key]['published'] = 'Yes';
            }
            else
            {
                $details[$key]['published'] = 'No';
            }

            $details[$key]['unit price'] = $product->unit_price;

             if($product->variant_product == 1)
            {
                $details[$key]['Variant'] = 'Yes';
            }
            else
            {
                $details[$key]['Variant'] = 'No';
            }

            $details[$key]['name arabic'] = translate($product->name);
            $details[$key]['product id'] = $product->id;
            if($product->extra)
            {
                $details[$key]['material'] = $product->extra->material;
                $details[$key]['battery'] = $product->extra->battery;
                $details[$key]['battery type'] = $product->extra->battery_type;
                $details[$key]['battery qty'] = $product->extra->battery_qty;
                $details[$key]['product dimention'] = $product->extra->product_dimention;
                $details[$key]['product unit'] = $product->extra->battery;
                $details[$key]['package dimention'] = $product->extra->package_dimention;
                $details[$key]['package unit'] = $product->extra->battery;
                $details[$key]['Recomended age'] = $product->extra->age_for;
                $details[$key]['country of origin'] = $product->extra->country_of_origin;
                $details[$key]['product warning'] = $product->extra->product_warning;
                $details[$key]['productusage'] = $product->extra->product_usage;
                $details[$key]['product weight'] = $product->extra->product_weight;
                $details[$key]['product weight unit'] = $product->extra->product_weight_unit;
                $details[$key]['package include'] = strip_tags($product->extra->package_include);

            }
            else
            {
                $details[$key]['material'] = '';
                $details[$key]['battery'] = '';
                $details[$key]['battery type'] = '';
                $details[$key]['battery qty'] = '';
                $details[$key]['product dimention'] = '';
                $details[$key]['product unit'] = '';
                $details[$key]['package dimention'] = '';
                $details[$key]['package unit'] = '';
                $details[$key]['Recomended age'] = '';
                $details[$key]['country of origin'] = '';
                $details[$key]['product warning'] = '';
                $details[$key]['product usage'] = '';
                $details[$key]['product weight'] = '';
                $details[$key]['product weight unit'] = '';
                $details[$key]['package include'] = '';
            }
            
            
        }
        // dd($details);
        $flag = false;
        foreach($details as $row) {
            if(!$flag) {
              // display field/column names as first row
              echo implode("\t", array_keys($row)) . "\r\n";
              $flag = true;
            }
            array_walk($row, 'self::cleanData');
            echo implode("\t", array_values($row)) . "\r\n";
          }
          


         
          exit;
    }


    public function export_productsaadsdsd(Request $request)
    {
        // filename for download
        $filename = "website_data_" . date('Ymd') . ".xls";

        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Type: application/vnd.ms-excel");
        
       
        // $products = DB::connection('mysql')->table('products')->with('extra')->latest()->get();

        // $products = Product::where('variant_product','1')->get();
        
        $details = array();
        
        //         $product_variants = ProductStock::get();
                
        //             foreach($product_variants as $key2 => $product_variant)
        //             {
        //                 $product = Product::where('id',$product_variant->product_id)->first();
        //                 if($product)
        //                 {
        //                     $details[$key2]['var_id'] = $product_variant->id; 
        //                     $details[$key2]['name'] = $product->name;
        //                     $details[$key2]['id'] = $product->id;
        //                     $details[$key2]['sku'] = $product->sku;
        //                     $details[$key2]['Variant'] = 'Yes';
        //                     $details[$key2]['Variant Name'] = $product_variant->variant;
            
        //                     $details[$key2]['Description'] = strip_tags($product_variant->variant_description);
        //                 }
                        
        //             }
                
                
                 
           
        
        // dd($details);
        $flag = false;
        foreach($details as $row) {
            if(!$flag) {
              // display field/column names as first row
              echo implode("\t", array_keys($row)) . "\r\n";
              $flag = true;
            }
            array_walk($row, 'self::cleanData');
            echo implode("\t", array_values($row)) . "\r\n";
          }
          


         
          exit;
       

        // filename for download
        $filename = "website_data_" . date('Ymd') . ".xls";

        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Type: application/vnd.ms-excel");
        
       
        // $products = DB::connection('mysql')->table('products')->with('extra')->latest()->get();

        $products = Product::with('extra')->latest()->get();
        $details = array();
        foreach($products as $key => $product)
        {
           
            $details[$key]['name'] = $product->name;
            $details[$key]['sku'] = $product->sku;
            if($product->category_id)
            {
                $cat = Category::where('id',$product->category_id)->first()->name;
                $details[$key]['category'] = $cat;
            }
            else
            {
                $details[$key]['category'] = '';
            }
            if($product->subcategory_id != null && $product->subcategory_id != '[]' )
            {
                
                $sub_cat = json_decode($product->subcategory_id);
                
                $sub_cat_name = '';
                if(is_array($sub_cat))
                {
                    foreach($sub_cat as $key1 => $sub )
                    {
                        $sub_name = SubCategory::where('id',$sub)->first();
                        if($sub_name)
                        {
                            $sub_cat_name .=  $sub_name->name.',';
                        }
                    }
                }
                else
                {
                    $sub_name = SubCategory::where('id',$sub_cat)->first();
                        if($sub_name)
                        {
                            $sub_cat_name .=  $sub_name->name.',';
                        }
                }
                
                $details[$key]['sub category'] = $sub_cat_name;
            }
            else
            {
                $details[$key]['sub category'] = '';
            }

            if($product->subsubcategory_id != null && $product->subsubcategory_id != '[]' )
            {
                $sub_cat = json_decode($product->subsubcategory_id);
                $sub_cat_name = '';
                if(is_array($sub_cat))
                {
                    foreach($sub_cat as $key1 => $sub )
                    {
                        $sub_name = SubSubCategory::where('id',$sub)->first();
                        if($sub_name)
                        {
                            $sub_cat_name .=  $sub_name->name.',';
                        }
                        
                    }
                }
                else
                {
                    $sub_name = SubCategory::where('id',$sub_cat)->first();
                        if($sub_name)
                        {
                            $sub_cat_name .=  $sub_name->name.',';
                        }
                }
                $details[$key]['sub sub category'] = $sub_cat_name;
            }
            else
            {
                $details[$key]['sub sub category'] = '';
            }
            if($product->published == 1)
            {
                $details[$key]['published'] = 'Yes';
            }
            else
            {
                $details[$key]['published'] = 'No';
            }

            $details[$key]['unit price'] = $product->unit_price;

             if($product->variant_product == 1)
            {
                $details[$key]['Variant'] = 'Yes';
            }
            else
            {
                $details[$key]['Variant'] = 'No';
            }
            $details[$key]['product id'] = $product->id;
            // $details[$key]['name arabic'] = translate($product->name);
            if($product->extra)
            {

                $details[$key]['material'] = $product->extra->material;
                $details[$key]['battery'] = $product->extra->battery;
                $details[$key]['battery type'] = $product->extra->battery_type;
                $details[$key]['battery qty'] = $product->extra->battery_qty;
                $details[$key]['product dimention'] = $product->extra->product_dimention;
                $details[$key]['product unit'] = $product->extra->battery;
                $details[$key]['package dimention'] = $product->extra->package_dimention;
                $details[$key]['package unit'] = $product->extra->battery;
                $details[$key]['Recomended age'] = $product->extra->age_for;
                $details[$key]['country of origin'] = $product->extra->country_of_origin;
                $details[$key]['product warning'] = $product->extra->product_warning;
                $details[$key]['productusage'] = $product->extra->product_usage;
                $details[$key]['product weight'] = $product->extra->product_weight;
                $details[$key]['product weight unit'] = $product->extra->product_weight_unit;
                $details[$key]['package include'] = strip_tags($product->extra->package_include);

            }
            else
            {
                $details[$key]['material'] = '';
                $details[$key]['battery'] = '';
                $details[$key]['battery type'] = '';
                $details[$key]['battery qty'] = '';
                $details[$key]['product dimention'] = '';
                $details[$key]['product unit'] = '';
                $details[$key]['package dimention'] = '';
                $details[$key]['package unit'] = '';
                $details[$key]['Recomended age'] = '';
                $details[$key]['country of origin'] = '';
                $details[$key]['product warning'] = '';
                $details[$key]['product usage'] = '';
                $details[$key]['product weight'] = '';
                $details[$key]['product weight unit'] = '';
                $details[$key]['package include'] = '';
            }
            
            
        }
        // dd($details);
        $flag = false;
        foreach($details as $row) {
            if(!$flag) {
              // display field/column names as first row
              echo implode("\t", array_keys($row)) . "\r\n";
              $flag = true;
            }
            array_walk($row, 'self::cleanData');
            echo implode("\t", array_values($row)) . "\r\n";
          }
          


         
          exit;
    }


    public function sitemapUpdate()
    {  
        $products = Product::where('published',1)->get();
      
        $categories = Category::all();
          
        $subcategories = SubCategory::all();
        $subsubcategories = SubSubCategory::all();
        $seosetteings = SeoSetting::where('main_page',0)->get();
       
        $posts = Post::all();
        //dd($posts);


        return response()->view('sitemap', [
            'products' => $products,
            'categories' => $categories,
            'subcategories' => $subcategories,
            'subsubcategories' => $subsubcategories,
            'seosetteings' => $seosetteings,
            'posts' => $posts,
        ])->header('Content-Type', 'text/xml');

    }

    public function removeAlldiscountProducts()
    {
        try{
            $all_products = Product::where('discount','>','0')->update(['discount' => '0.00']);
            return 1;
        }
        catch(\Exception $e)
        {
            return 0;
        }
        
    }
    public function removeAllFeaturedProducts()
    {
        try{
            $all_products = Product::where('featured','1')->update(['featured' => '0']);
            return 1;
        }
        catch(\Exception $e)
        {
            return 0;
        }
    }

    public function removeAllTodaysDeal()
    {
        try{
            $all_products = Product::where('todays_deal','1')->update(['todays_deal' => '0']);
            return 1;
        }
        catch(\Exception $e)
        {
            return 0;
        }
    }
    
    public function free_product_index()
    {
        $free_products = DB::table('free_products')
                    ->orderBy('id', 'desc')
                    ->join('products', 'products.id', '=', 'free_products.product_id')
                    ->select('free_products.id','free_products.offer_name','free_products.offer_type','free_products.status','products.name','products.sku')
                    ->distinct();
        $free_products = $free_products->paginate(15);
        return view('free_gift.index',compact('free_products'));
    }

    public function free_product_create()
    {
        $products = Product::where('current_stock','>','0')->get();
        return view('free_gift.create',compact('products'));
    }

    public function free_product_store(Request $request)
    {
        if(!empty($request->name) && !empty($request->product) && !empty($request->offer_type))
        {
            $free_product = new FreeProduct;
            $free_product->offer_name = $request->name;
            $free_product->product_id = $request->product;
            $free_product->offer_type = $request->offer_type;
            $free_product->validity = $request->expiry;
            $free_product->valid_text = $request->valid_text;
            $free_product->status = 0;
            $free_product->save();

            flash(translate('Free Gift has been inserted successfully'))->success();

        }
        else
        {
            flash(translate('Cannot add,Make sure you entered all the values.'))->error();
        }

        return redirect()->route('free_product.index');
    }

    public function free_product_edit($id)
    {
        $free_product = FreeProduct::findOrFail(decrypt($id));
        if($free_product)
        {
            $free_product_db = FreeProduct::where('id',decrypt($id))->first();
            $products =  Product::where('current_stock','>','0')->get();
            
            return view('free_gift.edit',compact('free_product_db','products'));
        }
    }

    public function free_product_update(Request $request)
    {
        $free_product = FreeProduct::where('id',$request->id)->first();
        $free_product->offer_name = $request->name;
        $free_product->product_id = $request->product;
        $free_product->offer_type = $request->offer_type;
        $free_product->validity = $request->expiry;
        $free_product->valid_text = $request->valid_text;
        
        $free_product->save();
        return redirect()->route('free_product.index');
    }

    public function free_product_status(Request $request)
    {
        $free_product = FreeProduct::where('id',$request->id)->first();
        if($free_product)
        {
            $free_product->status = $request->status;
            $free_product->save();
            return 1;
        }
        else{
            return 0;
        }
    }

    public function cronTest()
    {
        
        $cartLists = CartList::all();
        foreach($cartLists as $key => $cartlist)
        {
            $created = $cartlist->created_at;
            $now = \Carbon\Carbon::now();
            $added_days = $created->addDays(10);
            $result_day = $now->gte($added_days);
            if($result_day == false)
            {
                if(empty($cartlist->last_email_send) || $cartlist->last_email_send == '')
                {
                    if(!empty($cartlist->user_id) || !empty($cartlist->shipping_address))
                    {
                        $cart_details = CartDetail::where('cart_list_id',$cartlist->id)->get();
                        $cart_details_check_first = CartDetail::where('cart_list_id',$cartlist->id)->first();
                        $created = $cartlist->created_at;
                        
                        $current_time = \Carbon\Carbon::now();
                        $added_time = $created->addHours(3);
                        $result = $current_time->gte($added_time);
                        if($result == true)
                        {
                        
                            $array['order'] = $cartlist;
                            $array['status'] = 'Cart';
                            // dd($array['order']);
                            $array['order_details'] = $cart_details;
                            $array['view'] = 'emails.cart_alert';
                            
                            $array['from'] = env('MAIL_USERNAME');

                            try{
                                if($cart_details_check_first)
                                {
                                    if(is_null($cartlist->user_id)){
                                    
                                        $email = json_decode($cartlist->shipping_address)->email;
                                        $array['name'] = json_decode($cartlist->shipping_address)->name;
                                        $array['subject'] = 'Hi ' .ucwords($array['name']) .', come place your order!';
                                        $email_info = env('EMAIL_INFO');
                                        $email_it = env('EMAIL_IT');
                                        $email_more = env('EMAIL_MORE');
                                        $emai_marktng = env('EMAIL_MARKETING');
                                        $email_alternate = env('EMAIL_ALTERNATE');
                                        $send_to = [$email];
                                        $bcc = [$email_it,$email_more,$emai_marktng,$email_alternate];

                                           $email_check = $email;

                                        $vmail = new verifyEmail();
                                        $vmail->setStreamTimeoutWait(20);
                                        $vmail->Debug= TRUE;
                                        $vmail->Debugoutput= 'html';
                                
                                        $vmail->setEmailFrom('noreply@birigroup.com');
                                
                                        if ($vmail->check($email_check)) {
                                            Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                        } 
                                            if(!empty(json_decode($cartlist->shipping_address)->phone))
                                            {
                                                $this->cartAlertSms(json_decode($cartlist->shipping_address)->phone);
                                            }
                                        // Log::info('cart alert mail send');
                                        CartList::where('id',$cartlist->id)->update(['last_email_send'=>$current_time,'alert_email_send' => 1]);
                                    }
                                    else{
                                        $email = \App\User::find($cartlist->user_id)->email;
                                        $array['name'] = \App\User::find($cartlist->user_id)->name;
                                        $array['subject'] = 'Hi ' .$array['name'] .', come place your order!';
                                        $email_info = env('EMAIL_INFO');
                                        $email_it = env('EMAIL_IT');
                                        $email_more = env('EMAIL_MORE');
                                        $emai_marktng = env('EMAIL_MARKETING');
                                        $email_alternate = env('EMAIL_ALTERNATE');
                                        $send_to = [$email];
                                        $bcc = [$email_it,$email_more,$emai_marktng,$email_alternate];
                                        
                                        $email_check = $email;

                                        $vmail = new verifyEmail();
                                        $vmail->setStreamTimeoutWait(20);
                                        $vmail->Debug= TRUE;
                                        $vmail->Debugoutput= 'html';
                                
                                        $vmail->setEmailFrom('noreply@birigroup.com');
                                
                                        if ($vmail->check($email_check)) {
                                            Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                        }
                                        if(!empty(json_decode($cartlist->shipping_address)->phone))
                                        {
                                            $this->cartAlertSms(json_decode($cartlist->shipping_address)->phone);
                                        }
                                        Log::info('cart alert mail send');
                                        CartList::where('id',$cartlist->id)->update(['last_email_send'=>$current_time,'alert_email_send' => 1]);
                                    }
                                }

                            }
                            catch(\Exception $e)
                            {
                                Log::info('cart alert Exception');
                            }
                        }
                        else
                        {
                        
                            
                        }
                    }
                }
                else
                {
                    $cart_details = CartDetail::where('cart_list_id',$cartlist->id)->get();
                    $cart_details_check_first = CartDetail::where('cart_list_id',$cartlist->id)->first();
                    $created = new \Carbon\Carbon($cartlist->last_email_send);
                    $current_time = \Carbon\Carbon::now();
                    if(!empty($cartlist->deleay_schedule))
                    {
                        if($cartlist->deleay_schedule == '1')
                        {
                            $deleay_schedule = 2;
                            $added_time = $created->addHours(24);
                        }
                        if($cartlist->deleay_schedule == '2')
                        {
                            $deleay_schedule = 3;
                            $added_time = $created->addHours(72);
                        }
                        if($cartlist->deleay_schedule == '3')
                        {
                            $deleay_schedule = 4;
                            $added_time = $created->addDays(7);
                        }
                        if($cartlist->deleay_schedule == '4')
                        {
                            $deleay_schedule = 4;
                            $added_time = $created->addYears(100);
                        }

                    }
                    else
                    {
                        
                        $deleay_schedule = 1;
                        $added_time = $created->addHours(24);
                         
                    }
                                        
                    $result = $current_time->gte($added_time);
                    if($result == true)
                    {                 
                        $array['order'] = $cartlist;
                        $array['status'] = 'Cart';
                        // dd($array['order']);
                        $array['order_details'] = $cart_details;
                        $array['view'] = 'emails.cart_alert';
                        
                        $array['from'] = env('MAIL_USERNAME');

                        try{
                            if($cart_details_check_first)
                            {
                                if(is_null($cartlist->user_id)){

                                    $email = json_decode($cartlist->shipping_address)->email;
                                    $array['name'] = json_decode($cartlist->shipping_address)->name;
                                    $array['subject'] = 'Hi ' .ucwords($array['name']) .', come place your order!';
                                    $email_info = env('EMAIL_INFO');
                                    $email_it = env('EMAIL_IT');
                                    $email_more = env('EMAIL_MORE');
                                    $emai_marktng = env('EMAIL_MARKETING');
                                    $email_alternate = env('EMAIL_ALTERNATE');
                                    $send_to = [$email];
                                    $bcc = [$email_it,$email_more,$emai_marktng,$email_alternate];
                                        $email_check = $email;

                                    $vmail = new verifyEmail();
                                    $vmail->setStreamTimeoutWait(20);
                                    $vmail->Debug= TRUE;
                                    $vmail->Debugoutput= 'html';
                            
                                    $vmail->setEmailFrom('noreply@birigroup.com');
                            
                                    if ($vmail->check($email_check)) {
                                        Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                    }
                                        if(!empty(json_decode($cartlist->shipping_address)->phone))
                                        {
                                            $this->cartAlertSms(json_decode($cartlist->shipping_address)->phone);
                                        }
                                        Log::info('cart alert mail send');
                                    CartList::where('id',$cartlist->id)->update(['last_email_send'=>$current_time->toDateTimeString(),'alert_email_send' => 1,'deleay_schedule'=>$deleay_schedule]);
                                }
                                else{
                                    $email = \App\User::find($cartlist->user_id)->email;
                                    $array['name'] = \App\User::find($cartlist->user_id)->name;
                                    $array['subject'] = 'Hi ' .$array['name'] .', come place your order!';
                                    $email_info = env('EMAIL_INFO');
                                    $email_it = env('EMAIL_IT');
                                    $email_more = env('EMAIL_MORE');
                                    $emai_marktng = env('EMAIL_MARKETING');
                                    $email_alternate = env('EMAIL_ALTERNATE');
                                    $send_to = [$email];
                                    $bcc = [$email_it,$email_more,$emai_marktng,$email_alternate];
                                    $email_check = $email;

                                        $vmail = new verifyEmail();
                                        $vmail->setStreamTimeoutWait(20);
                                        $vmail->Debug= TRUE;
                                        $vmail->Debugoutput= 'html';
                                
                                        $vmail->setEmailFrom('noreply@birigroup.com');
                                
                                        if ($vmail->check($email_check)) {
                                            Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                        }
                                    if(!empty(json_decode($cartlist->shipping_address)->phone))
                                    {
                                        $this->cartAlertSms(json_decode($cartlist->shipping_address)->phone);
                                    }
                                    Log::info('cart alert mail send');
                                    CartList::where('id',$cartlist->id)->update(['last_email_send'=>$current_time->toDateTimeString(),'alert_email_send' => 1,'deleay_schedule'=>$deleay_schedule]);
                                }
                            }
                        }
                        catch(\Exception $e)
                        {
                            Log::info('cart alert Exception');
                        }
                    }
                }
            }
            else
            {
               
            }
        }
    }

    public function cartAlertSms($to)
    {
        try{
            
            $check = substr($to,0,4);
            if($check == '+971')
            {
                $to = substr_replace($to,"",0,4);
            }
            $check = substr($to,0,3);
            if($check == '971')
            {
                $to = substr_replace($to,"",0,3);
            }
            $check = substr($to,0,1);
            if($check == '0')
            {
                $to = substr_replace($to,"",0,1);
            }
            $to = '971'.$to;
            
           
          
            return 'true';
        }
        catch (\Exception $e)
        {
            return 'false';
        }
    }

    public function notifyStock(Request $request)
    {



          $validated = $request->validate([
            'email' => 'required|email|max:100',
            'captchaResponse' => 'required',
        ]);
      
             $secretKey  = "6LfuftsjAAAAAA2VzM9DEI5ftr7LgZE5qZexrd5I";
        // $this->form_validation->set_rules('g-recaptcha-response','Captcha','callback_recaptcha');
        if(!empty($request->captchaResponse) && !empty($request->captchaResponse))
        {
            // Get verify response data
            $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secretKey.'&response='.$request->captchaResponse);
            $responseData = json_decode($verifyResponse);
            
            if($responseData->success)
            {
                if(Auth::check())
                {
                    $user = User::where('id',Auth::user()->id)->first();
                    $name = $user->name;
                    $email = $user->email;
                    if($user->phone != null)
                    {
                        $phone = $user->phone;
                    }

                }
                else
                {
                    $name = $request->name;
                    $email = $request->email;
                    $phone = $request->phone;
                }
                
                $check_not = StockNotification::where('product_id',$request->pid)->where('email',$email)->where('email_send','0')->first();
                if(!$check_not)
                {
                    $notification = new StockNotification;
                    $notification->product_id = $request->pid;
                    $notification->name = $name;
                    $notification->email = $email;
                    $notification->phone = $phone;
                    $notification->save();
            
                  flash(translate('We will notify you once product is available'))->success();
                   }
                    else
                    {
                       flash(translate('Captcha Must Solved To Send Notify'))->warning();
                    }
            }
              else{
              //  return back();  
             }
                      //  return redirect()->back();

    }
    else
       {
        flash(translate('Captcha Must Solved To Send Notify'))->warning();
        }
  
     return redirect()->back();
    }
    
    // public function productStockNotification()
    // {
    //     $stock_notifications = StockNotification::where('email_send','0')->get();
    //     foreach($stock_notifications as $stock_notification)
    //     {
           
    //         $prod = Product::where('id',$stock_notification->product_id)->first();
    //         if($prod)
    //         {
    //             if($prod->current_stock > 0)
    //             {
                    
    //                 $array['product_id'] = $stock_notification->product_id;
    //                 $array['product'] = $prod;
    //                 $array['email'] = $stock_notification->email;
    //                 $array['name'] = $stock_notification->name;
    //                 // dd($array['order']);
    //                 $array['phone'] = $stock_notification->phone;
    //                 $array['view'] = 'emails.stock_notification_alert';
                    
    //                 $array['from'] = env('MAIL_USERNAME');
                    
    //                 try{
                            
    //                         $email = $stock_notification->email;
                            
    //                         $array['subject'] =ucwords($prod->name) .', is in stock now!';
    //                         $email_info = env('EMAIL_INFO');
    //                         $email_it = env('EMAIL_IT');
    //                         $email_more = env('EMAIL_MORE');
    //                         $emai_marktng = env('EMAIL_MARKETING');
    //                         $email_alternate = env('EMAIL_ALTERNATE');
    //                         $send_to = [$email];
    //                         $bcc = [$email_it,$email_more,$emai_marktng,$email_alternate];
    //                         $email_check = $email;

    //                                     $vmail = new verifyEmail();
    //                                     $vmail->setStreamTimeoutWait(20);
    //                                     $vmail->Debug= TRUE;
    //                                     $vmail->Debugoutput= 'html';
                                
    //                                     $vmail->setEmailFrom('noreply@birigroup.com');
                                
    //                                     if ($vmail->check($email_check)) {
    //                                         Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
    //                                     } 
    //                             // if(!empty($array['phone']))
    //                             // {
    //                             //     $this->cartAlertSms($array['phone']);
    //                             // }
                        
    //                     StockNotification::where('id',$stock_notification->id)->update(['email_send'=>'1']);        
    //                 }
    //                 catch(\Exception $e)
    //                 {
    //                     // Log::info($e);
    //                 }
    //             }
    //         }
            
            
    //     }
    // }

}
