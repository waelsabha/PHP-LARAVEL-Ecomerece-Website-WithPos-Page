<?php


namespace App\Http\Controllers;


use App\CustomerPackage;
use App\Order;
use App\OrderDetail;

use App\Models\Cart;

use Session;
use App\CartDetail;
use App\Product;
use App\ProductExtra;
use Illuminate\Support\Facades\Log;
class SendcloudController extends Controller
{
    public function sendlabel($order_id)
    {  


        $order = Order::findOrFail(Session::get('order_id'));
        $Shipping_address= $order->shipping_address;
        $total_order_value=$order->grand_total;
        $order_number=$order->code;
        $customer_name=json_decode($Shipping_address)->name;
        $customer_email=json_decode($Shipping_address)->email;
        //$customer_adress=json_decode($Shipping_address)->address;
        $customer_adress='London';
        $postcode=json_decode($Shipping_address)->postcode;
        $customer_flat_no=json_decode($Shipping_address)->flat_no;
        $customer_phone=json_decode($Shipping_address)->phone;
        $order_details = OrderDetail::where('order_id',$order_id)->get();
        $item = [];
        $parcelweight_one[]=0;
       //$parcelweightparcel=$parcelweight/$parcel_qnty;
        foreach($order_details as $key => $order_detail){
            $single_item['reference'] = $order_detail->id;
            $product = Product::where('id',$order_detail->product_id)->first();
            $single_item['description'] = $product->name;
           $single_item['product_id'] = $product->id;
           $properties['color']=$product->color_text;
           $single_item['properties'] = $properties;                  
            $single_item['quantity'] = $order_detail->quantity;
            $single_item['sku'] = $product->sku;
            $single_item['value'] = round(($order_detail->price)+($order_detail->tax),2);
           $single_item['weight'] = 3;                           
            $item[] = $single_item;
           
        }
        $base_url = 'https://panel.sendcloud.sc/api/v2/parcels';
        $order_data_json = [
            "parcel"=>
         [
                "name"=> $customer_name,
                "company_name"=> null,
                "email"=> $customer_email,
                "telephone"=> $customer_phone,
                "address"=> $customer_adress,
                "house_number"=> $customer_flat_no,
                "address_2"=> "",
                "city"=> $customer_adress,
                "country"=> 'GB',
                "postal_code"=> $postcode,
                "country_state"=> null,
                "integration_id"=>"" ,
                "to_service_point"=> null,
                "to_post_number"=>"" ,
                "customs_invoice_nr"=> "",
                "customs_shipment_type"=> null,
                "parcel_items"=> $item,
                ///here the weight of the order at all
                "weight"=> 3,
                "length"=> 70,
                "width"=> 70,
                "height"=> 70,
                "total_order_value"=> $total_order_value,
                "total_order_value_currency"=> "GBP",
                "shipment"=>
                [
                    "id"=>8,
                   "name"=> 'Unstamped letter'
                ],
                "Order_number"=> $order_number,
                "shipping_method_checkout_name"=>null,
                "quantity"=>1,
                "total_insured_value"=> 0,
                "is_return"=> false,
                "request_label"=> false,
                "apply_shipping_rules"=> false,
                "request_label_async"=> false
         ]
            ];
            $order_data_json = json_encode($order_data_json);

           
            $url = $base_url;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            $access_token='Basic ZTY4MTI5NTEzM2E2NDlkZDk4MzBjYjRmMjU5ZTkxOWE6ZDM0NTMzNTM1ODVhNDdmYjg1OTg4ZDM4Zjk4YWQ3NDQ=';
            $headers = array();
            $headers[] = 'Authorization: '.$access_token;
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $order_data_json);
            $result_order = curl_exec($ch);
          
          if (curl_errno($ch)) {
          echo 'Error:' . curl_error($ch);
          }
          curl_close($ch); 
          
         flash(translate('Your order has been placed successfully. Please submit payment information from purchase history'))->success();
         return redirect()->route('order_confirmed');
        // return view('frontend.app_confirm_order', compact('order'));
        //  dd($result_order);
    }


}
