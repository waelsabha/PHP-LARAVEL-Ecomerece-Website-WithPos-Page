<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stripe;

use App\Seller;

use App\CustomerPackage;
use App\SellerPackage;
use App\Http\Controllers\CustomerPackageController;
use App\Http\Controllers\CheckoutController;

use App\Http\Controllers\CommissionController;
use App\Http\Controllers\WalletController;



use Auth;
use App\Category;
use App\Http\Controllers\PaypalController;
use App\Http\Controllers\InstamojoController;
use App\Http\Controllers\ClubPointController;
use App\Http\Controllers\StripePaymentController;
use App\Http\Controllers\PublicSslCommerzPaymentController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AffiliateController;
use App\Http\Controllers\PaytmController;
use App\Order;
use App\BusinessSetting;
use App\Coupon;
use App\CouponUsage;
use App\User;
use App\Address;
use App\CartDetail;
use App\CartList;
use App\Country;
use App\Currency;
use App\PickupPoint;
use App\Models\Cart;
use PDF;
use Mail;
use App\Mail\InvoiceEmailManager;
use App\Models\OrderDetail;
use App\Models\Product;
use App\Models\ProductStock;
use App\ShippingCharge;
use Session;
use App\Utility\PayhereUtility;
use Illuminate\Support\Facades\DB;
use SMSGlobal\Credentials;
use SMSGlobal\Resource\Sms;
use App\Utility\verifyEmail;
use App\Postcodelatlng;
use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Facades\Log;
use Postpay\Exceptions\RESTfulException;

class StripePaymentController extends Controller
{
    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function stripe()
    {
        
        if(Session::has('payment_type')){
            if(Session::get('payment_type') == 'cart_payment' || Session::get('payment_type') == 'wallet_payment'){
                
                return view('frontend.payment.stripe');
            }
            elseif (Session::get('payment_type') == 'customer_package_payment') {
                $customer_package = CustomerPackage::findOrFail(Session::get('payment_data')['customer_package_id']);
                return view('frontend.payment.stripe', compact('customer_package'));
            }
            elseif (Session::get('payment_type') == 'seller_package_payment') {
                $seller_package = SellerPackage::findOrFail(Session::get('payment_data')['seller_package_id']);
                return view('frontend.payment.stripe', compact('seller_package'));
            }
        }
    }

    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
     function stripePost(Request $request)
    {
        
        if($request->session()->has('payment_type')){
            if($request->session()->get('payment_type') == 'cart_payment'){
                $order = Order::findOrFail(Session::get('order_id'));

                Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

                try {
                    // $payment = json_encode(Stripe\Charge::create ([
                    //         "amount" => $order->grand_total,
                    //         "currency" => "gbp",
                    //         "source" => $request->stripeToken
                    // ]));
                    $payment = \Stripe\PaymentIntent::create([
                    'amount' =>  $order->grand_total,
                    'currency' => "gbp",
                    "source" => $request->stripeToken
                ]);
                $output = [
                    'clientSecret' => $paymentIntent->client_secret,
                ];
                } catch (\Exception $e) {
                    flash($e->getMessage())->error();
                    return redirect()->route('checkout.payment_info');
                }


                $checkoutController = new CheckoutController;
                return $checkoutController->checkout_done($request->session()->get('order_id'), $payment);
            }
            elseif ($request->session()->get('payment_type') == 'wallet_payment') {
                Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

                try {
                    $payment = json_encode(Stripe\Charge::create ([
                            "amount" => $request->session()->get('payment_data')['amount'],
                            "currency" => "gbp",
                            "source" => $request->stripeToken
                    ]));
                } catch (\Exception $e) {
                    flash($e->getMessage())->error();
                    return redirect()->route('wallet.index');
                }


                $walletController = new WalletController;
                return $walletController->wallet_payment_done($request->session()->get('payment_data'), $payment);
            }
            elseif ($request->session()->get('payment_type') == 'customer_package_payment') {
                Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
                $customer_package = CustomerPackage::findOrFail(Session::get('payment_data')['customer_package_id']);

                try {
                    $payment = json_encode(Stripe\Charge::create ([
                            "amount" =>$customer_package->amount,
                            "currency" => "gbp",
                            "source" => $request->stripeToken
                    ]));
                } catch (\Exception $e) {
                    flash($e->getMessage())->error();
                    return redirect()->route('customer_packages_list_show');
                }


                $customer_package_controller = new CustomerPackageController;
                return $customer_package_controller->purchase_payment_done($request->session()->get('payment_data'), $payment);
            }
            elseif ($request->session()->get('payment_type') == 'seller_package_payment') {
                Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
                $seller_package = SellerPackage::findOrFail(Session::get('payment_data')['seller_package_id']);

                try {
                    $payment = json_encode(Stripe\Charge::create ([
                            "amount" => $seller_package->amount,
                            "currency" => "gbp",
                            "source" => $request->stripeToken
                    ]));
                } catch (\Exception $e) {
                    flash($e->getMessage())->error();
                    return redirect()->route('seller_packages_list');
                }


                $seller_package_controller = new SellerPackageController;
                return $seller_package_controller->purchase_payment_done($request->session()->get('payment_data'), $payment);
            }
        }
    }

    public function stripePostNew()
    {
        //require 'C:\xampp\htdocs\test_auth\vendor\autoload.php';
        // This is a public sample test API key.
        // Don’t submit any personally identifiable information in requests made with this key.
        // Sign in to see your own test API key embedded in code samples.
         


         //thats real one
            \Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));

            

            header('Content-Type: application/json');

            try {
                // retrieve JSON from POST body
                $jsonStr = file_get_contents('php://input');
                $jsonObj = json_decode($jsonStr);
                $order = Order::findOrFail(Session::get('order_id'));
                // Create a PaymentIntent with amount and currency
                Log::info('grand total when checking amount');
                Log::info($order->grand_total);
                $payment = \Stripe\PaymentIntent::create([
                    'amount' =>  ($order->grand_total*100),
                    'currency' => "gbp",
                    'automatic_payment_methods' => [
                        'enabled' => true,
                    ],
                ]);

                $output = [
                    'clientSecret' => $payment->client_secret,
                    
                ];

                echo json_encode($output);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
    }

    function calculateOrderAmount(array $items): int {
        // Replace this constant with a calculation of the order's amount
        // Calculate the order total on the server to prevent
        // people from directly manipulating the amount on the client
        return 1400;
    }

    public function stripeSuccess(Request $request)
    {
        //dd($request);
        $param = array();
        if(isset($request->redirect_status)){
            if($request->redirect_status == 'succeeded'){
                $param = ["payment_intent"=>$request->payment_intent,"payment_intent_client_secret"=>$request->payment_intent_client_secret,"redirect_status"=>$request->redirect_status];
                $orderController = new OrderController;
               $orderController->apiDataToWeAreFulfillment($request->session()->get('order_id'));
            }
        }
        
        $payment = json_encode($param);
        $order_id =$request->session()->get('order_id');
        $mobile_app=0;
        $order = Order::findOrFail($order_id);
        $order->payment_status = 'paid';
        $order->payment_details = $payment;
        $order->save();

        try {
            $payment = 'paid';
            
            Log::info('sale invoice updated in pos');
            $phone = json_decode($order->shipping_address)->phone;
            $explode = explode(',',$phone);
            $text = 'Dear Customer, your  order ('.$order->code.') has been successfully placed.We are preparing your order and we will inform you when it is shipped.';
            if($order->country_id == '230')
                                {
                                    try{
                                        //$this->send_message($explode[0],$text);
                                    }
                                    catch (\Exception $e) {
                                        Log::info($e);
                                    }
                                    
                                }
            
        }
        catch(\Exception $e)
        {
            Log::info('Could not update in pos');
        }
        if($mobile_app == 0)
        {
        foreach (Session::get('cart') as $key => $cartItem){
           
            if(env('ONE_DHM_DEAL') == 1)
                {
                    $flash_deal_product = \App\FlashDealProduct::where('product_id', $cartItem['id'])->first();
                    if($flash_deal_product)
                    {
                        if($flash_deal_product->product_id == $cartItem['id'])
                        {
                            $order->deal_availed = 1;
                        }
                    }
                }
            if($cartItem['one_dirham'] == 1)
            {
                $order->deal_availed = 1; 
            }

        }
        }
        $order->save();
        
        $user_update_one_aed_deal = 
            $order_details = OrderDetail::where('order_id',$order->id)->first();

            $pdf = PDF::setOptions([
                'isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true,
                'logOutputFile' => storage_path('logs/log.htm'),
                'tempDir' => storage_path('logs/')
            ])->loadView('invoices.customer_invoice', compact('order'));
                $output = $pdf->output();
                file_put_contents('public/invoices/'.'Order#'.$order->code.'.pdf', $output);

                
                if($order_details->shipping_type == 'home_delivery')
                {
                    $array['shipping_type'] = $order_details->shipping_type;

                }
                else{
                    $array['shipping_type'] = $order_details->shipping_type;
                    $pick_up_address = PickupPoint::where('id',$order_details->pickup_point_id)->first();
                    $array['pickup_address'] = $pick_up_address->address;
                    $array['phone']  = $pick_up_address->phone;
                }
                $array['code'] = $order->code;
                $array['order'] = $order;

                // dd($array['order']);
                $array['order_details'] = $order_details;
                $array['view'] = 'emails.invoice';
                $array['subject'] = 'Order Placed -Biri Trading UK LTD';
                $array['from'] = env('MAIL_USERNAME');
                $array['content'] = translate('A new order has been placed. Please check the attached invoice.');
                $array['file'] = 'public/invoices/Order#'.$order->code.'.pdf';
                $array['file_name'] = 'Order#'.$order->code.'.pdf';

                
                    try {
                        Log::info('checkout received trying to send email');
                        if(is_null($order->user_id)){
                                Log::info('inside if');
                                $email = json_decode($order->shipping_address)->email;
                            
                                $email_info = env('EMAIL_INFO');
                                $email_it = env('EMAIL_IT');
                                $email_more = env('EMAIL_MORE');
                                $email_accounts = env('EMAIL_ACC');
                                $emai_marktng = env('EMAIL_MARKETING');
                                $email_alternate = env('EMAIL_ALTERNATE');
                                $send_to = [$email];
                                Log::info('inside if 1');
                                $bcc = [$email_info,$email_it,$email_more,$emai_marktng, $email_alternate];
                                Log::info('inside if 2');
								 Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                 Log::info('inside if 3');
                           
                                Log::info('send to guest user - '.$email);
                            }
                            else
                            {
                                Log::info('inside else 1');
                               // $email = \App\User::find($order->user_id)->email; we need to try why not send email when customer logged in
                                 $email = json_decode($order->shipping_address)->email;
                            
                                $email_info = env('EMAIL_INFO');
                                $email_it = env('EMAIL_IT');
                                $email_more = env('EMAIL_MORE');
                                $email_accounts = env('EMAIL_ACC');
                                $emai_marktng = env('EMAIL_MARKETING');
                                $email_alternate = env('EMAIL_ALTERNATE');
                                $send_to = [$email];
                                Log::info('inside else 2');
                                $bcc = [$email_info,$email_it,$email_more,$emai_marktng,$email_alternate];
                                Log::info('inside else 3');
                                Mail::to($send_to)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                Log::info('inside else 4');

                              
                                Log::info('send to registered user - '.$email);
                            }
                                
                    } catch (\Exception $e) {
                        Log::info(json_encode($e));
                        Log::info('exception');
                    }
                
        

        if (\App\Addon::where('unique_identifier', 'affiliate_system')->first() != null && \App\Addon::where('unique_identifier', 'affiliate_system')->first()->activated) {
            $affiliateController = new AffiliateController;
            $affiliateController->processAffiliatePoints($order);
        }

        if (\App\Addon::where('unique_identifier', 'club_point')->first() != null && \App\Addon::where('unique_identifier', 'club_point')->first()->activated) {
            $clubpointController = new ClubPointController;
            $clubpointController->processClubPoints($order);
        }
        if (\App\Addon::where('unique_identifier', 'seller_subscription')->first() == null || !\App\Addon::where('unique_identifier', 'seller_subscription')->first()->activated) {
            if (BusinessSetting::where('type', 'category_wise_commission')->first()->value != 1) {
                $commission_percentage = BusinessSetting::where('type', 'vendor_commission')->first()->value;
                foreach ($order->orderDetails as $key => $orderDetail) {
                    $orderDetail->payment_status = 'paid';
                    $orderDetail->save();
                    if ($orderDetail->product->user->user_type == 'seller') {
                        $seller = $orderDetail->product->user->seller;
                        $seller->admin_to_pay = $seller->admin_to_pay + ($orderDetail->price * (100 - $commission_percentage)) / 100 + $orderDetail->tax + $orderDetail->shipping_cost;
                        $seller->save();
                    }
                }
            } else {
                foreach ($order->orderDetails as $key => $orderDetail) {
                    $orderDetail->payment_status = 'paid';
                    $orderDetail->save();
                    if ($orderDetail->product->user->user_type == 'seller') {
                        $commission_percentage = $orderDetail->product->category->commision_rate;
                        $seller = $orderDetail->product->user->seller;
                        $seller->admin_to_pay = $seller->admin_to_pay + ($orderDetail->price * (100 - $commission_percentage)) / 100 + $orderDetail->tax + $orderDetail->shipping_cost;
                        $seller->save();
                    }
                }
            }
        } else {
            foreach ($order->orderDetails as $key => $orderDetail) {
                $orderDetail->payment_status = 'paid';
                $orderDetail->save();
                if ($orderDetail->product->user->user_type == 'seller') {
                    $seller = $orderDetail->product->user->seller;
                    $seller->admin_to_pay = $seller->admin_to_pay + $orderDetail->price + $orderDetail->tax + $orderDetail->shipping_cost;
                    $seller->save();
                }
            }
        }

        $order->commission_calculated = 1;
        $order->save();

         if($mobile_app == 1)
        {
             $sendcloudshipping = new SendcloudController();
            $sendcloudshipping->sendlabel($order->id);
            //return view('frontend.app_confirm_order', compact('order'));
        }
        else
        {
            Session::put('cart', collect([]));
            // Session::forget('order_id');
            Session::forget('payment_type');
            Session::forget('delivery_info');
            Session::forget('coupon_id');
            Session::forget('coupon_discount');
            
           $sendcloudshipping = new SendcloudController();
            $sendcloudshipping->sendlabel($order->id);
           // flash(translate('Payment completed'))->success();
            //return view('frontend.order_confirmed', compact('order'));
        }
        
    }
}
