<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\BusinessSetting;
use App\ClubPointDetail;
use App\ClubPoint;
use App\Product;
use App\Wallet;
use App\Order;
use Auth;
use Mail;
use App\Mail\InvoiceEmailManager;
use App\User;
use Illuminate\Support\Facades\Log;
use App\Utility\verifyEmail;

class ClubPointController extends Controller
{
    public function configure_index()
    {
        return view('club_points.config');
    }

    public function index()
    {
        $club_points = ClubPoint::latest()->paginate(15);
        return view('club_points.index', compact('club_points'));
    }

    public function showDetails()
    {
        return view('club_points.frontend.show_details');
    }

    public function userpoint_index()
    {
        $club_points = ClubPoint::where('user_id', Auth::user()->id)->latest()->paginate(15);
        return view('club_points.frontend.index', compact('club_points'));
    }

    public function set_point()
    {
        $products = Product::latest()->paginate(15);
        return view('club_points.set_point', compact('products'));
    }

    public function set_products_point(Request $request)
    {
        $products = Product::whereBetween('unit_price', [$request->min_price, $request->max_price])->get();
        foreach ($products as $product) {
            $product->earn_point = $request->point;
            $product->save();
        }
        flash(translate('Point has been inserted successfully for ').count($products).translate(' products'))->success();
        return redirect()->route('set_product_points');
    }

    public function set_all_products_point(Request $request)
    {
        $products = Product::all();
        foreach ($products as $product) {;
            $product->earn_point = $product->unit_price * $request->point;
            $product->save();
        }
        flash(translate('Point has been inserted successfully for ').count($products).translate(' products'))->success();
        return redirect()->route('set_product_points');
    }

    public function set_point_edit($id)
    {
        $product = Product::findOrFail(decrypt($id));
        return view('club_points.product_point_edit', compact('product'));
    }

    public function update_product_point(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $product->earn_point = $request->point;
        $product->save();
        flash(translate('Point has been updated successfully'))->success();
        return redirect()->route('set_product_points');
    }

    public function convert_rate_store(Request $request)
    {
        $club_point_convert_rate = BusinessSetting::where('type', $request->type)->first();
        if ($club_point_convert_rate != null) {
            $club_point_convert_rate->value = $request->value;
        }
        else {
            $club_point_convert_rate = new BusinessSetting;
            $club_point_convert_rate->type = $request->type;
            $club_point_convert_rate->value = $request->value;
        }
        $club_point_convert_rate->save();
        flash(translate('Point convert rate has been updated successfully'))->success();
        return redirect()->route('club_points.configs');
    }

    public function processClubPoints(Order $order)
    {
        if($order->user_id)
        {
            $club_point = new ClubPoint;
            $club_point->user_id = $order->user_id;
            $club_point->order_id = $order->id;
            $club_point->points = 0;
            foreach ($order->orderDetails as $key => $orderDetail) {
                $total_pts = ($orderDetail->product->earn_point) * $orderDetail->quantity;
                $club_point->points += $total_pts;
            }
            if($total_pts > ( $order->grand_total-$order->shipping_cost ) )
            {
                $club_point->points = $order->grand_total-$order->shipping_cost;
            }
            $club_point->convert_status = 0;
            $club_point->customer_paid = $order->grand_total-$order->shipping_cost;
            $club_point->save();
            Log::info('process club point');
            foreach ($order->orderDetails as $key => $orderDetail) {
                $club_point_detail = new ClubPointDetail;
                $club_point_detail->club_point_id = $club_point->id;
                $club_point_detail->product_id = $orderDetail->product_id;
                $club_point_detail->order_details_id = $orderDetail->id;
                $club_point_detail->product_qty = $orderDetail->quantity;
                $club_point_detail->point = $total_pts;
                $club_point_detail->save();
            }
            if($order->payment_status == 'paid')
            {
                $this->methodPointToWallet($club_point->id);
            }
        }
        
    }

    public function club_point_detail($id)
    {
        $club_point_details = ClubPointDetail::where('club_point_id', decrypt($id))->paginate(12);
        return view('club_points.club_point_details', compact('club_point_details'));
    }

    public function club_point_edit($id)
    {
        $club_point_details = ClubPointDetail::where('club_point_id', $id)->paginate(12);
        $club_point_main = ClubPoint::where('id', $id)->first();
        return view('club_points.club_point_edit', compact('club_point_details','club_point_main'));
    }

    public function convert_point_into_wallet(Request $request)
    {
        $club_point_convert_rate = BusinessSetting::where('type', 'club_point_convert_rate')->first()->value;
        $club_point = ClubPoint::findOrFail($request->el);
        $wallet = new Wallet;
        $wallet->user_id = Auth::user()->id;
        $wallet->amount = floatval($club_point->points / $club_point_convert_rate);
        $wallet->payment_method = 'Club Point Convert';
        $wallet->payment_details = 'Club Point Convert';
        $wallet->save();
        $user = Auth::user();
        $user->balance = $user->balance + floatval($club_point->points / $club_point_convert_rate);
        $user->save();
        $club_point->convert_status = 1;
        if ($club_point->save()) {
            return 1;
        }
        else {
            return 0;
        }
    }

    public function methodPointToWallet($id)
    {
        $club_point_convert_rate = BusinessSetting::where('type', 'club_point_convert_rate')->first()->value;
        $club_point = ClubPoint::findOrFail($id);
        $wallet = new Wallet;
        $wallet->user_id = $club_point->user_id;
        $wallet->amount = floatval($club_point->points / $club_point_convert_rate);
        $wallet->payment_method = 'Club Point Convert';
        $wallet->payment_details = 'Club Point Convert';
        $wallet->save();
        
        $user = User::where('id',$club_point->user_id)->first();
        $user->balance = $user->balance + floatval($club_point->points / $club_point_convert_rate);
        $user->save();
        $club_point->convert_status = 1;
        if ($club_point->save()) {
            return 1;
        }
        else {
            return 0;
        }
    }

    public function alert_mail(Request $request)
    {
        $club_point = ClubPoint::where('id',$request->club_id)->where('convert_status',1)->first();
        if($club_point)
        {
            $user = User::where('id',$club_point->user_id)->first();
            if($user)
            {
                $club_point_convert_rate = BusinessSetting::where('type', 'club_point_convert_rate')->first()->value;
                $aed = 1/$club_point_convert_rate;
                $array['aed_rate'] = round($aed,2);
                $cashback = $aed*$club_point->points;
                $array['cash_back'] = round($cashback,2);
                $array['view'] = 'club_points.alert_mail_send';
                $array['subject'] = 'Redeem Your Club Point';
                $array['from'] = env('MAIL_USERNAME');
                $array['point_receved'] = $club_point->points;
                $email_more = env('EMAIL_MORE');
                $email_it = env('EMAIL_IT');

                // return view('club_points.alert_mail_send',compact('array'));
                $bcc = [$email_more,$email_it];
                $email_check = $user->email;

                                        $vmail = new verifyEmail();
                                        $vmail->setStreamTimeoutWait(20);
                                        $vmail->Debug= TRUE;
                                        $vmail->Debugoutput= 'html';
                                
                                        $vmail->setEmailFrom('noreply@birigroup.com');
                                
                                        if ($vmail->check($email_check)) {
                                            Mail::to($user->email)->bcc($bcc)->queue(new InvoiceEmailManager($array));
                                        }  
                
                return 'true';
            }
        }
        
    }

    public function club_point_update(Request $request)
    {
        $club_point_convert_rate = \App\BusinessSetting::where('type', 'club_point_convert_rate')->first()->value;
        $club_point =  ClubPoint::where('id', $request->club_id)->first();
        $user = User::where('id',$club_point->user_id)->first();
        $old_balance_customer_paid = $request->old_customer_paid;
        if($club_point->convert_status == 1)
        {
            $current_value = $request->point_value *(1/ $club_point_convert_rate);
            $old_balance_customer_paid_point_value = $old_balance_customer_paid *(1/ $club_point_convert_rate);
            if($user->balance > $current_value)
            {
                if(($user->balance - $old_balance_customer_paid_point_value >=  0 ))
                {
                    $user->balance = ($user->balance - $old_balance_customer_paid_point_value) + $current_value;

                    $user->save();
                    ClubPoint::where('id', $request->club_id)->update(['points'=>$request->point_value,'customer_paid'=>$request->customer_paid]);
                    flash(translate('Point has been updated successfully'))->success();
                    return redirect()->back();
                }
                
            }
            else
            {
                flash(translate('User balance is low for updating'))->error();
                return redirect()->back();
            }
        }
        else
        {
            ClubPoint::where('id', $request->club_id)->update(['points'=>$request->point_value,'customer_paid'=>$request->customer_paid]);
            flash(translate('Point has been updated successfully'))->success();
            return redirect()->back();
        }
        
    }
}
