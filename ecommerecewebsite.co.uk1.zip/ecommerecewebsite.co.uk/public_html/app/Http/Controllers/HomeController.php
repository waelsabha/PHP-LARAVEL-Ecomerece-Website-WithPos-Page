<?php

namespace App\Http\Controllers;

use App\Address;
use Illuminate\Http\Request;
use Session;
use Auth;
use Hash;
use App\Category;
use App\FlashDeal;
use App\Brand;
use App\SubCategory;
use App\SubSubCategory;
use App\Product;
use App\ProductStock;
use App\PickupPoint;
use App\CustomerPackage;
use App\CustomerProduct;
use App\User;
use App\Seller;
use App\Shop;
use App\Color;
use App\Order;

use App\BusinessSetting;
use App\Country;
use App\Currency;
use App\Http\Controllers\SearchController;
use ImageOptimizer;
use Cookie;
use Illuminate\Support\Str;
use App\Mail\SecondEmailVerifyMailManager;
use App\Models\OrderDetail;
use App\Models\SeoSetting;
use App\ProductExtra;
use App\ProductMetadata;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;
use Mail;

use SMSGlobal\Credentials;
use SMSGlobal\Resource\Sms;

use App\Http\Controllers\CartController;
use App\ShippingCharge;
use Illuminate\Support\Facades\DB;

use function GuzzleHttp\Promise\exception_for;

use Stevebauman\Location\Facades\Location;
use App\Utility\verifyEmail;

class HomeController extends Controller
{

    public function __construct()
    {

        //update_all_stock_from_pos();
        // update_cartDb_to_cartSession();
    }



    public function login()
    {
        if (Auth::check()) {
            return redirect()->route('home');
        }
        return view('frontend.user_login');
    }

    public function registration(Request $request)
    {
        if (Auth::check()) {
            return redirect()->route('home');
        }
        if ($request->has('referral_code')) {
            Cookie::queue('referral_code', $request->referral_code, 43200);
        }
        return view('frontend.user_registration');
    }

    // public function user_login(Request $request)
    // {
    //     $user = User::whereIn('user_type', ['customer', 'seller'])->where('email', $request->email)->first();
    //     if($user != null){
    //         if(Hash::check($request->password, $user->password)){
    //             if($request->has('remember')){
    //                 auth()->login($user, true);
    //             }
    //             else{
    //                 auth()->login($user, false);
    //             }
    //             return redirect()->route('dashboard');
    //         }
    //     }
    //     return back();
    // }

    public function cart_login(Request $request)
    {
        $user = User::whereIn('user_type', ['customer', 'seller'])->where('email', $request->email)->orWhere('phone', $request->email)->first();
        if ($user != null) {
            updateCartSetup();
            if (Hash::check($request->password, $user->password)) {
                if ($request->has('remember')) {
                    auth()->login($user, true);
                } else {
                    auth()->login($user, false);
                }
            }
        }
        return back();
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */


    /**
     * Show the admin dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function admin_dashboard()
    {
        
        return view('dashboard');
    }

    /**
     * Show the customer/seller dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function dashboard()
    {
        if (Auth::user()->user_type == 'seller') {
            return view('frontend.seller.dashboard');
        } elseif (Auth::user()->user_type == 'customer') {
            return view('frontend.customer.dashboard');
        } else {
            abort(404);
        }
    }

    public function profile(Request $request)
    {
        if (Auth::user()->user_type == 'customer') {
            return view('frontend.customer.profile');
        } elseif (Auth::user()->user_type == 'seller') {
            return view('frontend.seller.profile');
        }
    }

    public function address_edit_profile(Request $request)
    {
        $address = Address::where('id',$request->address_id)->first();
        $country = Country::where('name',$address->country)->first();
        $shipping_charges_db = ShippingCharge::where('sc_country',$country->id)->where('sc_sts',1)->where('sc_color','!=','red')->get();
        
        $emirates = $shipping_charges_db->unique('sc_emirate');

        $shipping_charges_area = ShippingCharge::where('sc_emirate',$address->emirate)->where('sc_color','!=','red')->get();
        
        $areas = $shipping_charges_area->unique('sc_town');
        
        return view('frontend.customer.profile_edit',compact('address','emirates','areas'));
        
    }

    public function customer_update_profile(Request $request)
    {
        if (env('DEMO_MODE') == 'On') {
            flash(translate('Sorry! the action is not permitted in demo '))->error();
            return back();
        }

        $user = Auth::user();
        $user->name = $request->name;
        $user->address = $request->address;
        $user->country = $request->country;
        $user->city = $request->city;
        $user->postal_code = $request->postal_code;
        $user->phone = $request->phone;

        if ($request->new_password != null && ($request->new_password == $request->confirm_password)) {
            $user->password = Hash::make($request->new_password);
        }

        if ($request->hasFile('photo')) {
            $user->avatar_original = $request->photo->store('uploads/users');
        }

        if ($user->save()) {
            flash(translate('Your Profile has been updated successfully!'))->success();
            return back();
        }

        flash(translate('Sorry! Something went wrong.'))->error();
        return back();
    }


    public function seller_update_profile(Request $request)
    {
        if (env('DEMO_MODE') == 'On') {
            flash(translate('Sorry! the action is not permitted in demo '))->error();
            return back();
        }

        $user = Auth::user();
        $user->name = $request->name;
        $user->address = $request->address;
        $user->country = $request->country;
        $user->city = $request->city;
        $user->postal_code = $request->postal_code;
        $user->phone = $request->phone;

        if ($request->new_password != null && ($request->new_password == $request->confirm_password)) {
            $user->password = Hash::make($request->new_password);
        }

        if ($request->hasFile('photo')) {
            $user->avatar_original = $request->photo->store('uploads');
        }

        $seller = $user->seller;
        $seller->cash_on_delivery_status = $request->cash_on_delivery_status;
        $seller->bank_payment_status = $request->bank_payment_status;
        $seller->bank_name = $request->bank_name;
        $seller->bank_acc_name = $request->bank_acc_name;
        $seller->bank_acc_no = $request->bank_acc_no;
        $seller->bank_routing_no = $request->bank_routing_no;

        if ($user->save() && $seller->save()) {
            flash(translate('Your Profile has been updated successfully!'))->success();
            return back();
        }

        flash(translate('Sorry! Something went wrong.'))->error();
        return back();
    }

    public function saudiArabia()
    {
        Session::put('currency_code','SAR');
        Session::put('locale','sa');
        
        // $request->session()->put('currency_code', $request->currency_code);
        $currency = Currency::where('code', 'SAR')->first();
        $country = Currency::where('code', $currency->country_id)->first();
        
        if($country)
        {
            flash(translate('Country ').$country->name)->success();
        }  

        return redirect()->route('home');
    }

    public function bahrain()
    {
        Session::put('currency_code','BHD');
        Session::put('locale','sa');
        
        // $request->session()->put('currency_code', $request->currency_code);
        $currency = Currency::where('code', 'BHD')->first();
        $country = Currency::where('code', $currency->country_id)->first();
        
        if($country)
        {
            flash(translate('Country ').$country->name)->success();
        }  

        return redirect()->route('home');
    }

    /**
     * Show the application frontend home.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         //$a = 10;
       // $check = Product::where('subcategory_id','like', '%' . $a . '%')->where('published', 1)->where('category_id', 4)->get();
        try {
            $this->updateSeoSetting('main');
        } catch (\Exception $e) {
        }

        $tasks_controller = new CartController;

        $tasks_controller->addFreeGift('registration');
        

        return view('frontend.index');
    }
    public function updateSeoSetting($page_name)
    {

        $meta_data = SeoSetting::where('page_name', $page_name)->first();
        $meta_data->updated_at = date('Y-m-d H:i:s');
        $meta_data->save();

        if ($meta_data) {

            $abc = view('invoices.pages_rdf', compact('meta_data'))->render();

            Storage::disk('local')->put('rdf/' . $page_name . '.rdf', $abc);
        }
    }

    public function flash_deal_details($slug)
    {
        $flash_deal = FlashDeal::where('slug', $slug)->first();
        if ($flash_deal != null)
            return view('frontend.flash_deal_details', compact('flash_deal'));
        else {
            abort(404);
        }
    }

    public function load_newArrival_section()
    {
        return view('frontend.partials.new_arrival');
    }

    // public function load_category_grid()
    // {
    //     return view('frontend.partials.category_grid');
    // }

    // public function load_category_grid_two()
    // {
    //     return view('frontend.partials.category_grid_two');
    // }


    public function load_featured_section()
    {
        return view('frontend.partials.featured_products_section');
    }

    public function load_subsubcat_one()
    {
        return view('frontend.partials.sub_category_home_section');
    }

    public function load_best_selling_section()
    {
        return view('frontend.partials.best_selling_section');
    }

    // public function load_sorted_by_price()
    // {
    //     return view('frontend.partials.sorted_by_price');
    // }
    // public function load_sorted_by_price_2()
    // {
    //     return view('frontend.partials.sorted_by_price_2');
    // }

    public function load_best_selling_section_category()
    {
        return view('frontend.partials.best_selling_categories');
    }

    public function load_home_categories_section()
    {
        return view('frontend.partials.home_categories_section');
    }

    public function load_best_sellers_section()
    {
        return view('frontend.partials.best_sellers_section');
    }



    public function load_first_secton_in_home()
    {
        return view('frontend.partials.first_secton_in_home');
    }
    
    public function offer_details($slug)
    {
        $home_show = \App\HomePageShow::where('id', decrypt($slug))->first();
       
    }

    public function trackOrder(Request $request)
    {
        if ($request->has('order_code')) {
            $order = Order::where('code', $request->order_code)->first();
            if ($order != null) {
                $order_details = OrderDetail::where('order_id', $order->id)->first();

                return view('frontend.track_order', compact('order', 'order_details'));
            }
        }
        return view('frontend.track_order');
    }

    public function delivaryCharges()
    {
        return view('frontend.policies.delivary');
    }
   public function oursitemap()
    {
        return view('frontend.sitemaps.oursitemap');
    }

    public function product(Request $request, $slug)
    {
        $detailedProduct  = Product::where('slug', $slug)->first();
        try {
            $this->updateMetadata($detailedProduct->id);
        } catch (\Exception $e) {
        }
        if ($detailedProduct != null && $detailedProduct->published) {
            $product_extra = ProductExtra::where('product_id', $detailedProduct->id)->first();
        
            updateCartSetup();
            if ($request->has('product_referral_code')) {
                Cookie::queue('product_referral_code', $request->product_referral_code, 43200);
                Cookie::queue('referred_product_id', $detailedProduct->id, 43200);
            }
            if ($detailedProduct->digital == 1) {
                return view('frontend.digital_product_details', compact('detailedProduct', 'product_extra'));
            } else {
                // dd($detailedProduct);

               
                return view('frontend.product_details', compact('detailedProduct', 'product_extra'));
            }
            // return view('frontend.product_details', compact('detailedProduct'));
        }
        abort(404);
    }

    public function updateMetadata($product_id)
    {

        $meta_data = ProductMetadata::where('product_id', $product_id)->first();
        $meta_data->updated_at = date('Y-m-d H:i:s');
        $meta_data->save();

        if ($meta_data) {

            $abc = view('invoices.rdf', compact('meta_data'))->render();

            Storage::disk('local')->put('rdf/prd_' . $meta_data->product_id . '.rdf', $abc);
        } else {

            $meta_data = new ProductMetadata;

            $meta_data->product_id = $product_id;
            // dd($request->meta_title);
            $meta_data->m_title = '';
            $meta_data->m_mdesc = '';


            $meta_data->m_title = '';



            $meta_data->m_mdesc = '';


            $meta_data->m_mkeywrd = '';
            $meta_data->m_robot = '';
            $meta_data->m_cpyrgt = '';
            $meta_data->m_dc_title = '';
            $meta_data->m_dc_desc = '';
            $meta_data->m_dc_sub = '';
            $meta_data->m_dc_crtor = '';
            $meta_data->m_dc_type = '';
            $meta_data->m_dc_type_img = '';
            $meta_data->m_dc_lang = '';
            $meta_data->m_dc_format = '';
            $meta_data->save();



            $abc = view('invoices.rdf', compact('meta_data'))->render();

            Storage::disk('local')->put('rdf/prd_' . $meta_data->product_id . '.rdf', $abc);
        }
    }

    public function colorSelect(Request $request)
    {
        if ($request->ajax()) {

            $test = $request->get('test');

            $data = $test;
            return response()->json($data);
        }
    }

    public function getProductVarientDetails(Request $request)
    {
        if ($request->ajax()) {

            $variant = $request->get('variant');

            $product_id = $request->get('product_id');

            // $variant=preg_replace('/\s+/', '', $variant);

            $product_stock = ProductStock::where('product_id', $product_id)->where('variant', $variant)->first();
            // $data = $test;
            return response()->json($product_stock);
        }
    }

    public function shop($slug)
    {
        $shop  = Shop::where('slug', $slug)->first();
        if ($shop != null) {
            $seller = Seller::where('user_id', $shop->user_id)->first();
            if ($seller->verification_status != 0) {
                return view('frontend.seller_shop', compact('shop'));
            } else {
                return view('frontend.seller_shop_without_verification', compact('shop', 'seller'));
            }
        }
        abort(404);
    }

    public function filter_shop($slug, $type)
    {
        $shop  = Shop::where('slug', $slug)->first();
        if ($shop != null && $type != null) {
            return view('frontend.seller_shop', compact('shop', 'type'));
        }
        abort(404);
    }

    public function listing(Request $request)
    {
        // $products = filter_products(Product::orderBy('created_at', 'desc'))->paginate(12);
        // return view('frontend.product_listing', compact('products'));
         return $this->search($request);
    }

    public function all_categories(Request $request)
    {
        $categories = Category::where('status',1)->get();
        return view('frontend.all_category', compact('categories'));
    }
    public function all_brands(Request $request)
    {
        $categories = Category::all();
        return view('frontend.all_brand', compact('categories'));
    }

    public function show_product_upload_form(Request $request)
    {
        if (\App\Addon::where('unique_identifier', 'seller_subscription')->first() != null && \App\Addon::where('unique_identifier', 'seller_subscription')->first()->activated) {
            if (Auth::user()->seller->remaining_uploads > 0) {
                $categories = Category::all();
                return view('frontend.seller.product_upload', compact('categories'));
            } else {
                flash(translate('Upload limit has been reached. Please upgrade your package.'))->warning();
                return back();
            }
        }
        $categories = Category::all();
        return view('frontend.seller.product_upload', compact('categories'));
    }

    public function show_product_edit_form(Request $request, $id)
    {
        $categories = Category::all();
        $product = Product::find(decrypt($id));
        return view('frontend.seller.product_edit', compact('categories', 'product'));
    }

    public function seller_product_list(Request $request)
    {
        $check_seller_verification = Seller::where('user_id', Auth::user()->id)->where('verification_status', 1)->first();
        if (!$check_seller_verification) {
            flash(translate('Your account is not verified yet!'))->warning();
            return redirect()->route('dashboard');
        }
        $search = null;
        $products = Product::where('user_id', Auth::user()->id)->orderBy('created_at', 'desc');
        if ($request->has('search')) {
            $search = $request->search;
            $products = $products->where('name', 'like', '%' . $search . '%');
        }
        $products = $products->paginate(10);
        return view('frontend.seller.products', compact('products', 'search'));
    }

    public function ajax_search(Request $request)
    {
        $keywords = array();
        $products = Product::where('published', 1)->where('tags', 'like', '%' . $request->search . '%')->get();
        foreach ($products as $key => $product) {
            foreach (explode(',', $product->tags) as $key => $tag) {
                if (stripos($tag, $request->search) !== false) {
                    if (sizeof($keywords) > 5) {
                        break;
                    } else {
                        if (!in_array(strtolower($tag), $keywords)) {
                            array_push($keywords, strtolower($tag));
                        }
                    }
                }
            }
        }

        $products = filter_products(Product::where('published', 1)->where('name', 'like', '%' . $request->search . '%')->orWhere('sku', 'like', '%' . $request->search  . '%'))->get()->take(3);

        $subsubcategories = SubSubCategory::where('name', 'like', '%' . $request->search . '%')->get()->take(3);

        $shops = Shop::whereIn('user_id', verified_sellers_id())->where('name', 'like', '%' . $request->search . '%')->get()->take(3);

        if (sizeof($keywords) > 0 || sizeof($subsubcategories) > 0 || sizeof($products) > 0 || sizeof($shops) > 0) {
            return view('frontend.partials.search_content', compact('products', 'subsubcategories', 'keywords', 'shops'));
        }
        return '0';
    }

    public function search(Request $request, $value = null)
    {

       //dd($request);

        $query = $request->q;
        
        $tag = $request->tag;
        $brand_id = (Brand::where('slug', $request->brand)->first() != null) ? Brand::where('slug', $request->brand)->first()->id : null;
        $sort_by = $request->sort_by;
        if($request->category)
        {
            $category_id = (Category::where('slug', $request->category)->first() != null) ? Category::where('slug', $request->category)->first()->id : null;

        }
        else
        {

            $category_id = (Category::where('slug', $value)->first() != null) ? Category::where('slug', $value)->first()->id : null;
            
        }


        // dd($request->category);
        if($request->subcategory)
        {
            $subcategory_id = (SubCategory::where('slug', $request->subcategory)->first() != null) ? SubCategory::where('slug', $request->subcategory)->first()->id : null;
        }
        else
        {
            $subcategory_id = (SubCategory::where('slug', $value)->first() != null) ? SubCategory::where('slug', $value)->first()->id : null;

        }
        if($request->subsubcategory)
        {
            $subsubcategory_id = (SubSubCategory::where('slug', $request->subsubcategory)->first() != null) ? SubSubCategory::where('slug', $request->subsubcategory)->first()->id : null;
        }
        else
        {
            $subsubcategory_id = (SubSubCategory::where('slug', $value)->first() != null) ? SubSubCategory::where('slug', $value)->first()->id : null;
        }
        $min_price = $request->min_price;
        $max_price = $request->max_price;
        $seller_id = $request->seller_id;



        $conditions = ['published' => 1];

        if ($brand_id != null) {
            $conditions = array_merge($conditions, ['brand_id' => $brand_id]);
        }



        if ($category_id != null) {
            $conditions = array_merge($conditions, ['category_id' => $category_id]);
            $products = Product::where('published', 1)->where('category_id', $category_id);
        }
        if ($subcategory_id != null) {
            $conditions = array_merge($conditions, ['subcategory_id' => $subcategory_id]);
            $products = Product::where('published', 1)->where('subcategory_id', 'like', '%"' . $subcategory_id . '"%');
        }
        if ($subsubcategory_id != null) {
            $conditions = array_merge($conditions, ['subsubcategory_id' => $subsubcategory_id]);
            $products = Product::where('published', 1)->where('subsubcategory_id', 'like', '%"' . $subsubcategory_id . '"%');
        }

        if ($seller_id != null) {
            $conditions = array_merge($conditions, ['user_id' => Seller::findOrFail($seller_id)->user->id]);
            $products = Product::where('user_id', Seller::findOrFail($seller_id)->user->id);
        }
        // dd($products);
        if (!isset($products)) {
            $products = Product::where('published', 1)->where('subcategory_id', 'like', '%' . $subcategory_id . '%');
        }

        // $products = Product::where($conditions);

        if ($min_price != null && $max_price != null) {
            $products = $products->where('unit_price', '>=', $min_price)->where('unit_price', '<=', $max_price);
        }

        if ($query != null) {
            $searchController = new SearchController;
            $searchController->store($request);
             $products = $products->where('name', 'like', '%' . $query . '%')->orWhere('tags', 'like', '%' . $query . '%');
        }

        if ($tag != null) {
            // $searchController = new SearchController;
            // $searchController->store($request);
            $products = $products->Where('tags', 'like', '%' . $tag . '%');
            $sort_by = null;
           
        }

        if ($sort_by != null) {
            switch ($sort_by) {
                case '1':
                    $products->orderBy('created_at', 'desc');
                    break;
                case '2':
                    $products->orderBy('created_at', 'asc');
                    break;
                case '3':
                    $products->orderBy('unit_price', 'asc');
                    break;
                case '4':
                    $products->orderBy('unit_price', 'desc');
                    break;
                default:
                    // code...
                    break;
            }
        }


        $non_paginate_products = filter_products($products,$sort_by)->get();

        //Attribute Filter

        $attributes = array();
        foreach ($non_paginate_products as $key => $product) {
            if ($product->attributes != null && is_array(json_decode($product->attributes))) {
                foreach (json_decode($product->attributes) as $key => $value) {
                    $flag = false;
                    $pos = 0;
                    foreach ($attributes as $key => $attribute) {
                        if ($attribute['id'] == $value) {
                            $flag = true;
                            $pos = $key;
                            break;
                        }
                    }
                    if (!$flag) {
                        $item['id'] = $value;
                        $item['values'] = array();
                        foreach (json_decode($product->choice_options) as $key => $choice_option) {
                            if ($choice_option->attribute_id == $value) {
                                $item['values'] = $choice_option->values;
                                break;
                            }
                        }
                        array_push($attributes, $item);
                    } else {
                        foreach (json_decode($product->choice_options) as $key => $choice_option) {
                            if ($choice_option->attribute_id == $value) {
                                foreach ($choice_option->values as $key => $value) {
                                    if (!in_array($value, $attributes[$pos]['values'])) {
                                        array_push($attributes[$pos]['values'], $value);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        $selected_attributes = array();

        foreach ($attributes as $key => $attribute) {
            if ($request->has('attribute_' . $attribute['id'])) {
                foreach ($request['attribute_' . $attribute['id']] as $key => $value) {
                    $str = '"' . $value . '"';
                    $products = $products->where('choice_options', 'like', '%' . $str . '%');
                }

                $item['id'] = $attribute['id'];
                $item['values'] = $request['attribute_' . $attribute['id']];
                array_push($selected_attributes, $item);
            }
        }


        //Color Filter
        $all_colors = array();

        foreach ($non_paginate_products as $key => $product) {
            if ($product->colors != null) {
                foreach (json_decode($product->colors) as $key => $color) {
                    if (!in_array($color, $all_colors)) {
                        array_push($all_colors, $color);
                    }
                }
            }
        }

        $selected_color = null;

        if ($request->has('color')) {
            $str = '"' . $request->color . '"';
            $products = $products->where('colors', 'like', '%' . $str . '%');
            $selected_color = $request->color;
        }
        $selected_age = array();
        if ($request->has('by_age')) {


            $by_age = $request->by_age;

            foreach ($by_age as $key => $item) {
                array_push($selected_age, $item);
            }
            // $products = $products->whereIn('subcategory_id','like',  '%' . $by_age .'%');
            $products = $products->where(function ($query) use ($by_age) {
                foreach ($by_age as $keyword) {
                    $query->orWhere('subcategory_id', 'like',  '%' . $keyword . '%');
                }
            });
        }

        
        $products = filter_products($products,$sort_by)->paginate(12)->appends(request()->query());
        $session_count = session()->put('p_count', $products->count());

        
        try {
            $session_pid_first = session()->put('pid_first', $products[0]->id);
            Log::info('last id main--'.$products[11]->id);
            $session_pid = session()->put('pid', $products[11]->id);
        } catch (\Exception $e) {
        }

        return view('frontend.product_listing', compact('products', 'query', 'tag', 'category_id', 'subcategory_id', 'subsubcategory_id', 'brand_id', 'sort_by', 'seller_id', 'min_price', 'max_price', 'attributes', 'selected_attributes', 'all_colors', 'selected_color', 'selected_age'));
        
    }


    public function fetchMoreProducts(Request $request)
    {
        DB::enableQueryLog();
        $query = $request->q;
        $brand_id = (Brand::where('slug', $request->brand)->first() != null) ? Brand::where('slug', $request->brand)->first()->id : null;
        $sort_by = $request->sort_by;
        $category_id = null;
        $subcategory_id = null;
        $subsubcategory_id = null;

        if($request->slug)
        {
            $category_id = (Category::where('slug', $request->slug)->first() != null) ? Category::where('slug', $request->slug)->first()->id : null;

        }
        if($request->cat1)
        {
            $category_id = (Category::where('slug', $request->cat1)->first() != null) ? Category::where('slug', $request->cat1)->first()->id : null;

        }
        
        if($request->subcat1)
        {
            $subcategory_id = (SubCategory::where('slug', $request->subcat1)->first() != null) ? SubCategory::where('slug', $request->subcat1)->first()->id : null;

        }
   
        if($request->subsubcat2)
        {
            $subsubcategory_id = (SubSubCategory::where('slug', $request->subsubcat2)->first() != null) ? SubSubCategory::where('slug', $request->subsubcat2)->first()->id : null;
        }


        if($request->category)
        {
            $category_id = (Category::where('slug', $request->category)->first() != null) ? Category::where('slug', $request->category)->first()->id : null;

        }
        
        if($request->subcategory)
        {
            $subcategory_id = (SubCategory::where('slug', $request->subcategory)->first() != null) ? SubCategory::where('slug', $request->subcategory)->first()->id : null;

        }
   
        if($request->subsubcategory)
        {
            $subsubcategory_id = (SubSubCategory::where('slug', $request->subsubcategory)->first() != null) ? SubSubCategory::where('slug', $request->subsubcategory)->first()->id : null;
        }
        // $query_log = DB::getQueryLog();
        // Log::info($query_log);
        // Log::info('Slug--'.$request->slug);
        $min_price = $request->min_price;
        $max_price = $request->max_price;
        $seller_id = $request->seller_id;

        $conditions = ['published' => 1];

        if ($brand_id != null) {
            $conditions = array_merge($conditions, ['brand_id' => $brand_id]);
        }
        if ($category_id != null) {
            $conditions = array_merge($conditions, ['category_id' => $category_id]);
            Log::info('cat id-- '.$category_id);
            $products = Product::where('published', 1)->where('category_id', $category_id);
        }
        if ($subcategory_id != null) {
            $conditions = array_merge($conditions, ['subcategory_id' => $subcategory_id]);
            // Log::info('subcat id-- '.$subcategory_id);
            $products = Product::where('published', 1)->where('subcategory_id', 'like', '%"' . $subcategory_id . '"%');
        }
        if ($subsubcategory_id != null) {
            // Log::info('sub sub cat id-- '.$subsubcategory_id);
            $conditions = array_merge($conditions, ['subsubcategory_id' => $subsubcategory_id]);

            $products = Product::where('published', 1)->where('subsubcategory_id', 'like', '%"' . $subsubcategory_id . '"%');
        }
        if ($seller_id != null) {
            $conditions = array_merge($conditions, ['user_id' => Seller::findOrFail($seller_id)->user->id]);
        }

        if (!isset($products)) {
            $products = Product::where('published', 1);
        }
        // $products = Product::where($conditions);
        // dd($products);
        if ($min_price != null && $max_price != null) {
            Log::info('inside price sort-'.$min_price.'--max-'.$max_price);
            $products = $products->where('unit_price', '>=', $min_price)->where('unit_price', '<=', $max_price);
        }

        if ($query != null) {
            $searchController = new SearchController;
            $searchController->store($request);
            $products = $products->where('name', 'like', '%' . $query . '%')->orWhere('tags', 'like', '%' . $query . '%');
        }

        $tag = $request->tag;
        if ($tag != null) {
            
            $products = $products->where('tags', 'like', '%' . $tag . '%');
        }
        Log::info('sort by--'.$sort_by);
        if ($sort_by != null) {
            switch ($sort_by) {
                case '1':
                    $products->orderBy('created_at', 'desc');
                    break;
                case '2':
                    $products->orderBy('created_at', 'asc');
                    break;
                case '3':
                    Log::info('sort insode case --'.$sort_by);
                    // $products->orderBy('unit_price', 'asc');
                    
                    break;
                case '4':
                    $products->orderBy('unit_price', 'desc');
                    break;
                default:
                    // code...
                    break;
            }
        }
        // Log::info($products);

        // $non_paginate_products = filter_products($products)->get();

        //Attribute Filter
        
        $attributes = array();
        // foreach ($non_paginate_products as $key => $product) {
        //     if ($product->attributes != null && is_array(json_decode($product->attributes))) {
        //         foreach (json_decode($product->attributes) as $key => $value) {
        //             $flag = false;
        //             $pos = 0;
        //             foreach ($attributes as $key => $attribute) {
        //                 if ($attribute['id'] == $value) {
        //                     $flag = true;
        //                     $pos = $key;
        //                     break;
        //                 }
        //             }
        //             if (!$flag) {
        //                 $item['id'] = $value;
        //                 $item['values'] = array();
        //                 foreach (json_decode($product->choice_options) as $key => $choice_option) {
        //                     if ($choice_option->attribute_id == $value) {
        //                         $item['values'] = $choice_option->values;
        //                         break;
        //                     }
        //                 }
        //                 array_push($attributes, $item);
        //             } else {
        //                 foreach (json_decode($product->choice_options) as $key => $choice_option) {
        //                     if ($choice_option->attribute_id == $value) {
        //                         foreach ($choice_option->values as $key => $value) {
        //                             if (!in_array($value, $attributes[$pos]['values'])) {
        //                                 array_push($attributes[$pos]['values'], $value);
        //                             }
        //                         }
        //                     }
        //                 }
        //             }
        //         }
        //     }
        // }

        $selected_attributes = array();

        foreach ($attributes as $key => $attribute) {
            if ($request->has('attribute_' . $attribute['id'])) {
                foreach ($request['attribute_' . $attribute['id']] as $key => $value) {
                    $str = '"' . $value . '"';
                    $products = $products->where('choice_options', 'like', '%' . $str . '%');
                }

                $item['id'] = $attribute['id'];
                $item['values'] = $request['attribute_' . $attribute['id']];
                array_push($selected_attributes, $item);
            }
        }


        //Color Filter
        $all_colors = array();

        // foreach ($non_paginate_products as $key => $product) {
        //     if ($product->colors != null) {
        //         foreach (json_decode($product->colors) as $key => $color) {
        //             if (!in_array($color, $all_colors)) {
        //                 array_push($all_colors, $color);
        //             }
        //         }
        //     }
        // }

        $selected_color = null;

        if ($request->has('color')) {
            $str = '"' . $request->color . '"';
            $products = $products->where('colors', 'like', '%' . $str . '%');
            $selected_color = $request->color;
        }
        $selected_age = array();


        if ($request->has('by_age')) {
            //    Log::info('inside by age');
            $by_age = json_decode($request->by_age);

            if ($by_age != null) {
                foreach ($by_age as $key => $item) {
                    array_push($selected_age, $item);
                }

                // $products = $products->whereIn('subcategory_id','like',  '%' . $by_age .'%');

                $products = $products->where(function ($query) use ($by_age) {
                    foreach ($by_age as $keyword) {

                        $query->orWhere('subcategory_id', 'like',  '%' . $keyword . '%');
                    }
                });
            }
        }

        if ($request->ajax()) {
            if (session()->get('pid')) {
                // Log::info('product--count before---'.$products->count());
                $id = session()->get('pid');
                // Log::info('id --'.$id);
                $id_first = session()->get('pid_first');
                Log::info('here1');
                Log::info($request->sort_by);
                if ($sort_by != null) {
                    $products = filter_products2($products, $id,$sort_by)->take(12);
                }
                else
                {
                    $products = filter_products2($products, $id,$sort_by)->paginate(12)->appends(request()->query());

                }
                
               
                
                // $products = filter_products2($products, $id,$sort_by);
                // $products = $products->orderBy('created_at','asc');
                // $products = $products->paginate(12)->appends(request()->query());
                // Log::info('product--count---'.$products->count());
            }
            if ($request->has('category')) {
            }
            

            // $products = Product::all();
            $productcount = session()->get('p_count');
            if ($productcount < 12) {
                $productcount = session()->forget('p_count');
                $product = '';

                return $product;
            } else {

                $productcount = session()->put('p_count', $products->count());
            }
            
            if (session()->get('pid_first')) {

                $products->contains('id', $id_first);
            }
            try {
                
                $lst_pid = $products->count() - 1;
                Log::info('last pid --'.$products[$lst_pid]->id);
                Log::info('current page--'.$products->currentPage());
                // $session_pid = session()->put('pid', $products[$lst_pid]->id);
            } catch (\Exception $e) {
            }
        }
        $data = '';
        $last_id = '';
       
        if ($request->ajax()) {
            
            foreach ($products as $key => $product) {
                
                    if ($products->count() < 12) {
                        session()->forget('pid_first');
                        session()->forget('pid');
                    }
    
                    if ($product->id == $id_first) {
    
                        return $product->id;
                        session()->forget('pid_first');
                        session()->forget('pid');
                    } else {
    
    
                        $data .= '<div class="col-xxl-3 col-xl-4 col-lg-3 col-md-4 col-6">';
                        $data .= '<div class="product-box-2 bg-white alt-box my-md-2">';
                        $data .= '<div class="position-relative overflow-hidden">';
    
                        $data .=  "<a href=" . route('product', $product->slug) . " class='d-block product-image h-100 text-center' tabindex='0'>";
    
                        if ($request->webp == 1) {
    
                            $photo_webp = convertToWebp($product->thumbnail_img);
                            if (file_exists(public_path($photo_webp))) {
    
                                $photo_name = $photo_webp;
                            } else {
                                $photo_name = $product->thumbnail_img;
                            }
                        } else {
                            $photo_name = $product->thumbnail_img;
                        }
    
                        $data .= '<img class="img-fit img-fit2 img-response lazyload" src="' . my_asset('frontend/images/placeholder.webp') . '" data-src="' . my_asset($product->thumbnail_img) . '" alt="' . translateUsingDb($product->name) . '" />';
                        if (home_base_price($product->id) != home_discounted_base_price($product->id)) {
    
                            $real_price = home_base_price_without_format($product->id);
                            $discounted_price = home_discounted_base_price_without_format($product->id);
                            $disc_price = $real_price - $discounted_price;
                            $discount_per = ($disc_price / $real_price) * 100;
                            $discount_per = round($discount_per, 0);
                            $data .= '<p class="disount-perc">-' . $discount_per . '% <span class="off-style">OFF</span></p>';
                        }
    
                        $data .= '</a>';
    
                        $data .= '<div class="product-btns clearfix">';
                        $data .= '<button class="btn add-wishlist" title="Add to Wishlist" onclick="addToWishList(' . $product->id . ')" type="button">';
                        $data .= '<i class="la la-heart-o"></i></button>';
    
                        $data .= '<button class="btn quick-view" title="Quick view" onclick="showAddToCartModal(' . $product->id . ')" type="button">';
                        $data .= '<i class="la la-eye"></i></button>';
    
                        $data .= '<button class="add-to-cart btn" title="Add to Cart" onclick="showAddToCartModal(' . $product->id . ')" type="button">';
                        $data .= '<i class="la la-shopping-cart"></i></button>';
                        $data .= '</div>';
    
    
                        $data .= '</div>';
    
                        $data .= '<div class="p-md-3 p-2">';
                        $data .= '<div class="price-box">';
                        if (home_base_price($product->id) != home_discounted_base_price($product->id)) {
                            $data .= '<del class="old-product-price strong-400">' . home_base_price($product->id) . ' </del>';
                        }
                       
                             $data .= '<span class="product-price strong-600">'. home_unit_price($product->id) .'</span></br>';
                              $data .= ' <span class="product-price strong-200">'. home_discounted_base_price($product->id) .' (Inc VAT 20%) </span>';
                         


                        $data .= '</div>';
                        $data .= '<h2 class="product-title p-0">';
                        $data .= '<a href=' . route('product', $product->slug) . ' class=" text-truncate">' .  translateUsingDb($product->name) . '</a>';
                       if (\App\Addon::where('unique_identifier', 'club_point')->first() != null && \App\Addon::where('unique_identifier', 'club_point')->first()->activated) {
                          //  $data .= '<div class="club-point mt-2 bg-soft-base-1 border-light-base-1 border">';
                          //  $data .=  translateUsingDb('Club Point');
                          //  $data .= '<span class="strong-700 float-right">' . $product->earn_point . '</span>';
                          //  $data .= '</div>';
                       }
                        $data .= '</div>';
                        $data .= '</div>';
    
                        $data .= '</div>';
                    }
                    $last_id = $product->id;
                
               
            }
            $session_pid = session()->put('pid', $last_id);
            // $data .= '<input name="last_id" value="' . $last_id . '" hidden />';
            return $data;
        }
    }

    public function product_content(Request $request)
    {
        $connector  = $request->connector;
        $selector   = $request->selector;
        $select     = $request->select;
        $type       = $request->type;
        productDescCache($connector, $selector, $select, $type);
    }

    public function home_settings(Request $request)
    {
        return view('home_settings.index');
    }

    public function top_10_settings(Request $request)
    {
        foreach (Category::all() as $key => $category) {
            if (is_array($request->top_categories) && in_array($category->id, $request->top_categories)) {
                $category->top = 1;
                $category->save();
            } else {
                $category->top = 0;
                $category->save();
            }
        }

        foreach (Brand::all() as $key => $brand) {
            if (is_array($request->top_brands) && in_array($brand->id, $request->top_brands)) {
                $brand->top = 1;
                $brand->save();
            } else {
                $brand->top = 0;
                $brand->save();
            }
        }

        flash(translate('Top 10 categories and brands have been updated successfully'))->success();
        return redirect()->route('home_settings.index');
    }

    public function variant_price(Request $request)
    {
        $product = Product::find($request->id);
        $str = '';
        $quantity = 0;

        if ($request->has('color')) {
            $data['color'] = $request['color'];
            $str = Color::where('code', $request['color'])->first()->name;
        }

        if (json_decode(Product::find($request->id)->choice_options) != null) {
            foreach (json_decode(Product::find($request->id)->choice_options) as $key => $choice) {
                if ($str != null) {
                    $str .= '-' . str_replace(' ', '', $request['attribute_id_' . $choice->attribute_id]);
                    $item = $request['attribute_id_' . $choice->attribute_id];
                } else {
                    $str .= str_replace(' ', '', $request['attribute_id_' . $choice->attribute_id]);
                    $item = $request['attribute_id_' . $choice->attribute_id];
                }
            }
        }



        if ($str != null && $product->variant_product) {
            $product_stock = $product->stocks->where('variant', $item)->first();
            $price = $product_stock->price;
            $quantity = $product_stock->qty;
        } else {
            $price = $product->unit_price;
            $quantity = $product->current_stock;
        }

        //discount calculation
        $flash_deals = \App\FlashDeal::where('status', 1)->get();
        $inFlashDeal = false;
        foreach ($flash_deals as $key => $flash_deal) {
            if ($flash_deal != null && $flash_deal->status == 1 && strtotime(date('d-m-Y')) >= $flash_deal->start_date && strtotime(date('d-m-Y')) <= $flash_deal->end_date && \App\FlashDealProduct::where('flash_deal_id', $flash_deal->id)->where('product_id', $product->id)->first() != null) {
                $flash_deal_product = \App\FlashDealProduct::where('flash_deal_id', $flash_deal->id)->where('product_id', $product->id)->first();
                if ($flash_deal_product->discount_type == 'percent') {
                    $price -= ($price * $flash_deal_product->discount) / 100;
                } elseif ($flash_deal_product->discount_type == 'amount') {
                    $price -= $flash_deal_product->discount;
                }
                $inFlashDeal = true;
                break;
            }
        }
        if (!$inFlashDeal) {
            if ($product->discount_type == 'percent') {
                $price -= ($price * $product->discount) / 100;
            } elseif ($product->discount_type == 'amount') {
                $price -= $product->discount;
            }
        }

        if ($product->tax_type == 'percent') {
            $price += ($price * $product->tax) / 100;
        } elseif ($product->tax_type == 'amount') {
            $price += $product->tax;
        }
        return array('price' => single_price($price * $request->quantity), 'quantity' => $quantity, 'digital' => $product->digital);
    }

    public function sellerpolicy()
    {
        return view("frontend.policies.sellerpolicy");
    }

    public function returnpolicy()
    {
        return view("frontend.policies.returnpolicy");
    }

    public function supportpolicy()
    {
        return view("frontend.policies.supportpolicy");
    }

    public function terms()
    {
        return view("frontend.policies.terms");
    }
   
  public function contactUs()
    {
        return view("frontend.policies.contactUs");
    }
  public function frequentlquestion()
    {
        return view("frontend.policies.frequestion");
    }
    
    public function privacypolicy()
    {
        return view("frontend.policies.privacypolicy");
    }

    public function get_pick_ip_points(Request $request)
    {
        $pick_up_points = PickupPoint::all();
        return view('frontend.partials.pick_up_points', compact('pick_up_points'));
    }

    public function get_category_items(Request $request)
    {
        $category = Category::findOrFail($request->id);
        return view('frontend.partials.category_elements', compact('category'));
    }

    public function premium_package_index()
    {
        $customer_packages = CustomerPackage::all();
        return view('frontend.customer_packages_lists', compact('customer_packages'));
    }

    public function seller_digital_product_list(Request $request)
    {
        $check_seller_verification = Seller::where('user_id', Auth::user()->id)->where('verification_status', 1)->first();
        if (!$check_seller_verification) {
            flash(translate('Your account is not verified yet!'))->warning();
            return redirect()->route('dashboard');
        }
        $products = Product::where('user_id', Auth::user()->id)->where('digital', 1)->orderBy('created_at', 'desc')->paginate(10);
        return view('frontend.seller.digitalproducts.products', compact('products'));
    }
    public function show_digital_product_upload_form(Request $request)
    {
        if (\App\Addon::where('unique_identifier', 'seller_subscription')->first() != null && \App\Addon::where('unique_identifier', 'seller_subscription')->first()->activated) {
            if (Auth::user()->seller->remaining_digital_uploads > 0) {
                $business_settings = BusinessSetting::where('type', 'digital_product_upload')->first();
                $categories = Category::where('digital', 1)->get();
                return view('frontend.seller.digitalproducts.product_upload', compact('categories'));
            } else {
                flash(translate('Upload limit has been reached. Please upgrade your package.'))->warning();
                return back();
            }
        }

        $business_settings = BusinessSetting::where('type', 'digital_product_upload')->first();
        $categories = Category::where('digital', 1)->get();
        return view('frontend.seller.digitalproducts.product_upload', compact('categories'));
    }

    public function show_digital_product_edit_form(Request $request, $id)
    {
        $categories = Category::where('digital', 1)->get();
        $product = Product::find(decrypt($id));
        return view('frontend.seller.digitalproducts.product_edit', compact('categories', 'product'));
    }


    // Ajax call
    public function new_verify(Request $request)
    {
        $email = $request->email;
        if (isUnique($email) == '0') {
            $response['status'] = 2;
            $response['message'] = 'Email already exists!';
            return json_encode($response);
        }

        $response = $this->send_verification_mail($request, $email);
        return json_encode($response);
    }


    // Form request
    public function update_email(Request $request)
    {
        $email = $request->email;
        if (isUnique($email)) {
            $this->send_email_change_verification_mail($request, $email);
            flash(translate('A verification mail has been sent to the mail you provided us with.'))->success();
            return back();
        }

        flash(translate('Email already exists!'))->warning();
        return back();
    }

    public function send_email_change_verification_mail($request, $email)
    {
        $response['status'] = 0;
        $response['message'] = 'Unknown';

        $verification_code = Str::random(32);

        $array['subject'] = 'Email Verification';
        $array['from'] = env('MAIL_USERNAME');
        $array['content'] = 'Verify your account';
        $array['link'] = route('email_change.callback') . '?new_email_verificiation_code=' . $verification_code . '&email=' . $email;
        $array['sender'] = Auth::user()->name;
        $array['details'] = "Email Second";

        $user = Auth::user();
        $user->new_email_verificiation_code = $verification_code;
        $user->save();

        try {
          
            Mail::to($email)->queue(new SecondEmailVerifyMailManager($array));

            $response['status'] = 1;
            $response['message'] = translate("Your verification mail has been Sent to your email.");
        } catch (\Exception $e) {
            // return $e->getMessage();
            $response['status'] = 0;
            $response['message'] = $e->getMessage();
        }

        return $response;
    }

    public function email_change_callback(Request $request)
    {
        if ($request->has('new_email_verificiation_code') && $request->has('email')) {
            $verification_code_of_url_param =  $request->input('new_email_verificiation_code');
            $user = User::where('new_email_verificiation_code', $verification_code_of_url_param)->first();

            if ($user != null) {

                $user->email = $request->input('email');
                $user->new_email_verificiation_code = null;
                $user->save();

                auth()->login($user, true);

                flash(translate('Email Changed successfully'))->success();
                return redirect()->route('dashboard');
            }
        }

        flash(translate('Email was not verified. Please resend your mail!'))->error();
        return redirect()->route('dashboard');
    }


    public function send_message()
    {

        try {

            $to = '971526719195';

            $start_msg = 'Dear Customer, This is a test in server';

            $foot = ',from BiriTading server.';

            Credentials::set('24baa0b710c713e63af5edab75f5c739', '18f761b425b750ba1831bdeb4a2183ac');
            $send_message = new Sms();
            $text = $start_msg . $foot;
            $send = $send_message->sendToOne($to, $text, 'BiriTrading');
        } catch (\Exception $e) {
            return 'false';
        }
    }

    public function searchTags(Request $request)
    {
        $key_get = $request->key;

        $prod_tags = \App\Product::where('tags', '<>', '')->get();

        $tags_arr = array();
        foreach ($prod_tags as $tag_key => $prod_tag) {
            $tags = explode(',', $prod_tag->tags);
            foreach ($tags as $tag_single) {
                if (isset($tags_arr) && in_array($tag_single, $tags_arr)) {
                } else {
                    $tags_arr[] = $tag_single;
                }
            }
        }
        $array_colors = array('#CD5C5C', '#40E0D0', '#DE3163', '#808000', '#6C3483', '#9C640C');
        $col_key = 0;
        $count = 0;
        $data = '';
        $ap = "'";
        foreach ($tags_arr as $key_ar_tag => $tag_arr) {

            if($request->key != '')
            {  
                if (strpos($tag_arr, strtolower($request->key)) !== false) {
                    if ($count != 25) {
                        if (isset($tag) && $tag_arr == $tag) {
                            $data .= '<span class="tag" style="color: #000;text-decoration: underline;" onclick="tag_search(' .$ap. $tag_arr .$ap. ')" >' . $tag_arr . '</span>';
                        } else {

                            $col = $array_colors[array_rand($array_colors, 1)];

                            $data .= '<span class="tag" style="background:' . $array_colors[$col_key] . '" onclick="tag_search(' .$ap. $tag_arr .$ap. ')" >' . $tag_arr . '</span>';
                            
                            $count++;
                            if ($key_ar_tag % 6 == 5) {
                                $col_key = 0;
                            } else {
                                $col_key++;
                            }
                        }
                    }
                }
            }
            else
            {
                if ($count != 25) {
                    if (isset($tag) && $tag_arr == $tag) {
                        $data .= '<span class="tag" style="color: #000;text-decoration: underline;" onclick="tag_search("' .$ap. $tag_arr .$ap. '")" >' . $tag_arr . '</span>';
                    } else {

                        $col = $array_colors[array_rand($array_colors, 1)];

                        $data .= '<span class="tag" style="background:' . $array_colors[$col_key] . '" onclick="tag_search("' .$ap. $tag_arr .$ap. '")" >' . $tag_arr . '</span>';

                        $count++;
                        if ($key_ar_tag % 6 == 5) {
                            $col_key = 0;
                        } else {
                            $col_key++;
                        }
                    }
                }
            }
        }


        return $data;
    }
    public function googleFeed()
{
          // dd('here');  
    //generates a Google Merchant XML feed of products
     

    $products = Product::where('published',1)->get();

     //dd($products);
    // $categories = Category::all();
    // $subcategories = SubCategory::all();
    // $subsubcategories = SubSubCategory::all();
    return response()->view('googlefeed', 
        ['products' => $products]
        
    )->header('Content-Type', 'text/xml');

}



    // public function androidOrIOS(Request $request) {
		
    //     $user_agent = $request->header('User-Agent');

    //     if (preg_match('/Android/i', $user_agent)) {
    //         return redirect()->away('https://play.google.com/store/apps/details?id=biritrading.co.uk');
    //     }
    //     elseif (preg_match('/Iphone/i', $user_agent)) {
    //         return redirect()->away('https://apps.apple.com/us/app/Biritrading/id1593659955');
    //     }
    //     elseif (preg_match('/Ipad/i', $user_agent)) {
    //         return redirect()->away('https://apps.apple.com/us/app/Biritrading/id1593659955');
    //     }
    //     elseif (preg_match('/Ipod/i', $user_agent)) {
    //         return redirect()->away('https://apps.apple.com/us/app/Biritrading/id1593659955');
    //     }
    //     else {
    //         return redirect()->away('https://play.google.com/store/apps/details?id=biritrading.co.uk');
    //     }
    // }
}
