<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Subscriber;

class SubscriberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email|max:100',
            'captchaResponse' => 'required',
        ]);
        
         $secretKey  = "6LfuftsjAAAAAA2VzM9DEI5ftr7LgZE5qZexrd5I";
        // $this->form_validation->set_rules('g-recaptcha-response','Captcha','callback_recaptcha');
        if(!empty($request->captchaResponse) && !empty($request->captchaResponse))
        {
            // Get verify response data
            $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secretKey.'&response='.$request->captchaResponse);
            $responseData = json_decode($verifyResponse);
            if($responseData->success)
            {
                $subscriber = Subscriber::where('email', $request->email)->first();
                if($subscriber == null){
                    $subscriber = new Subscriber;
                    $subscriber->email = $request->email;
                    $subscriber->save();
                    flash(translate('You have subscribed successfully'))->success();
                }
                else{
                    flash(translate('You are  already a subscriber'))->success();
                }
                return back();
            }
            else{
               return back();
            }
        }
        else{
            return back();
        }

        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
