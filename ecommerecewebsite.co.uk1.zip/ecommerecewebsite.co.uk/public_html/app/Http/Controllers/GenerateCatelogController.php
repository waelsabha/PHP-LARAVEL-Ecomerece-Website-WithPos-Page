<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use PDF;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GenerateCatelogController extends Controller
{
    //

    public function index()
    {
        $categories = Category::all();
        return view('generate_catelog.index',compact('categories'));
    }

    public function generateView(Request $request)
    {
        $products = array();
        $cat_ids  = $request->category_id;


        

        
        // dd($order->productExtra);
        
        // dd($products);
        // $exclude = ['PA003','PA002','WP005','PA005','EM003','CP006','PD004','WB005','WB006','WP004','EB002','WP009','WP010','PF001','WP006','TW004','TW051','BP003','BP002','PF002','TWP010','BP001','PP001','TW021','KT001','AC001','PA006','EB010','EM004','TE001','TW031','CP004','CP001','AC002','PP002','BP004','S001','TW039','TW045','EM00S','CB004','WP011','WP012','EM035','TW018','PD003','WP008','LT001','WP007','KT002','CP007','BP005'];
        $exclude =[];
        $products = DB::connection('mysql')->table('products')->whereNotIn('sku',$exclude)->where('current_stock','>',0)->where('published',1)->whereIn('category_id',$cat_ids)->orderBy('category_id', 'desc')->get();
        // $all = Product::all();
        // $products = Product::whereIn('category_id',$cat_ids)->orderBy('category_id', 'desc')->get();
        $products_variant = DB::connection('mysql')->table('products')->where('variant_product',1)->where('current_stock','>',0)->where('published',1)->whereIn('category_id',$cat_ids)->orderBy('category_id', 'desc')->get();
        $categories = Category::whereIn('id',$cat_ids)->get();
        // dd($ev->count());
        if($request->session()->has('removeProducts'))
           {
                           
            Session::forget('removeProducts');
           }
        return view('generate_catelog.view',compact('products','categories','cat_ids'));
    }

    public function removeProduct(Request $request)
    {
        $product = array();
        $product_id[] = $request->get('product_id');
        $product = $product_id;
        if($request->ajax())
        {
           if($request->session()->has('removeProducts'))
           {
            $old_items = Session::get('removeProducts', []);
                
                
            Session::put('removeProducts',array_merge($old_items,$product_id));
           }
            
           else{
            
            Session::put('removeProducts',$product_id);
           }    
            
            

            $sess2= $request->session()->get('removeProducts');
            return $sess2;
                        
            
        }
    }

    public function catelogPrint(Request $request)
    {
        // $data = $_GET['ids'];
        
        // $remove_products = Session::get('removeProducts', []);
        $cat_ids = $request->cat_id;

        // $exclude = ['PA003','PA002','WP005','PA005','EM003','CP006','PD004','WB005','WB006','WP004','EB002','WP009','WP010','PF001','WP006','TW004','TW051','BP003','BP002','PF002','TWP010','BP001','PP001','TW021','KT001','AC001','PA006','EB010','EM004','TE001','TW031','CP004','CP001','AC002','PP002','BP004','S001','TW039','TW045','EM00S','CB004','WP011','WP012','EM035','TW018','PD003','WP008','LT001','WP007','KT002','CP007','BP005'];
        $exclude =[];
        if(Session::has('removeProducts'))
        {
            $remove_products = Session::get('removeProducts', []);
            $products = DB::connection('mysql')->table('products')->whereNotIn('sku',$exclude)->where('current_stock','>',0)->where('published',1)->whereNotIn('id',$remove_products)->whereIn('category_id',$cat_ids)->orderBy('category_id', 'desc')->get();
            // $products = Product::whereNotIn('id',$remove_products)->whereIn('category_id',$request->cat_id)->get();
            // dd($remove_products);
        }
        else{
            $products = DB::connection('mysql')->table('products')->whereNotIn('sku',$exclude)->where('current_stock','>',0)->where('published',1)->whereIn('category_id',$request->cat_id)->orderBy('category_id', 'desc')->get();
            // $products = Product::whereIn('category_id',$request->cat_id)->orderBy('category_id', 'desc')->get();

        }
        // dd($products);
        $categories = Category::whereIn('id',$cat_ids)->get();

        // return view('generate_catelog.print_catelog', compact('products','cat_ids','categories'));
        // return view('generate_catelog.test2', compact('products','cat_ids','categories'));  

 
        $pdf = PDF::setOptions([
            'isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true,
            'logOutputFile' => storage_path('logs/log.htm'),
            'tempDir' => storage_path('logs/')
        ])->loadView('generate_catelog.test2', compact('products','cat_ids','categories'));
        Session::forget('removeProducts');
        return $pdf->stream('catelogTest.pdf');
        // return $pdf->download('order-.pdf');

    }
}
