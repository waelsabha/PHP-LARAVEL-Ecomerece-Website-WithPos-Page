<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use PDF;
use Session;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class GeneratePricelistController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        return view('generate_pricelist.index',compact('categories'));
    }

    public function generateView(Request $request)
    {
        $products = array();
        $cat_ids  = $request->category_id;


        

        
        // dd($order->productExtra);
        
        // dd($request);
        $othersetting = \App\OtherSetting::first();
        $price_margin =$othersetting->pricelist_minimum;

        if($request->price_margin > $othersetting->pricelist_minimum)
        {
            $price_margin = $request->price_margin;
        }

        if($request->price_margin < $othersetting->pricelist_minimum)
        {
            flash(translate('price margin should be greater than'.$othersetting->pricelist_minimum))->error();
            return redirect()->back();
        }
        $exclude = [];
        // $exclude = ['PA003','PA002','WP005','PA005','EM003','CP006','PD004','WB005','WB006','WP004','EB002','WP009','WP010','PF001','WP006','TW004','TW051','BP003','BP002','PF002','TWP010','BP001','PP001','TW021','KT001','AC001','PA006','EB010','EM004','TE001','TW031','CP004','CP001','AC002','PP002','BP004','S001','TW039','TW045','EM00S','CB004','WP011','WP012','EM035','TW018','PD003','WP008','LT001','WP007','KT002','CP007','BP005'];
        $products = DB::connection('mysql')->table('products')->whereNotIn('sku',$exclude)->where('current_stock','>',0)->where('published',1)->whereIn('category_id',$cat_ids)->orderBy('category_id', 'desc')->get(); 
        // $products = Product::whereIn('category_id',$cat_ids)->orderBy('category_id', 'desc')->get();
        $categories = Category::whereIn('id',$cat_ids)->get();
        // dd($products);
        if($request->session()->has('removeProducts'))
           {
                           
            Session::forget('removeProducts');
           }
        return view('generate_pricelist.view',compact('products','categories','cat_ids','price_margin'));
    }

    public function removeProduct(Request $request)
    {
        $product = array();
        $product_id[] = $request->get('product_id');
        $product = $product_id;
        if($request->ajax())
        {
           if($request->session()->has('removeProducts'))
           {
            $old_items = Session::get('removeProducts', []);
                
                
            Session::put('removeProducts',array_merge($old_items,$product_id));
           }
            
           else{
            
            Session::put('removeProducts',$product_id);
           }    
            
            

            $sess2= $request->session()->get('removeProducts');
            return $sess2;
                        
            
        }
    }

    public function pricelistFinal(Request $request)
    {
        // dd($request);
        $cat_ids = $request->cat_id;
        $exclude = [];
        // $exclude = ['PA003','PA002','WP005','PA005','EM003','CP006','PD004','WB005','WB006','WP004','EB002','WP009','WP010','PF001','WP006','TW004','TW051','BP003','BP002','PF002','TWP010','BP001','PP001','TW021','KT001','AC001','PA006','EB010','EM004','TE001','TW031','CP004','CP001','AC002','PP002','BP004','S001','TW039','TW045','EM00S','CB004','WP011','WP012','EM035','TW018','PD003','WP008','LT001','WP007','KT002','CP007','BP005'];
        if(Session::has('removeProducts'))
        {
            $remove_products = Session::get('removeProducts', []);
            $products = DB::connection('mysql')->table('products')->whereNotIn('id',$remove_products)->whereNotIn('sku',$exclude)->where('current_stock','>',0)->where('published',1)->whereIn('category_id',$request->cat_id)->orderBy('category_id', 'desc')->get();
            // $products = Product::whereNotIn('id',$remove_products)->whereIn('category_id',$request->cat_id)->get();
            // dd($remove_products);
        }
        // 
        // $products = Product::whereIn('id',)->whereIn('category_id',$request->cat_id)->get();
        else{
            $products = DB::connection('mysql')->table('products')->whereNotIn('sku',$exclude)->where('current_stock','>',0)->where('published',1)->whereIn('category_id',$request->cat_id)->orderBy('category_id', 'desc')->get();

            // $products = Product::whereIn('category_id',$request->cat_id)->orderBy('category_id', 'desc')->get();

        }
        // dd($products);
        $categories = Category::whereIn('id',$cat_ids)->get();

        return view('generate_pricelist.final', compact('products','cat_ids','categories','request'));
    }

    public function pricelistPrint(Request $request)
    {
        // $data = $_GET['ids'];
        // dd($request);
        // $remove_products = Session::get('removeProducts', []);
        $exclude = [];
        $cat_ids = $request->cat_id;
        // $exclude = ['PA003','PA002','WP005','PA005','EM003','CP006','PD004','WB005','WB006','WP004','EB002','WP009','WP010','PF001','WP006','TW004','TW051','BP003','BP002','PF002','TWP010','BP001','PP001','TW021','KT001','AC001','PA006','EB010','EM004','TE001','TW031','CP004','CP001','AC002','PP002','BP004','S001','TW039','TW045','EM00S','CB004','WP011','WP012','EM035','TW018','PD003','WP008','LT001','WP007','KT002','CP007','BP005'];
        if(Session::has('removeProducts'))
        {
            $remove_products = Session::get('removeProducts', []);
            $products = DB::connection('mysql')->table('products')->whereNotIn('id',$remove_products)->whereNotIn('sku',$exclude)->where('current_stock','>',0)->where('published',1)->whereIn('category_id',$request->cat_id)->orderBy('category_id', 'desc')->get();
            
            // $products = Product::whereNotIn('id',$remove_products)->whereIn('category_id',$request->cat_id)->get();
            // dd($remove_products);
        }
        // 
        // $products = Product::whereIn('id',)->whereIn('category_id',$request->cat_id)->get();
        else{
            $products = DB::connection('mysql')->table('products')->whereNotIn('sku',$exclude)->where('current_stock','>',0)->where('published',1)->whereIn('category_id',$request->cat_id)->orderBy('category_id', 'desc')->get();

            // $products = Product::whereIn('category_id',$request->cat_id)->orderBy('category_id', 'desc')->get();

        }
        // dd($products);
        $categories = Category::whereIn('id',$cat_ids)->get();

        // return view('generate_pricelist.print_pricelist', compact('products','cat_ids','categories'));
        // return view('generate_pricelist.test2', compact('products','cat_ids','categories','request'));

        
       

        $pdf = PDF::setOptions([
            'isHtml5ParserEnabled' => true, 'isRemoteEnabled' => true,
            'logOutputFile' => storage_path('logs/log.htm'),
            'tempDir' => storage_path('logs/')
        ])->loadView('generate_pricelist.test2', compact('products','cat_ids','categories','request'));

        return $pdf->stream('pricelistTest.pdf');
        // return $pdf->download('order-.pdf');

    }
}
