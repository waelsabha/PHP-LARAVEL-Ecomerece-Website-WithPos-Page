<?php


namespace App\Http\Controllers;


use App\CustomerPackage;
use App\Order;
use App\OrderDetail;

use App\Models\Cart;
use App\Utility\CashewUtility;
use Session;
use App\CartDetail;
use App\Product;
use Illuminate\Support\Facades\Log;
class CashewController extends Controller
{
    public function pay($order_id)
    {  
        
        $cashewsecretkey = "acfc366d820fa6f7f7395a1a5e72e9618ec2be1e66acab171de0a217b5a5ec24";
        $storeurl = "https://birigroup.co.uk/";  
        // $ch = curl_init(); 
        // curl_setopt($ch, CURLOPT_URL, "https://api-sandbox.cashewpayments.com/v1/identity/store/authorize"); 

        // curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        //    //"accept: application/vnd.ni-identity.v1+json",
        //     "cashewsecretkey: ".$cashewsecretkey,
        //     "storeurl : ".$storeurl,
        //    // "content-type: application/vnd.ni-identity.v1+json"
        // )); 
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        // curl_setopt($ch, CURLOPT_POST, 1); 
        // curl_setopt($ch, CURLOPT_POSTFIELDS,  "{\"realmName\":\"Cashew\"}"); 
        // $output = json_decode(curl_exec($ch)); 
        // dd($output);
        // $access_token = $output->access_token;
        // dd($access_token);

        $base_url = 'https://api-sandbox.cashewpayments.com/v1';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $base_url.'/identity/store/authorize');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);

        $headers = array();
        $headers[] = 'Cashewsecretkey: '.$cashewsecretkey;
        $headers[] = 'Storeurl: '.$storeurl;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
                echo 'Error:' . curl_error($ch);
            }
            curl_close($ch); 
        //   dd(json_decode($result)->data->token);
        $order = Order::findOrFail(Session::get('order_id'));
        
        $Shipping_address= $order->shipping_address;
       
      $customer_name=json_decode($Shipping_address)->name;
      
      $customer_email=json_decode($Shipping_address)->email;
      $customer_adress=json_decode($Shipping_address)->address;
      $customer_country=json_decode($Shipping_address)->country;
      $customer_emirate=json_decode($Shipping_address)->emirate;
      $customer_area=json_decode($Shipping_address)->area;
      $customer_building_name=json_decode($Shipping_address)->building_name;
      $customer_flat_no=json_decode($Shipping_address)->flat_no;
      $customer_landmark=json_decode($Shipping_address)->landmark;
      $customer_phone=json_decode($Shipping_address)->phone;
      //$orderid=$order->id;
         // $request->session()->get('cart');

      //$guest_id=Order::findOrFail(Session::get('guest_id'));
      //$customer_checkout_type=json_decode($Shipping_address)->checkout_type;
      //$cart_info=carts::findOrFail(Session::get('id'));
  
        $order_details = OrderDetail::where('order_id',$order_id)->get();
        $item = [];
        foreach($order_details as $key => $order_detail){
            $single_item['reference'] = $order_detail->id;
            $product = Product::where('id',$order_detail->product_id)->first();
            $single_item['name'] = $product->name;
            $single_item['description'] = $product->description;
            $single_item['url'] = 'https://brigroup.ae/product/'.$product->slug;
            $single_item['image'] = 'https://brigroup.ae/public/'.$product->thumbnail_img;
            $single_item['unitPrice'] = $product->unit_price;
            $single_item['quantity'] = $order_detail->quantity;
                                            
            $item[] = $single_item;
        }
        
        $order_data_json = [ 
                            "orderReference" => $order->code,
                            "totalAmount"=>$order->grand_total, 
                            "taxAmount"=>0,
                            "currencyCode"=> "AED",
                            "shipping"=>[
                                "reference"=> $order->code,
                                "name"=>$customer_name,
                                "address"=> [
                                    "firstName"=>$customer_name,
                                    "lastName"=> "",
                                    "phone"=>$customer_phone,
                                    "alternatePhone"=> $customer_phone,
                                    "address1"=> $customer_adress,
                                    "address2"=> "",
                                    "city"=> $customer_area,
                                    "state"=> $customer_emirate,
                                    "country" =>$customer_country,
                                    "postalCode"=> $customer_emirate
                               ]
                                ],
                                
                                "billingAddress"=>[
                                    "firstName"=> $customer_name,
                                    "lastName"=> "",
                                    "phone"=>$customer_phone,
                                    "alternatePhone"=> "",
                                    "address1"=> $customer_adress,
                                    "address2"=> "",
                                    "city"=> $customer_area,
                                    "state"=> $customer_emirate,
                                    "country" =>$customer_country,
                                    "postalCode"=> $customer_emirate
                                ],

                                "customer"=>[
                                    "id"=>$order->guest_id,
                                    "mobileNumber"=>$customer_phone,
                                    "email"=> $customer_email,
                                    "firstName"=>$customer_name,
                                    "lastName"=> "",
                                    "gender"=> "",
                                    "account"=> "",
                                    "dateOfBirth"=> "",
                                    "dateJoined"=> "",
                                    "defaultAddress"=>[
                                    "firstName"=> $customer_name,
                                    "lastName"=> "",
                                    "phone"=>$customer_phone,
                                    "alternatePhone"=> "",
                                    "address1"=> $customer_adress,
                                    "address2"=> "",
                                    "city"=> $customer_area,
                                    "state"=> $customer_emirate,
                                    "country" =>$customer_country,
                                    "postalCode"=> $customer_emirate
                                   ]
                                      ],
             "items"=>($item),
                                    
                                    "discounts"=> [
                                        [
                                            "code"=> "0",
                                            "name"=> "",
                                            "amount"=> 0,
                                        ]
                                    ],
                                    "merchant"=>[
                                        "confirmationUrl"=> "https:\/\/integrations.cashewpayments.com\/sdk\/index.php\/cashew-direct-integration\/?payment_status=success&order_reference_id=1649152893",
                                        "cancelUrl"=> "THIS IS CANCEL URL"
                                    ],
                                    "orderUrl"=>[
                                        "confirmationUrl"=> "https:\/\/integrations.cashewpayments.com\/sdk\/index.php\/cashew-direct-integration\/?payment_status=success&order_reference_id=1649152893",
                                        "cancelUrl"=> "THIS IS CANCEL URL"
                                    ],

                                    "metaData"=>[],
                                    "additionalInfos"=> [
                                        [
                                            "key"=> "nationality",
                                            "value"=> "UAE"
                                         ],
                                        [
                                            "key"=> "dob",
                                            "value"=> "1990-08-03"
                                         ],
                                       [ 
                                            "key"=> "gender",
                                            "value"=> "MALE"
                                       ]
                                    ]
                                   
        ];
         
         





            $order_data_json = json_encode($order_data_json);

            // dd($order_data_json);
            $access_token = json_decode($result)->data->token;
          $url = $base_url.'/checkouts';
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch, CURLOPT_POST, 1);
          
          $headers = array();
          $headers[] = 'Authorization: '.$access_token;
          $headers[] = 'Content-Type: application/json';
          curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $order_data_json);
          $result_order = curl_exec($ch);
          if (curl_errno($ch)) {
          echo 'Error:' . curl_error($ch);
          }
          curl_close($ch); 
          $res = json_decode($result_order);
          $token= $res->data->token;
          $url= $res->data->url;
          $orderId= $res->data->orderId;
          $expiryTime= $res->data->expiryTime;
          $storeToken = $access_token;
          return view('frontend.cashew',compact('token','url','orderId','expiryTime','storeToken'));

          dd($result_order);
    }


}
