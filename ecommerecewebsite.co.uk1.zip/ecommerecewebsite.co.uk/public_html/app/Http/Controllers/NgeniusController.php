<?php


namespace App\Http\Controllers;


use App\CustomerPackage;
use App\Order;
use App\Models\OrderDetail;
use App\Models\Cart;
use App\Utility\NgeniusUtility;
use Session;
use Illuminate\Support\Facades\Log;
class NgeniusController extends Controller
{
    public function pay()
    {
        if (Session::get('payment_type') == 'cart_payment') {
            $order = Order::findOrFail(Session::get('order_id'));
            $total_amount = $order->grand_total;

            
            $amount = round($total_amount * 100);
            //will be redirected
            NgeniusUtility::make_payment(route('ngenius.cart_payment_callback'),"cart_payment",$amount);
        } elseif (Session::get('payment_type') == 'wallet_payment') {
            $amount = round(Session::get('payment_data')['amount'] * 100);
            //will be redirected
            
            NgeniusUtility::make_payment(route('ngenius.wallet_payment_callback'),"wallet_payment",$amount);
        } elseif (Session::get('payment_type') == 'customer_package_payment') {
            $customer_package = CustomerPackage::findOrFail(Session::get('payment_data')['customer_package_id']);
            $amount = round($customer_package->amount * 100);
            //will be redirected
            
            NgeniusUtility::make_payment(route('ngenius.customer_package_payment_callback'),"customer_package_payment",$amount);
        } elseif (Session::get('payment_type') == 'seller_package_payment') {
            $seller_package = \App\SellerPackage::findOrFail(Session::get('payment_data')['seller_package_id']);
            $amount = round($seller_package->amount * 100);
            //will be redirected
            
            NgeniusUtility::make_payment(route('ngenius.seller_package_payment_callback'),"seller_package_payment",$amount);
        }
        

        $seller_package_id = Session::get('payment_data')['seller_package_id'];
        $seller_package  = \App\SellerPackage::findOrFail($seller_package_id);

    }

    public function cart_payment_callback()
    {
        if (request()->has('ref')) {
           return NgeniusUtility::check_callback(request()->get('ref'),"cart_payment");
        }
    }
    public function wallet_payment_callback()
    {
        if (request()->has('ref')) {
            return NgeniusUtility::check_callback(request()->get('ref'),"wallet_payment");
        }
    }

    public function customer_package_payment_callback()
    {
        if (request()->has('ref')) {
            return NgeniusUtility::check_callback(request()->get('ref'),"customer_package_payment");
        }
    }

    public function seller_package_payment_callback()
    {
        if (request()->has('ref')) {
            return NgeniusUtility::check_callback(request()->get('ref'),"seller_package_payment");
        }
    }

    public function ngenius_check_callback()
    {

        if (request()->has('ref')) {
        Log::info($_GET['ref']);
         
        $outlet = "adbe5328-aa64-4f4b-a353-a2d027f33ca6";
        $apikey = "NDcwNTc5NmItNmZiZC00NjRjLTg3OTEtZmM5ZGZjMWIwMDk4OmM2MWZjMmRhLWJmYjgtNGQzNy04MmQ4LTZjNDk1YzQ0MmJjNA==";   // enter your API key here
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, "https://api-gateway.ngenius-payments.com/identity/auth/access-token"); 

        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "accept: application/vnd.ni-identity.v1+json",
            "authorization: Basic ".$apikey,
            "content-type: application/vnd.ni-identity.v1+json"
        )); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        curl_setopt($ch, CURLOPT_POST, 1); 
        curl_setopt($ch, CURLOPT_POSTFIELDS,  "{\"realmName\":\"NetworkInternational\"}"); 
        $output = json_decode(curl_exec($ch)); 
        $access_token = $output->access_token;

        Log::info(json_encode($access_token));
        /////////////////////order status//////////////////////////////
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api-gateway.ngenius-payments.com/transactions/outlets/".$outlet."/orders/".$_GET['ref'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "accept: application/vnd.ni-payment.v2+json",
            "authorization: Bearer ".$access_token
        ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            //echo "cURL Error #:" . $err;
           
            // return $err;
        } else {
        //pre_list($response);
        // return $response;
            
        }
        
        $orderStatusResponse = json_decode($response);
        Log::info(json_encode($orderStatusResponse));
        if ($orderStatusResponse->_embedded->payment[0]->state == "FAILED") {
            // fail or cancel or incomplete
            Session::forget('payment_data');
            flash(translate('Payment incomplete'))->error();
            $message = 'Payment incomplete..Please Try Again Later.';
            return view('frontend.app_message_notification',compact('message'));

        } else if ($orderStatusResponse->_embedded->payment[0]->state == "CAPTURED") {
            // success

            $payment = json_encode($orderStatusResponse);

            //dd($payment_type, Session::get('order_id'),Session::get('payment_data'), $payment);

            $payment_type = 'cart_payment';
                $checkoutController = new CheckoutController;
                $order = Order::where('payment_reference_id',$_GET['ref'])->first();
                $order_details = OrderDetail::where('order_id',$order->id)->first();
                if($order_details->mobile_app_cart_id != null){
                    $select_cart = Cart::where('id', $order_details->mobile_app_cart_id)->first();
                    if($select_cart->user_id != null){
                        Cart::where('user_id', $select_cart->user_id)->delete();
                    }
                    else{
                        Cart::where('device_id', $select_cart->device_id)->delete();
                    }
                }
                return $checkoutController->checkout_done($order->id, $payment,1);
            
        }
        }
    }


}
