<?php

namespace App\Http\Middleware;

use App\Country;
use App\Currency;
use App\Redirection;
use Closure;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Stevebauman\Location\Facades\Location;

class Redirection301
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // return $next($request);
        
        $ip = $request->ip();
        // $ip = '217.165.123.18';
        // $ip = '3.5.223.255';
    //    dd(Location::get($ip));
        $redirection = Redirection::where('old_url',$request->fullUrl())->first();
        
        if($redirection)
        {  
            return redirect(env('APP_URL_SLASH').$redirection->new_url, 301);
        }
        else
        {
            //return $next($request);
        }

        
        return $next($request);
        try
        {            
            // Log::info('IP Address --'.$request->ip());      
            // Log::info($request->server('HTTP_USER_AGENT'));      
        }
        catch(\Exception $e)
        {

        }
        
        
        
    }
}
