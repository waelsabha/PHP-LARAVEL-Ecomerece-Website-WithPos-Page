<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\ResourceCollection;

class SliderCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return [
            'data' => $this->collection->map(function($data) {
                //return $data;
                 $replace = explode('sliders/',$data->photo);
                
                $add = $replace[0].'sliders/compressed/'.$replace[1];
                $data->photo = $add;
                return ($data);       
               
            })
        ];
    }

    public function with($request)
    {
        return [
            'success' => true,
            'status' => 200
        ];
    }
}
