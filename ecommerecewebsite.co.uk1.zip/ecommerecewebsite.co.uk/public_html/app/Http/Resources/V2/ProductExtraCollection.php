<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\ResourceCollection;
use Illuminate\Support\Facades\Log;
use App\Product;

class ProductExtraCollection extends ResourceCollection
{
    public function toArray($request)
    {
        
        //Log::info('here in home page Resources');
        return [
            'data' => $this->collection->map(function($data) {
                if($data->battery == 0){
                    $bat_text = 'Not required';
                }
                else{
                    $bat_text = 'Battery Required';
                }
                $product = Product::where('id',$data->product_id)->first();

                $text = '<b>Name </b>: '.$product->name.' <br> <b>Package Includes</b> : '.$data->package_include;
                                                  
                                                          
                        $text .= '<br> <b>Material </b>: '.ucwords($data->material);

                                $text .=      ' <br> <b>Weight </b>: ' .$data->product_weight . $data->product_weight_unit;
                                $text .=  ' <br> <b>Packing Dimensions </b>: ';
                                                            

                                                                    if(!is_null($data->package_dimention))
                                                                    {
                                                                        $packing_dim = explode(',',$data->package_dimention);
                                                                    }
                                                                
                                                           
                                                            
                                                                
                                                                    if(!is_null($data->package_dimention)){

                                                                    $text .= 'Length :'. $packing_dim[0]  .$data->package_unit;
                                                                    $text .= ', ';
                                                                    
                                                                    $text .= 'Width :'. $packing_dim[1]  .$data->package_unit;
                                                                    $text .= ', ';
                                                                    
                                                                    $text .= 'Height :'. $packing_dim[2]  .$data->package_unit;
                                                                    $text .= '. ';

                                                                    }
                                                                
                                            
                                            $text .=  '<br> <b>Product Dimensions </b>: ';
                                                            
                                                                if(!is_null($data->product_dimention))
                                                                {
                                                                    $product_dim = explode(',',$data->product_dimention);
                                                                }
                                                               
                                                            
                                                                
                                                                    if(!is_null($data->product_dimention))
                                                                    {
                                                                        $text .= 'Length :' .$product_dim[0] . $data->product_unit;
                                                                        $text .= ', ';
                                                                    
                                                                        $text .= 'Width :' .$product_dim[1] . $data->product_unit;
                                                                        $text .= ', ';
                                                                    
                                                                        $text .= 'Height :' .$product_dim[2] . $data->product_unit;
                                                                        $text .= ', ';

                                                                    } 

                                                          $text .= '<br> <b>Batteries </b>: ';
                                                                
                                                                    if($data->battery == 1)
                                                                    {
                                                                        $text .= 'Battery : Required <br> Battery Type :'. $data->battery_type .'<br>Battery Quantity :'. $data->battery_qty;   
                                                                    }
                                                                    else{
                                                                        $text .= 'Battery : Not  Required';
                                                                    }                                                           
                                                                    
                                                        
                                                          $text .= ' <br> <b>Recommended age by manufacturer</b>: '. $data->age_for;

                                                        $text .= '
                                                        <br> <b>Country of origin </b>: '. ucwords($data->country_of_origin) ;
                return [
                    'id' => $data->product_id,
                    'name' => $product->name,
                    'material' => $data->material,
                    'battery' =>  $bat_text,
                    'battery_type' => $data->battery_type,
                    'package_dimention' => $data->package_dimention,
                    'product_dimention' => $data->product_dimention,
                    'age_for' => $data->age_for,
                    'country_of_origin' =>$data->country_of_origin,
                    'product_weight' => $data->product_weight,
                    'product_weight_unit' => $data->product_weight_unit,
                    'package_include' => $data->package_include,
                    'package_include_arabic' => $data->package_include_arabic,
                    'package_unit' => $data->package_unit,
                    'product_unit' => $data->product_unit,
                    'description' => $text,
                    
                ];
            })
        ];
    }

    public function with($request)
    {
        return [
            'success' => true,
            'status' => 200
        ];
    }
}
