<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\ResourceCollection;

class AddressCollection extends ResourceCollection
{
    public function toArray($request)
    {
        return [
            'data' => $this->collection->map(function($data) {
                if($data->user_id == null || $data->user_id == '')
                {
                    return [
                        'id'      =>(int) $data->id,
                        'device_id' => $data->device_id,
                        'address' => $data->address,
                        'country' => $data->country,
                        'city' => $data->area,
                        'postal_code' => $data->phone,
                        'phone' => $data->phone,
                        'set_default' =>(int) $data->set_default
                    ];
                }
                return [
                    'id'      =>(int) $data->id,
                    'user_id' =>(int) $data->user_id,
                    'address' => $data->address,
                    'country' => $data->country,
                    'city' => $data->area,
                    'postal_code' => $data->phone,
                    'phone' => $data->phone,
                    'set_default' =>(int) $data->set_default
                ];
            })
        ];
    }

    public function with($request)
    {
        return [
            'success' => true,
            'status' => 200
        ];
    }
}
