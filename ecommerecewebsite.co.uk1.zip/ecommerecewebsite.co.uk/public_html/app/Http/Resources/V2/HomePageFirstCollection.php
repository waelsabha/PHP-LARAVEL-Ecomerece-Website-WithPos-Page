<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\ResourceCollection;
use App\Http\Resources\ProductCollection;
use App\Models\FlashDeal;
use App\Models\Product;

class HomePageFirstCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'data' => $this->collection->map(function($data) {
                if(isset($data->page_in_home))
                {
                    return [
                        'id' => $data->id,
                        'title' => $data->page_in_home,
                        'banner' => $data->banner
                    ];
                }
                else 
                {
                    return [
                        'id' => $data->category_id,
                        'title' => $data->title,
                        'banner' => $data->banner
                    ];  
                }
                
            })
        ];
    }

    public function with($request)
    {
        return [
            'success' => true,
            'status' => 200
        ];
    }
}
