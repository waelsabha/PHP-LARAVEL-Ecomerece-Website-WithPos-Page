<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\ResourceCollection;

class StatesCollection extends ResourceCollection
{
    public function toArray($request)
    {
        
        return [

            'data' => $this->collection->map(function($data) {
                // dd($data);
                if($data['sc_emirate'] != null || $data['sc_emirate'] !=" ")
                {
                    if(rtrim($data['sc_emirate']) == $data['sc_emirate']) 
                    {
                        return [     
                                    
                            'name' => $data['sc_emirate'],  
                        ];
                    }
                }
                
                
            })
        ];
    }

    public function with($request)
    {
        return [
            'success' => true,
            'status' => 200
        ];
    }
}
