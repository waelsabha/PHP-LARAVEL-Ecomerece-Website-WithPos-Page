<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\ResourceCollection;
use App\Models\Review;
use App\Models\Attribute;
use App\ProductStock;
use DateInterval;
use DateTime;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;

ini_set('serialize_precision', -1);

class ProductDetailCollection extends ResourceCollection
{
    public function toArray($request)
    {
        //Log::info(json_encode($request));
        return [
            'data' => $this->collection->map(function($data) {
                //Log::info(json_encode($data));
                $precision = 2;
                $calculable_price = homeDiscountedBasePrice($data->id);
                $calculable_price = number_format($calculable_price, $precision, '.', '');
                $calculable_price = floatval($calculable_price);
                // $calculable_price = round($calculable_price, 2);
                $current_stock = 0;
                if($data->variant_product == 1)
                {
                    $stock = ProductStock::where('product_id',$data->id)->where('qty','>','0')->first();
                    if($stock)
                    {
                        $current_stock = $stock->qty;
                    }
                }
                else{
                    $current_stock = $data->current_stock;
                }
                                        $order_txt = ' ';
                                        $receive_text = ' ';
                                        $date = date('Y-m-d');
                                        $time = date('H:i');
                                        $time_h = date('H');
                                        $add_holiday = env('HOLIDAY_DATE');
                                        $add_holiday_count = env('HOLIDAY_COUNT');
                                        
                                       $final_date = new DateTime('tomorrow');
                                      // $final_date = new DateTime('2021-07-01');
                                       
                                       $tommorrow = 'Tommorow';
                                      
                                       if($time_h >= env('DELIVERY_TIME'))
                                       {
                                        
                                        $final_date =   $final_date->add(new DateInterval('P1D'));
                                        
                                        $tommorrow = $final_date->format('l');
                                        
                                        if($tommorrow == 'Saturday')
                                        {
                                            
                                            $final_date =   $final_date->add(new DateInterval('P1D'));
                                            $tommorrow = $final_date->format('l');  
                                        }
                                        //dd($tommorrow);
                                       }
                                      
                                       if($add_holiday == 1)
                                       {
                                            $final_date =   $final_date->add(new DateInterval('P'.$add_holiday_count.'D'));
                                            $tommorrow = $final_date->format('l');
                                       }
                                       $tom_day = $final_date->format('l');
                                       if($tom_day == 'Friday')
                                       {
                                           
                                            //$today_get = new DateTime('');

                                            $final_date =   $final_date->add(new DateInterval('P2D'));
                                            $tommorrow = $final_date->format('l');
                                             
                                       }
                                        $monthName = $final_date->format('M');
                                        $day = $final_date->format('d');
                                        $base_code = \App\Currency::findOrFail(\App\BusinessSetting::where('type', 'system_default_currency')->first()->value)->code;
                                        if (Session::has('currency_code')) {
                                            $currency = \App\Currency::where('code', Session::get('currency_code', $base_code))->first();
                                            $check_code = Session::get('currency_code');
                                        } else {
                                            $currency = \App\Currency::where('code', $base_code)->first();
                                            $check_code = $base_code;
                                        }
                                        
                                        $get_new_today = new DateTime();
                                        $get_new_today = $get_new_today->format('l');
                                        if($get_new_today == 'Wednesday' && $tommorrow == 'Sunday')
                                        {
                                            $final_date =   $final_date->sub(new DateInterval('P1D'));
                                            $tommorrow = $final_date->format('l');
                                            
                                        }
                                        
                                    
                                       if($check_code == $base_code){
                                        
                                                if($time_h < env('DELIVERY_TIME')){
                                                    

                                                        $time1 = new DateTime(env('DELIVERY_TIME').':00:00');
                                                        $time2 = new DateTime($time.':00');
                                                        $interval = $time1->diff($time2);
                                                        
                                                        $dif =$interval->format('%h');
                                                        $time_i = $interval->format('%i');

                                                        
                                                    
                                                    if ($current_stock > 0){
                                                        $order_txt = 'Order within '.$dif.' hrs and '.$time_i.' mins';
                                                    // <span class="strong-600" style="color:#000;font-size: 18px;">{{ translate('Order within')}}<span style="color:rgb(94, 202, 85);"> {{$dif}} hrs and {{$time_i}} mins</span></span>
                                                    }
                                                }else{
                                                    if ($current_stock > 0){
                                                        $order_txt ='Order now';
                                                    // <span class="strong-600 " style="color:rgb(94, 202, 85);font-size: 18px;">{{ translate('Order now')}} </span>
                                                    }
                                                }
                                        
                                                if($time_h < env('DELIVERY_TIME')){
                                                 
                                                $time1 = new DateTime(env('DELIVERY_TIME').':00:00');
                                                $time2 = new DateTime($time.':00');
                                                $interval = $time1->diff($time2);
                                                
                                                $dif =$interval->format('%h');
                                                $time_i = $interval->format('%i');
                                                 
                                                
                                                    if ($current_stock > 0){
                                                        
                                                        $receive_text = 'Get it by '.$tommorrow.', '.$monthName .$day ;
                                                    // <span class="strong-600" style="color:#000;font-size: 18px;">{{ translate('Get it by ') }}<span style="color:#000;font-size: 22px;">{{($tommorrow) }}</span>, {{$monthName}} {{$day}}</span>
                                                    }
                                                }
                                                    else{
                                                    if ($current_stock > 0){
                                                        $receive_text = 'Get it by '.$tommorrow.', '.$monthName .$day ;
                                                    // <span class="strong-600" style="color:#000;font-size: 18px;">{{ translate('Get it by ') }}<span style="color:#000;font-size: 22px;">{{ __($tommorrow) }}</span>, {{$monthName}} {{$day}}</span>
                                                    }
                                                    
                                                }
                                            
                                            
                                        
                                        }else{ 
                                            $order_txt = 'Order now';
                                            $receive_text = 'Get it within 7-10 working days';
                                       
                                        }
                return [
                    'id' => (integer) $data->id,
                    'name' => $data->name,
                    'added_by' => $data->added_by,
                    'seller_id' => $data->user->id,
                    'shop_id' => $data->added_by == 'admin' ? 0 : $data->user->shop->id,
                    'shop_name' => $data->added_by == 'admin' ? 'In House Product' : $data->user->shop->name,
                    'shop_logo' => $data->added_by == 'admin' ? (get_setting('header_logo'))  : ($data->user->shop->logo),
                    'photos' => json_decode($data->photos),
                    'thumbnail_image' => ($data->thumbnail_img),
                    'tags' => explode(',', $data->tags),
                    'price_high_low' => (double) explode('-', homeDiscountedPrice($data->id))[0] == (double) explode('-', homeDiscountedPrice($data->id))[1] ? format_price( (double) explode('-', homeDiscountedPrice($data->id))[0]) : "From ".format_price( (double)explode('-', homeDiscountedPrice($data->id))[0])." to ".format_price( (double) explode('-', homeDiscountedPrice($data->id))[1]),
                    'choice_options' => $this->convertToChoiceOptions(json_decode($data->choice_options)),
                    'colors' => json_decode($data->colors),
                    'has_discount' => homeBasePrice($data->id) != homeDiscountedBasePrice($data->id) ,
                    'stroked_price' => home_base_price($data->id),
                    'main_price' => home_discounted_base_price($data->id),
                    'calculable_price' => $calculable_price,
                    'currency_symbol' => currency_symbol(),
                    'current_stock' => (integer) $current_stock,
                    'unit' => $data->unit,
                    'rating' => (double) $data->rating,
                    'rating_count' => (integer) Review::where(['product_id' => $data->id])->count(),
                    'earn_point' => (double) $data->earn_point,
                    'description' => $data->description,
                    'order_txt' => $order_txt,
                    'receive_text' => $receive_text

                ];
            })
        ];
    }

    public function with($request)
    {
        return [
            'success' => true,
            'status' => 200
        ];
    }

    protected function convertToChoiceOptions($data){
        $result = array();
        foreach ($data as $key => $choice) {
            $item['name'] = $choice->attribute_id;
            $item['title'] = Attribute::find($choice->attribute_id)->name;
            $item['options'] = $choice->values;
            array_push($result, $item);
        }
        return $result;
    }

    protected function convertPhotos($data){
        $result = array();
        foreach ($data as $key => $item) {
            array_push($result, api_asset($item));
        }
        return $result;
    }
}
