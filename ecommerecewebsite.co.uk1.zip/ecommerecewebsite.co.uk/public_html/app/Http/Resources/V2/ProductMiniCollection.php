<?php

namespace App\Http\Resources\V2;

use Illuminate\Http\Resources\Json\ResourceCollection;
use Illuminate\Support\Facades\Log;

class ProductMiniCollection extends ResourceCollection
{
    public function toArray($request)
    {
        
        //Log::info('here in home page Resources');
        return [
            'data' => $this->collection->map(function($data) {
                
                return [
                    'id' => $data->id,
                    'name' => $data->name,
                    'thumbnail_image' => ($data->thumbnail_img),
                    'base_price' => format_price(homeBasePrice($data->id)) ,
                    'rating' => (double) $data->rating,
                    'sales' => (integer) $data->num_of_sale,
                    'links' => [
                        'details' => route('products.show', $data->id),
                    ]
                ];
            })
        ];
    }

    public function with($request)
    {
        return [
            'success' => true,
            'status' => 200
        ];
    }
}
