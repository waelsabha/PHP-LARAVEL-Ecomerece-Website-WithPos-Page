<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\VariationValueTemplete;
class VariationTemplete extends Model
{
    //

    protected $guarded = ['id'];
    // public $table = ['variation_templetes'];

    /**
    * Get the attributes for the variation.
    */
    public function values()
    {
        return $this->hasMany(VariationValueTemplete::class);
    }
}
