<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VariationValueTemplete extends Model
{
    //

    protected $guarded = ['id'];

    // public $table = ['variation_value_templetes'];
    /**
     * Get the variation that owns the attribute.
     */
    public function variationTemplate()
    {
        return $this->belongsTo(\App\VariationTemplate::class);
    }
}
